package Object_Repository;

import org.openqa.selenium.By;

public class OB_COS_obj {
	
//Mortgage Loan
	//Login 
	
	public static final By Cos_UserName =By.id("jsUser");
	public static final By Cos_pwd =By.id("jsPassword");
	public static final By Cos_Submit =By.name("submit");
	public static final By Cos_loggedin =By.xpath("//span[contains(text(), 'Logged in as')]");
	//##################### Home Page ##################################
	
	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Document_Status = By.linkText("Document Status");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Application_ID = By.linkText("Application ID");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By checkapprefid = By.id("checkapprefid");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By channel = By.id("channel");


	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Product = By.linkText("Product");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By The_Land_RegistryIRIS = By.linkText("The Land Registry - IRIS");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Origination = By.linkText("Origination");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Name = By.linkText("Name");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Refresh = By.linkText("Refresh");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By CIMS = By.linkText("CIMS");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Queue = By.id("queueLov");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Logout = By.linkText("Logout");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By NORKOM = By.linkText("NORKOM 5.6");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Application_Status = By.linkText("Application Status");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Standard_Chartered_Bank_Online = By.linkText("Standard Chartered Bank Online");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By HK_GOV = By.linkText("HK GOV");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Now_viewing = By.id("editLov");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By CREATE_NEW = By.xpath("//span[text()='Create New']/..");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Campaign_Code = By.linkText("Campaign Code");

	 
	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By PCCW_Directory_Inqueries = By.linkText("PCCW Directory Inqueries");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By stxt_SD_APPREFID = By.id("stxt_SD.APPREFID");
	 
	 public static final By txt_APPREFID = By.id("stxt_APPREFID");
	 
	 public static final By Go_Button = By.name("btnLOVSearch");
	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Filter_By = By.id("slst_PRODUCTTYPEOCDE");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By stxt_CUSTID = By.id("stxt_CUSTID");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By APR_Calculator = By.linkText("APR Calculator");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Queue_Status = By.linkText("Queue Status");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Advanced_Search = By.linkText("Advanced Search");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By CCY_Value = By.linkText("CCY - Value");

	 //New Object added - 07.03.2019 - 11.16.38

	 public static final By Sourcing_ID = By.linkText("Sourcing ID");
	 
	 
	 //############################## Create New ######################################	
	
	

	 public static final By sBeginAIPOptionNewProduct = By.id("jsBeginAIPSelectorNewProduct");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By countryOfIssue = By.id("countryOfIssue");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By ID_Type = By.id("IDTypeCode");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By jsCalendar101 = By.id("shellDateOfIncorporation");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By primaryPhoneType = By.id("primaryPhoneType");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By referralID = By.id("referralID");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By productClassificationCode = By.id("jsBeginAIPOptionNewProduct");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By salutationCode = By.id("salutationCode");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By Mobile_Number = By.id("dedupeMobileNo");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By dateOfBirth = By.id("dateOfBirth");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By primaryPhoneNumber = By.id("primaryPhoneNumber");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By isdCode = By.id("isdCode");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By docExpiryDate = By.id("docExpiryDate");

	//New Object added - 06.03.2019 - 16.25.00

	 public static final By Email = By.id("emailAddress");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By closingID = By.id("closingID");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By Cancel_Application = By.linkText("Cancel Application");
	 
	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By sourcingID = By.id("sourcingID");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By ID_Number = By.id("custIDStyleID");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By Full_Name = By.id("name");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By Customer = By.linkText("1Customer");

	 //New Object added - 06.03.2019 - 16.25.00

	 public static final By isdAreaCode = By.id("isdAreaCode");
	 
	 public static final By dedupe_Button = By.name("dedupe");
	 
	 public static final By PerformPreScreen = By.id("PerformPreScreen");
	 
	 public static final By result = By.xpath("//span[contains(@class,'scbCosContentStyle506Result')]");
	 
	 public static final By Process = By.id("jsProcessBut");
	 
	 public static final By Process_DocumentHandling = By.id("styleIdProcess");
	 
	 public static final By save = By.name("save");
	 	
	 
	 
	 //####################################KIV Result################################
	 public static final By Launch_Appliaction = By.linkText("Launch Application");
	 
	 public static final By KIV_Remarks = By.id("remarks");
	 
	 public static final By submit_Replay = By.id("disableReply");
	
	//Product details
	 public static final By PRODUCT_TYPE=By.id("productType");
	 public static final By CAMPAIGN_CODE=By.id("promotionCodeDisplayData");
	 public static final By Affiliation =By.id("cardTypeCode");
	 public static final By Card_Type =By.id("subCardTypeCode");
	 public static final By search_Icon = By.xpath("//span[@class='searchButtons']/a");
	 
	 public static final By Fee_Terms = By.id("subChannelCode");
	 public static final By ASSESSMENT_TYPE=By.id("assesmentType");
	 public static final By Request_Amount = By.name("appliedAmount");
	 public static final By supplementry_Cards = By.name("suppCardFlag");
	 
	public static final By PRODUCT_CATEGORY=By.xpath("//select[@id='productCategory']");
	
	
	public static final By MORTGAGE_TYPE=By.id("mortgageTypeCode");
	public static final By MORTGAGE_SERVICES=By.id("mortgageServiceCode");
	
	public static final By BROKER_REFERRAL_FLAG=By.id("lbrokerReferralFlag");
	
	//############Prodcut Details##############################################
	
	 public static final By Applicant_Details = By.xpath("//*[text()='Applicant Details']/../..");
			
	 public static final By Personal_Details = By.xpath("//*[text()='Personal Details']/../..");
	 
	 public static final By ICDD_Details = By.xpath("//*[text()='ICDD Details']/../..");
	 
	 public static final By Contact_Details = By.xpath("//*[text()='Contact Details']/../..");
	 public static final By Contact_Information = By.xpath("//*[text()='Contact Information']/../..");
	 public static final By Residential_Address = By.xpath("//*[text()='Residential Address']/../..");
	 
	 public static final By Employment_Profession_Details = By.xpath("//*[text()='Employment / Profession Details']/../..");
	 
	 public static final By employment_Profession_information= By.xpath("//*[text()='Employment / Profession & Financial Details']/../..");
	 
	 public static final By Bank_Use= By.xpath("//*[text()='Bank Use']/../..");
	
	 
	 public static final By Financial_Details = By.xpath("//*[text()='Financial Details']/../..");
	 
	 public static final By More_Financial_Details = By.xpath("//*[text()='More Financial Details']/../..");
	 
	 public static final By search_Icon_Phone = By.id("staffSearch");
	 
	 public static final By search_Icon_Business = By.xpath("//input[@id='natureOfBussinessDisplayName']/following-sibling::span/a");
	 
	 public static final By search_Icon_Occupation = By.xpath("//input[@id='occupationCodeDisplayName']/following-sibling::span/a");
	 
	 public static final By search_Icon_EmploymentType = By.xpath("//input[@id='employmentTypeCodeDisplayName']/following-sibling::span/a");
	 
	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  offUsOtherText1 = By.id("offUsOtherText1");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  callSeconds = By.id("callSeconds");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  emailOptFlag = By.id("emailOptFlag");

	
	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  monthlyMortgagePayment = By.id("monthlyMortgagePayment");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  occupationCodeDisplayName = By.id("occupationCodeDisplayName");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  annualRentalIncome = By.id("annualRentalIncome");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  nationalityCode = By.id("nationalityCode");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  emailAddress = By.id("emailAddress");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  staffInd = By.id("staffInd");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasAnnualBasicIncome = By.id("overseasAnnualBasicIncome");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasAnnualSurrogateIncome = By.id("overseasAnnualSurrogateIncome");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  phoneOptFlag = By.id("phoneOptFlag");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  annualBasicIncome = By.id("annualBasicIncome");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasAnnualCommission = By.id("overseasAnnualCommission");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  turnOverDeclared = By.id("turnOverDeclared");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  payRollCustomer = By.id("payRollCustomer");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  offUSAccountNumber = By.xpath("//*[contains(@id, offUSAccountNumber)]");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  accountCode = By.id("accountCode");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  shellDateOfIncorporation = By.id("shellDateOfIncorporation");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  annualCommission = By.id("annualCommission");

	 
	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  postOptFlag = By.id("postOptFlag");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  connectedPartyRelation = By.id("connectedPartyRelation");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  mailingAddressIndicator = By.id("mailingAddressIndicator");



	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  natureOfBussinessDisplayName = By.id("natureOfBussinessDisplayName");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  csiFlag = By.id("csiFlag");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  resZipCode = By.id("resZipCode");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  acctDtaccountSourcels = By.id("acctDtls[0].accountSource");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  offUsOther = By.id("offUsOther");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  annualotherIncome = By.id("annualotherIncome");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  yrsInOccupation = By.id("yrsInOccupation");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  phoneConversationFlag = By.id("phoneConversationFlag");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  name = By.id("name");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  resAddress1 = By.id("resAddress1");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  monthsInOccupation = By.id("monthsInOccupation");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  resAddress3 = By.id("resAddress3");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  resAddress2 = By.id("resAddress2");


	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  acctDtlsoffUSAccountType = By.id("acctDtls[0].offUSAccountType");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasAnnualotherIncome = By.id("overseasAnnualotherIncome");


	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  monthlyRentalPayment = By.id("monthlyRentalPayment");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  callMinute = By.id("callMinute");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  decOnUsGlobal = By.id("decOnUsGlobal");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasTurnOverDeclared = By.id("overseasTurnOverDeclared");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  teleSalesPhone = By.id("teleSalesPhone");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  dedupeMobileNo = By.id("dedupeMobileNo");


	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  callInterval = By.id("callInterval");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  teleSalesName = By.id("teleSalesName");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  annualSurrogateIncome = By.id("annualSurrogateIncome");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  smsOptFlag = By.id("smsOptFlag");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  callHour = By.id("callHour");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  connectedLendingIndicator = By.id("connectedLendingIndicator");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasTurnOverAsPerStmt = By.id("overseasTurnOverAsPerStmt");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  customerSegment = By.id("customerSegment");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  turnOverAsPerStatement = By.id("turnOverAsPerStatement");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  custIDStyleID = By.id("custIDStyleID");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  residenceStatus = By.id("residenceStatus");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  profitAsPerPL = By.id("profitAsPerPL");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasAnnualRentalIncome = By.id("overseasAnnualRentalIncome");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  residenceStatusOthers = By.id("residenceStatusOthers");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  offUsGlobal = By.id("offUsGlobal");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  offUsCash = By.id("offUsCash");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  dropDownAumRequest = By.id("dropDownAumRequest");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  permanentResFlag = By.id("permanentResFlag");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  decOnUsCash = By.id("decOnUsCash");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasAnnualBonus = By.id("overseasAnnualBonus");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  annualBonus = By.id("annualBonus");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  customerConsent = By.id("customerConsent");


	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  shellCompanyCertificateInCorNo = By.id("shellCompanyCertificateInCorNo");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  mobileNo = By.id("mobileNo");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  employmentTypeCodeDisplayName = By.id("employmentTypeCodeDisplayName");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  resState = By.id("resState");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  decOnUsOther = By.id("decOnUsOther");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  interestCode = By.id("interestCode");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  overseasProfitAsPerPL = By.id("overseasProfitAsPerPL");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  financialCurrencyCode = By.id("financialCurrencyCode");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  conversationDate = By.id("conversationDate");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  offUsOtherText = By.id("offUsOtherText");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  resCountry = By.id("resCountry");

	 //New Object added - 07.03.2019 - 17.26.00

	 public static final By  resCity = By.id("resCity");
	 //New Object added - 07.03.2019 - 17.40.11

	 public static final By acctDtlsofUSAccountType = By.id("acctDtls[0].offUSAccountType");

	 //New Object added - 07.03.2019 - 17.40.11

	 public static final By acctDtlsaccountSource = By.id("acctDtls[0].accountSource");
	
	 
	 //########################################AIP Results#############################33333
	 public static final By customerRequest_status = By.xpath("//label[text() ='Status:']/../following-sibling::dd/span");
	 public static final By customerRequest_Brand_Usage = By.xpath("//label[text() ='Brand & Usage:']/../following-sibling::dd/span");
	 public static final By customerRequest_Affilation = By.xpath("//label[text() ='Affiliation:']/../following-sibling::dd/span");
	 public static final By customerRequest_CardType = By.xpath("//label[text() ='Card Type:']/../following-sibling::dd/span");
	 public static final By customerRequest_DeclineReason = By.xpath("//label[text() ='Decline Reasons:']/../following-sibling::dd/span");
	 public static final By Decision_Accept = By.id("accept01");
	 public static final By Decision_Escalate = By.id("escalate01");
	 public static final By CrossSell_RPL = By.xpath("//lablel[contains(text(), 'Personal Line Of Credit')]/preceding-sibling::input");
	 public static final By CrossSell_PL = By.xpath("//lablel[text()='Personal Loan']/preceding-sibling::input");
	 
	 public static final By Perform_Cross_Sell = By.name("utilScrName");
	 
	 //#####################################################Data Completion####################33
	 public static final By Application_Id_fetch = By.xpath("//span[contains(text(), 'Application ID :')]");
	 
	 public static final By Client_Type = By.id("clientTypeCode");
	 public static final By potentialPEPStatus = By.id("potentialPEPStatus");
	 public static final By sanctionsLinkIndicator = By.id("sanctionsLinkIndicator");
	 public static final By adverseInformation = By.id("adverseInformation");
	 
	 
	 public static final By Marital_Status_Code = By.id("maritalStatusCode");
	 public static final By Mode_Of_Communication = By.id("modeOfCommunication");
	 public static final By Country_Of_Birth = By.id("birthCountry");
	 public static final By Establish_date = By.id("jsCalendarEstablishDate");
	 public static final By Employer_Name = By.id("idEmployerName");
	 public static final By Bussiness_Ownership_Percentage = By.id("bussinessOwnershipPercentage");
	 public static final By HomePhoneNo = By.id("homePhoneNo");
	 
	 //##################################################Bank Use################################3
	 public static final By Channel_Code = By.id("channelCode");
	 public static final By Acquisition_Channel_Code = By.id("acquisitionChannelCode");
	 public static final By Acquisition_Code = By.id("acquisitionCode");
	 
	 
	 //####################################Offer Confirmation#######################################3
	 
	 public static final By Offer_Confirmation = By.xpath("//*[text()='Offer Confirmation']/..");
	 
	 
	 //######################################Documents #####################################
	 public static final By Document_Tab = By.xpath("//*[text()='Documents']/..");
	 
	 public static final By Verification_Tab = By.xpath("//*[text()='Verification']/..");
	 
	 public static final By Customer_Tab = By.xpath("//*[text()='Customer']/..");
	 public static final By Application_Tab = By.xpath("//*[text()='Application']/..");
	 
	 public static final By ICDD_reference_Notification = By.xpath("//*[text()='ICDD VERIFICATION - Notification Status']/../..");
	 public static final By ICDD_reference_Number = By.id("jsicddNo");
	 public static final By Waived_Data_Address = By.id("result[1].subResults[0].waived");
	 public static final By update_Data_Address = By.name("result[1].subResults[0].Updatestatus");
	 
	 public static final By Waived_Data_Employment = By.id("result[2].subResults[0].waived");
	 public static final By update_Data_Employment = By.name("result[2].subResults[0].Updatestatus");
	 
	 public static final By Waived_Data_Telephone = By.id("result[2].subResults[1].waived");
	 public static final By update_Data_Telephone = By.name("result[2].subResults[1].Updatestatus");
	 
	 
	 public static final By KIV = By.xpath("//img[@title='KIV']");
	 
	 public static final By Raise_KIV = By.xpath("//*[text()='Raise KIV']");
	 
	 public static final By KIV_Reason_Code = By.id("//label[contains(text(),'Reason Code')]/../following-sibling::dd//select");
	 public static final By KIV_Department_Id = By.id("departmentID");
	 public static final By KIV_Sub_Department_Id = By.id("subDepartmentID");
	 public static final By KIV_Target_Receipient_1 = By.id("targetrecipient1");
	 public static final By KIV_Target_Receipient_2 = By.id("targetrecipient2");
	 
	 
	 public static final By save_exit = By.name("exit");
	 
	 public static final By Reason_Code = By.id("reasonCode");
	 public static final By process_Exit = By.name("process");
	 
	 public static final By Release = By.name("Release");
	
	//Offer confirmation
	 
	 public static final By Offer_Status = By.xpath("//label[text()='Status:']/../following-sibling::dd/span");
	 
	 public static final By Offer_Appeal = By.name("appealButton");
	 
	 public static final By offer_Accept = By.name("offerSelected");
	 
	 public static final By Credit_Initiation_Assign = By.xpath("//input[@value='Assign to me']");
	 
	 
	 public static final By CI_Offer_With_Condition = By.name("withcheck");
	 
	 public static final By CI_Offer_SubType = By.id("cardSubCardType");
	 public static final By CI_debt_Settlement_Amt = By.id("debtSettlementAmt");
	 public static final By CI_Remodel = By.xpath("(//input[@id='remodel'])[1]");
	 public static final By CI_Approve = By.id("ciDecisionIDAcc1");
	 public static final By CI_Recomended = By.id("ciDecisionIDRecApp");
	 public static final By CI_Reason_Code_Search = By.xpath("//input[@id='approveReasonDisplayNameID']/following-sibling::span/a");
	 
	 public static final By fullfilmentStatus = By.xpath("//*[contains(text(),'Fulfillment Status:')]");
	 
	//property details
	public static final By PROPERTY_DETAILS_EXPAND=By.xpath("text()='Property Details'");
	public static final By PROPERTY_DETAILS_AVAILABLE=By.id("availPropertyFlag");
	public static final By PURCHASE_TYPE=By.id("purchaseTypeCode");
	public static final By USE_OF_PROPERTY=By.id("useOfProperty");
	public static final By PROPERTY_TYPE=By.id("propertyTypeCodeDisplayData");
	public static final By DEVELOPMENT=By.id("developmentCodeDisplayData");
	public static final By DEVELOPER_NAME=By.id("developerCodeDisplayData");
	public static final By GROSS_AREA=By.id("grossArea");
	public static final By NETORSALEABLE_AREA=By.id("netArea");
	public static final By PURCHASE_PRICE=By.id("purchasePrice");
	public static final By NET_PURCHASE_PRICE=By.id("netPurchasePrice");
	public static final By PROPERTY_DETAIL1=By.id("blockNo");
	public static final By PROPERTY_DETAIL2=By.id("buildingNo");
	public static final By PROPERTY_DETAIL3=By.id("pdStreet");
	public static final By PROPERTY_DETAIL4=By.id("district");
	public static final By AREA=By.id("areaCode");
	public static final By COUNTRY=By.id("propertyCountryCode");
	public static final By ZIPCODE=By.id("zipCode");
	public static final By APPURTENANCE=By.id("pdAppurtenance");
	public static final By CARPARKLEVEL=By.id("pdCarParkLevel");
	public static final By CARPARKSPACES=By.id("pdCarParkSpace");
	public static final By SUBSIDY_TYPE=By.id("subsidyType");
	public static final By CONFIRM_OR_DEALFLAG=By.id("lconfirmorDealFlag");
	public static final By DIRECT_DEAL_FLAG=By.id("ldirectDealFlag");
	public static final By LEASE_TERM_EXPIRY_DATE=By.id("pdleaseTermExpireDate");
	//Indicative Validation
	public static final By DATEOFVALUATION=By.id("jsLabelFormat");
	public static final By INDICATIVE_VALUATION_TYPE=By.xpath("//option[text()='-- Please Select --']/..");
	public static final By VALUATION_REF_NO=By.xpath("//label[text()='Valuation Reference Number:']/..//input");
	public static final By VALUATION_AMT_MORTGAGE_PROPERTY=By.xpath("//label[text()='Valuation Amount- Mortgaged property: ']/..//input");
	public static final By VALUATION_AMT_CARPARK1=By.xpath("//label[text()='Valuation Amount- Car Park1:']/..//input");
	public static final By VALUATION_AMT_CARPARK2=By.xpath("//label[text()='Valuation Amount- Car Park2:']/..//input");
	//Product Request
	public static final By PRODUCT_REQUEST=By.xpath("text()='Product Request'");
	public static final By LOAN_CURRENCY_CODE=By.id("currencyCode");
	public static final By REQUESTED_LOAN_AMT=By.id("appliedLoanAmount");
	public static final By REQUEST_TENURE=By.xpath("appliedTenor");
	public static final By FLOATING_LOAN_TYPE=By.xpath("text()='Product Request'");
	public static final By LOAN_PURPOSE=By.xpath("text()='Product Request'");
	public static final By INTEREST_RATE_TYPE=By.xpath("text()='Product Request'");
	public static final By LOAN_REPAYMENT_METHOD=By.xpath("text()='Product Request'");
	public static final By DRAWDOWN_DATE=By.xpath("text()='Product Request'");
	public static final By PRUDENTIAL_MEASURE_EXCEPTION_DSR=By.id("reasonForPMDSR");
	public static final By PRUDENTIAL_MEASURE_EXCEPTION_LTV=By.id("reasonForPMLTV");
	//Lock-In-Period
	public static final By LOCK_IN_PERIOD=By.xpath("text()='Lock-in Period'");
	//Co-Finance
	public static final By COFINANCE_CHECKBOX=By.id("coFinanceFlag");
	public static final By COFINANCE_LOANAMOUNT=By.id("coFinanceLoanAmount");
	public static final By LOAN_REPAYMENT_TENURE=By.name("loanRepaymentTenor");
	public static final By PAYMENT_HOLIDAY=By.name("paymentHoliday");
	public static final By INTEREST_TYPE=By.id("coFinanceInterestType");
	public static final By INTEREST_RATE=By.id("interestRate");
	//scheme_loan
	public static final By SCHEME_LOAN_FLAG=By.id("schemeLoanFlag");
	public static final By SCHEME_LOAN_TYPE_CODE=By.id("schemeLoanTypeCode");
	public static final By SCHEME_LOAN_CATEGORY=By.id("lschemeLoanCategory");
	public static final By SCHEME_LOAN_AMOUNT=By.id("schemeLoanAmount");
	public static final By SCHEME_LOAN_TENOR=By.id("schemeLoanTenor");
	public static final By SCHEME_LOAN_=By.id("schemeLoanIntRate");
	
	public static final By DEDUP_NTB_BUTTON = By.xpath("//input[@value='New to Bank']");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
