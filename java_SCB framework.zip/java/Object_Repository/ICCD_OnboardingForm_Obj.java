package Object_Repository;

import org.openqa.selenium.By;

public class ICCD_OnboardingForm_Obj {
	
	public static final By NAVIGATETOPAGES_MNUONBOARDING = By.xpath("//a[@rel='menu.menu.onboarding']");
	public static final By NAVIGATETOPAGES_CLINTLINK = By.linkText("Client");
	public static final By NAVIGATETOPAGES_RP_INDIVIDUAL	= By.linkText("Related Party - Individual");
	
	// On Boarding form objects
    public static final By OBFORM_CLIENTTYPE 						= By.id("ci_1_nameOfTheCustomer_ci_ci_clientType");
    public static final By OBFORM_RELATIONTYPE 						= By.id("ci_1_nameOfTheCustomer_ci_ci_relationType");
    public static final By OBFORM_ACCOPENING 						= By.id("ci_1_nameOfTheCustomer_ci_countryOfAccountOpening");
    public static final By OBFORM_TITLE 							= By.xpath("//select[@id='ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_title']");
    public static final By OBFORM_FIRSTNAME 						= By.id("ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_firstName");
    public static final By OBFORM_MIDDLENAME 						= By.id("ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_middleName");
    public static final By OBFORM_SURNAME 							= By.id("ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_surname");
    public static final By OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES 	= By.name("customerInfo_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_formerName");
    public static final By OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES2 	= By.name("customerInfo_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_formerName2");
    public static final By OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES3 	= By.name("customerInfo_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_formerName3");
    public static final By OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES4 	= By.name("customerInfo_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_formerName4");
    public static final By OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES5 	= By.name("customerInfo_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_formerName5");
    public static final By OBFORM_SALUTATION 						= By.id("ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_salutation");
    public static final By OBFORM_EMBOSSEDNAME 						= By.id("ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_embossedName");
    public static final By OBFORM_ADDRESSTYPE 						= By.id("ci_4_AddressInformation_ci_addressInformation_customerAddressType_1");
    public static final By OBFORM_ADDLINE1 							= By.id("ci_4_AddressInformation_ci_addressInformation_addressLine1_1");
    public static final By OBFORM_ADDLINE2 							= By.id("ci_4_AddressInformation_ci_addressInformation_addressLine2_1");
    public static final By OBFORM_ADDLINE3 							= By.id("ci_4_AddressInformation_ci_addressInformation_addressLine3_1");
    public static final By OBFORM_CITY1 							= By.id("ci_4_AddressInformation_ci_addressInformation_city_1");
    public static final By OBFORM_COUNTRY1 							= By.id("ci_4_AddressInformation_ci_addressInformation_Country_1");
    public static final By OBFORM_STATE1 							= By.id("ci_4_AddressInformation_ci_addressInformation_state_1");
    public static final By OBFORM_POSTAL1 							= By.id("ci_4_AddressInformation_ci_addressInformation_postalZip_1");
    public static final By OBFORM_ADDRESSTYPE_OFFICE				= By.id("ci_4_AddressInformation_ci_addressInformation_customerAddressType_2");
    public static final By OBFORM_ADDRESS_ADD						= By.xpath("//a[@id='fset_add_link_ci_4_AddressInformation']");
    public static final By OBFORM_OFFICE_ADDLINE1 					= By.id("ci_4_AddressInformation_ci_addressInformation_addressLine1_2");
    public static final By OBFORM_OFFICE_ADDLINE2 					= By.id("ci_4_AddressInformation_ci_addressInformation_addressLine2_2");
    public static final By OBFORM_OFFICE_ADDLINE3 					= By.id("ci_4_AddressInformation_ci_addressInformation_addressLine3_2");
    public static final By OBFORM_OFFICE_CITY1 						= By.id("ci_4_AddressInformation_ci_addressInformation_city_2");
    public static final By OBFORM_OFFICE_COUNTRY1 					= By.id("ci_4_AddressInformation_ci_addressInformation_Country_2");
    public static final By OBFORM_OFFICE_STATE1 					= By.id("ci_4_AddressInformation_ci_addressInformation_state_2");
    public static final By OBFORM_OFFICE_POSTAL1 					= By.id("ci_4_AddressInformation_ci_addressInformation_postalZip_2");
    public static final By OBFORM_PHONETYPE 						= By.id("ci_ci_customerPhoneDetails_ci_ci_phone_phoneType_1");
    public static final By OBFORM_COUNTRYCODE 						= By.id("ci_ci_customerPhoneDetails_ci_ci_phone_countryCode_1");
    public static final By OBFORM_AREACODE 							= By.id("ci_ci_customerPhoneDetails_ci_ci_phone_areaCode_1");
    public static final By OBFORM_PHONEDETAILS 						= By.id("ci_ci_customerPhoneDetails_ci_ci_phone_phoneDetails_1");
    public static final By OBFORM_EMAILTYPE 						= By.id("ci_ci_customerEmailDetails_ci_ci_email_emailType_1");
    public static final By OBFORM_EMAILADDRESS 						= By.id("ci_ci_customerEmailDetails_ci_ci_email_emailAddress_1");
    public static final By OBFORM_IDENTITYDOCTYPE 					= By.id("ci_6_documentInformation_ci_documentInformation_IdentityDocumentType_1");
    public static final By OBFORM_IDENTITYDOCUMENTNUMBER 			= By.id("ci_6_documentInformation_ci_documentInformation_identityDocumentNo_1");
    public static final By OBFORM_EXPIRYDATE 						= By.id("ci_6_documentInformation_ci_documentInformation_documentExpiryDate_1");
    public static final By OBFORM_DOB 								= By.id("ci_7_1_CustomerDetails_ci_customerDetails_DateOfBirth");
    public static final By OBFORM_COB 								= By.id("ci_7_1_CustomerDetails_ci_customerDetails_countryOfBirth");
    public static final By OBFORM_NATIONALITIESORCITIZENSHIPS1 		= By.id("ci_7_1_CustomerDetails_ci_customerDetails_citizenships");
    public static final By OBFORM_NATIONALITIESORCITIZENSHIPS2 		= By.id("ci_7_1_CustomerDetails_ci_customerDetails_citizenships2");
    public static final By OBFORM_NATIONALITIESORCITIZENSHIPS3 		= By.id("ci_7_1_CustomerDetails_ci_customerDetails_citizenships3");
    public static final By OBFORM_NATIONALITIESORCITIZENSHIPS4 		= By.id("ci_7_1_CustomerDetails_ci_customerDetails_citizenships4");
    public static final By OBFORM_NATIONALITIESORCITIZENSHIPS5 		= By.id("ci_7_1_CustomerDetails_ci_customerDetails_citizenships5");
    public static final By OBFORM_GENDER 							= By.id("ci_7_1_CustomerDetails_ci_customerDetails_gender");
    public static final By OBFORM_NATUREOFEMPLOYMENT 				= By.id("ci_8_EmploymentDetails_ci_employmentDetails_natureOfEmployment");
    public static final By OBFORM_OCCUPATION 						= By.id("ci_8_EmploymentDetails_ci_employmentDetails_occupation");
    public static final By OBFORM_INCOME_CURRENCY					= By.id("ci_9_IncomeInformation_common_Currency");
    public static final By OBFORM_INDUSTRY 							= By.id("ci_8_EmploymentDetails_industry_ci_employmentDetails_industry");
    public static final By OBFORM_SAVE 								= By.id("savePartyButton");
    public static final By OBFORM_RESIDENT 							= By.name("customerInfo_ci_10_fatca_ci_fatca_usResident");
    public static final By OBFORM_PERMRESIDENT						= By.name("customerInfo_ci_10_fatca_ci_fatca_permanentResidenceUS");
    public static final By OBFORM_NAMEOFEMPLOYER					= By.name("customerInfo_ci_8_EmploymentDetails_nameOfEmployerUAE_ci_employmentDetails_nameOfEmployerUAE_startsWith");
    public static final By OBFORM_NAMEOFEMPLOYER1					= By.name("customerInfo_ci_8_EmploymentDetails_nameOfEmployerUAE_ci_employmentDetails_nameOfEmployerUAE");
    // Product tab in onboarding

    public static final By OBFORM_PRODUCTNAME 						= By.id("products_productCrossReference_products_pcr_productName_1");
    public static final By OBFORM_SUBPRODUCT 						= By.id("products_productCrossReference_products_pcr_subproduct_1");
    public static final By OBFORM_ACCOUNTCURRENCY 					= By.id("products_productCrossReference_products_pcr_accountCurrency_1");
    public static final By OBFORM_PURPOSEACCOUNTOPENING 			= By.xpath("//input[starts-with(@id,'products_purposeAndReason_products_purpose_purpose_1')]");
    public static final By OBFORM_AMTINIDEPOSIT						= By.name("products_products_initialSource_whole_products_SOF_amountOfInitialDeposit_1");
    public static final By OBFORM_CURRENCY							= By.name("products_products_initialSource_whole_products_SOF_amountOfInitialDepositCurrency_1");
    public static final By OBFORM_PRODUCTTAB 						= By.xpath("//*[@id='tab_c_1']");
    public static final By OBFORM_SUMMARY 							= By.xpath("//*[@id='tab_c_4']");
    public static final By OBFORM_INTERNALINFO 						= By.xpath("//*[@id='tab_c_2']");
    public static final By OBFORM_ACQUISITIONCHANNEL 				= By.name("internalInfo_ii_internalInformation_ii_onboardingChannel");
    public static final By OBFORM_SEGMENT 							= By.name("internalInfo_ii_internalInformation_ii_ii_segment");
    public static final By OBFORM_SUBSEGMENT 						= By.name("internalInfo_ii_internalInformation_ii_ii_subsegment");
    public static final By OBFORM_SUBSEGMENT1						= By.xpath("(//span[text()='Sub-segment']/../../../following-sibling::div//input)[1]");
    public static final By OBFORM_BRANCHCODE						= By.name("internalInfo_ii_internalInformation_ii_ii_branchCode");
    public static final By OBFORM_ARMCODE1							= By.name("internalInfo_ii_internalInformation_arm_code");
    public static final By BOFORM_OWNERID							= By.name("internalInfo_ii_internalInformation_case_owner_id");
    public static final By OBFORM_PARTKEY1							= By.xpath("//span[text()='Party Key:']/../following-sibling::td/span");
    public static final By OBFORM_RELATEDPARTIES 					= By.xpath("//div[contains(text(),'Related Parties')]");
    public static final By OBFORM_SEARCHEXISTING 					= By.xpath("//a[contains(text(),'Search Existing')]");
    public static final By OBFORM_SEARCH 							= By.xpath("//div[contains(text(),'Search')]");
    public static final By OBFORM_BRANCHCODE_HOMEBRANCH 			= By.xpath("//select[@name='internalInfo_ii_internalInformation_ii_ii_branchCode']");
    public static final By OBFORM_ARMCODE 							= By.id("ii_internalInformation_arm_code");
    public static final By OBFORM_EMPRELID 							= By.id("ii_employerRelationshipID_ii_ii_employerRelationship");
    public static final By OBFORM_TOOLS 							= By.id("ii_toolGenerateName_ii_ii_toolToGenerateName");
    public static final By OBFORM_PEPORNOT 							= By.id("ii_suspiciousFlags_ii_sf_potentialPEP");
    public static final By OBFORM_SUSSANCTION 						= By.id("ii_suspiciousFlags_ii_sf_sanctionsLinks");
    public static final By OBFORM_ADVERSEINFO 						= By.id("ii_suspiciousFlags_ii_sf_adverseInformation");
    public static final By OBFORM_PARTYKEY 							= By.xpath("//table[@class='summaryTabOverview']//td[contains(.,'Party Key:')]/following-sibling::td[1]");//("//table[@class='summaryTabOverview']//td[2]");
    public static final By OBFORM_VALIDATE 							= By.id("validatePartyButton");
    public static final By OBFORM_SUBMIT 							= By.id("submitPartyButton");
    public static final By OBFORM_ICDDID 							= By.id("search_PARTY.PARTY_KEY");
    public static final By OBFORM_ICDD 								= By.xpath("//table[@id='clone_H_Head']//a");
    public static final By OBFORM_RELATION_TYPE 					= By.xpath("//select[@id='rp_relatedParties_rp_relationType_1']");
    public static final By OBFORM_RELATEDACCOUNT 					= By.xpath("//select[@id='rp_relatedAccount_rp_relatedAccounts_1']");
    public static final By OBFORM_RELATIONSHIPWITHCLIENT 			= By.xpath("//select[@id='rp_natureOfRelationship_conditional_rp_individual_partyDetails_natureOfRelationship_1']");
    public static final By OBFORM_SAVERELATEDPARTY 					= By.xpath("//div[@id='onboardingActionsDiv']/div[conatins(text(),'Save');");
    public static final By ONBOARDING_SEARCH 						= By.xpath("(//div[contains(text(),'Search')])[1]");
    public static final By ONBOARDING_ICDDID 						= By.id("search_PARTY.PARTY_KEY");
    public static final By OBFORM_PRODUCT_ADD 						= By.xpath("//div[@id='fset_add_products_productCrossReference']/a[contains(text(),'Add')]");
    public static final By OBFORM_FIRST_NAME 						= By.id("sumAns_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_firstName");
    public static final By OBFORM_LAST_NAME 						= By.id("sumAns_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_surname");
    public static final By OBFORM_MIDDLE_NAME 						= By.id("sumAns_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_middleName");
    public static final By RISK_LEVEL_SUMMARY 						= By.xpath("//table[@class='summaryTabOverview']//td[contains(.,'Risk Level')]/following-sibling::td[1]");
    public static final By STP_FLAG_SUMMARY 						= By.xpath("//*[@id='highlightDivContent']//td[contains(.,'STP Flag')]/following-sibling::td[1]");
    public static final By NAME_SCREENING_HIT 						= By.xpath("//*[@id='highlightDivContent']//td[contains(.,'Name Screening Hit')]/following-sibling::td[1]");
    public static final By PROHIBITION 								= By.xpath("//*[@id='highlightDivContent']//td[contains(.,'Prohibition')]/following-sibling::td[1]");
    public static final By ANNUAL_INCOME 							= By.id("ci_9_IncomeInformation_ci_incomeInformation_income"); 
    public static final By SEARCH_RADIO_BUTTON						= By.id("clone");
    public static final By CONVERT_PARTY							= By.id("convertButton");
    public static final By PARTY_TYPE								= By.name("pType");
    public static final By CONTINUE_BOOKING							= By.xpath("//td[contains(text(),'Continue Onboarding >>')]");
    
    
    
    //Norkom
    public static final By Norkom_username							= By.xpath("//input[@name='username']");
    public static final By Norkom_pwd								= By.xpath("//input[@name='password']");
    public static final By Login_button								= By.xpath("//input[@id='screenId']");
    public static final By Notice_Ok_button							= By.xpath("//input[@value='Ok']");
    public static final By Notice_Cancel_button						= By.xpath("//input[@value='Cancel']");
    public static final By CASE_MANAGEMENT_MENU						= By.xpath("//a[text()='Case Management']");
    public static final By ALERT_SEARCH 							= By.xpath("//a[text()='Alert Search']");
    public static final By ALERT_ID_FIELD							= By.xpath("//input[@name='ALERT_IDENTIFIER']");
    public static final By SEARCH_BUTTON							= By.id("Search");
    public static final By ALERT_ACTION								= By.xpath("//a[text()='Alert Action']");
    public static final By WORKFLOW_ACTION							= By.xpath("//select[@name='workflowActionId']");
    public static final By AUDIT_COMMENT							= By.xpath("//textarea[@name='workflowAuditComment']");
    public static final By PERFORM_BUTTON							= By.id("Perform");
    public static final By NAMESCREENING_ALERT_ID					= By.xpath("//div[@id='highlightDivContent']/table/tbody/tr[2]/td[4]");
    
    
    // 
    
    //RP Objects
    
    public static final By RP_COUNTRY_ACCOUNT_OPENING				= By.id("rp_individual_nameOfTheCustomer_ci_countryOfAccountOpening");
    public static final By RP_CASE_OWNER_ID							= By.id("rp_individual_nameOfTheCustomer_case_owner_id");
    public static final By RP_FIRSTNAME								= By.id("rp_individual_nameOfTheCustomer_ci_nameOfTheCustomer_firstName");
    public static final By RP_MIDDLE_NAME							= By.id("rp_individual_nameOfTheCustomer_ci_nameOfTheCustomer_middleName");
    public static final By RP_SURNAME 								= By.id("rp_individual_nameOfTheCustomer_ci_nameOfTheCustomer_surname");
    public static final By RP_ADDRESS_TYPE							= By.id("rp_individual_addressInformation_ci_addressInformation_customerAddressType_1");
    public static final By RP_ADDRESS_LINE_1						= By.id("rp_individual_addressInformation_ci_addressInformation_addressLine1_1");
    public static final By RP_ADDRESS_LINE_2						= By.id("rp_individual_addressInformation_ci_addressInformation_addressLine2_1");
    public static final By RP_ADDRESS_LINE_3						= By.id("rp_individual_addressInformation_ci_addressInformation_addressLine3_1");
    public static final By RP_ADDRESS_CITY							= By.id("rp_individual_addressInformation_ci_addressInformation_city_1");
    public static final By RP_ADDRESS_COUNTRY						= By.id("rp_individual_addressInformation_ci_addressInformation_Country_1");
    public static final By RP_STATE									= By.id("rp_individual_addressInformation_ci_addressInformation_state_1");
    public static final By RP_POSTALCODE 							= By.id("rp_individual_addressInformation_ci_addressInformation_postalZip_1");
    public static final By RP_DOB		 							= By.id("rp_individual_partyDetails_ci_customerDetails_DateOfBirth");
    public static final By RP_NATIONALITIESORCITIZENSHIPS1			= By.id("rp_individual_partyDetails_ci_customerDetails_citizenships");
    public static final By RP_NATIONALITIESORCITIZENSHIPS2 			= By.id("rp_individual_partyDetails_ci_customerDetails_citizenships2");
    public static final By RP_NATIONALITIESORCITIZENSHIPS3 			= By.id("rp_individual_partyDetails_ci_customerDetails_citizenships3");
    public static final By RP_NATIONALITIESORCITIZENSHIPS4 			= By.id("rp_individual_partyDetails_ci_customerDetails_citizenships4");
    public static final By RP_NATIONALITIESORCITIZENSHIPS5 			= By.id("rp_individual_partyDetails_ci_customerDetails_citizenships5");
    public static final By RP_GENDER 								= By.id("rp_individual_partyDetails_ci_customerDetails_gender");
    public static final By RP_SUMMARY_TAB							= By.id("tabTag_1");
    
}
