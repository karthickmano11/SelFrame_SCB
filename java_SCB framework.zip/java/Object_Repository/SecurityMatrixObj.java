package Object_Repository;

import org.openqa.selenium.By;

public class SecurityMatrixObj {
	public static final By Work_items= By.xpath("//div[text()='Work Items']");
	public static final By Home_PAGE_TAB=By.xpath("//a[@rel='menu.menu.homepage']");
	public static final By Home_page_title=By.xpath("//div[text()='Home Page']");
	public static final By Reasearch_tab=By.xpath("//a[@rel='menu.menu.research']");
	public static final By Dart_Under_Reasearch_tab=By.xpath("//a[@rel='menu.menu.investigation']");
	public static final By On_Demand_Reports=By.xpath("//a[@rel='menu.menu.ondemandreports']");
	public static final By Dart_label=By.xpath("//div[text()='DART']");
	public static final By On_Demand_Reports_label=By.xpath("//div[text()='On-Demand Reports']");
	public static final By Reports_Under_WorkBench=By.xpath("//a[@rel='menu.menu.reports']");
	public static final By Reports_Label=By.xpath("//div[@id='rcmHeadlineContainer']");
	public static final By dropdown_icon=By.xpath("//img[@src='images/rcm/panelContainer/Arrow_White.gif']");
	public static final By All_Reports=By.xpath("//div[@title='All Reports']");
	
	public static final By OnBoarding_label=By.xpath("//div[text()='On-Boarding']");
	
	public static final By DashBoard_Tab=By.xpath("//a[@rel='menu.menu.dashboards']");
	
	public static final By More_tab=By.xpath("(//a[@id='icon_default_a'])[1]");
	public static final By View_History =By.xpath("//a[@id='icon_view_history_a']");
	public static final By Close_button=By.xpath("//td[text()='Close']");
	public static final By Close_view_history=By.id("textButton_generalViewAudits_OkButton");
	
	public static final By Export_Icon=By.xpath("//a[@id='icon_export_a']");
	public static final By Export_Option=By.xpath("//a[@id='icon_csv_a']");
	public static final By Print_List=By.xpath("//a[@id='icon_print_list_a']");
	public static final By Send_Mail=By.xpath("//a[@id='icon_mail_a']");
	
	public static final By ICDD_ID_Under_Onboarding=By.id("search_PARTY.PARTY_KEY");
	public static final By Search_Under_Onboarding=By.xpath("//div[text()='Search']");
	
	public static final By View_Notes=By.xpath("//a[@id='icon_view_notes_a']");
	public static final By View_Notes_Label=By.xpath("//div[contains(text(),'View Notes')]");
	
	public static final By View_Attachments=By.xpath("//a[@id='icon_view_attachment_a']");
	public static final By Cancel_button=By.xpath("//span[text()='Cancel']");
	
	public static final By RFI_close=By.id("textButton__CancelButton");
	public static final By Print_list_close=By.id("closeLink");
	public static final By Select_first_checkBox=By.xpath("//table[@id='alertsModel']//tr[2]/td[1]/input");
	
    public static final By Attachment_icon=By.xpath("//a[@id='icon_open_attachments_a']");
    public static final By First_attchment_checkbox=By.xpath("//table[@id='attachmentsDialog_attachmentsGrid']/tbody/tr/td[1]/input");
	public static final By Delete_attachment=By.id("attachmentsDialog_deleteAttachment");
	public static final By Save_attachment=By.id("attachmentsDialog_saveAttachmentsButton");
	public static final By Cancel_attachment=By.id("attachmentsDialog_closeAttachmentsDialogButton");
	
	public static final By Close_View_RFI=By.id("textButton_viewRFI_OkButton");
	
	public static final By Close_Print_details=By.id("closeLink");
	
	public static final By Advance_filter=By.id("icon_advancedFilter");
	public static final By Risk_Level_colomn=By.id("Risk_Level_valuesField");
	public static final By Go_Filter=By.id("textButton__SubmitButton");
	public static final By Exact_Match=By.id("exactMatch");
	public static final By Advance_filter_label=By.id("dialogHeader");
	
	public static final By Advance_filter_Reports=By.id("openAdvancedFilterButton");
	public static final By Report_type=By.id("reportTypeName_valuesField");
	public static final By On_demand_report_label=By.id("rcmHeadlineContainer");
	public static final By status_filter_icon=By.id("statusId_picker");
	public static final By status_filter_ok=By.id("textButton__SubmitButton"); 
	public static final By filter_cancel=By.id("textButton__CancelButton");
	
	
	//satish
	//public static final By View_Notes=By.xpath("//a[@id='icon_view_notes_a']");
    //public static final By View_Notes_Label=By.xpath("//div[contains(text(),'View Notes')]");
    public static final By Add_Attachments= By.xpath("//a[@id='icon_open_attachments_a']");
    //public static final By View_Attachments=By.xpath("//a[@id='icon_view_attachment_a']");
    //public static final By Cancel_button=By.xpath("//span[text()='Cancel']");
    public static final By Attachement_Title = By.xpath("//div[@class='md-toolbar-tools ng-binding']");
    public static final By form_link = By.linkText("Forms");
    public static final By TRR_Add_CDD_link = By.linkText("Trigger Additional CDD");
    public static final By Attachement_GridTable = By.xpath("//table[@id='attachmentsDialog_attachmentsGrid']//tr");
    public static final By RemoveAttachment_Button = By.id("attachmentsDialog_deleteAttachment");
    public static final By SaveAttachment_Button = By.id("attachmentsDialog_saveAttachmentsButton");
    public static final By CancelAttachment_Button = By.id("attachmentsDialog_closeAttachmentsDialogButton");
    public static final By Link_Button = By.id("attachmentsDialog_addLink");
    public static final By attachement_Text = By.id("addLinkTextToDisplayInput");
    public static final By attachment_URL = By.id("addLinkUrlInput");
    public static final By attachment_add = By.id("attachmentsDialog_addLinkConfirmButton");
    public static final By message_delete = By.id("userMessage_button_0");
    public static final By workItem_Title = By.xpath("//span[@class='clsViewChangerTitle']");
    public static final By AddAttachment_Icon = By.xpath("//i[@id='icon_open_attachments']");
    public static final By RemoveAttachment = By.id("textButton_removeAttachmentButton");
    public static final By AddAttachment 	= By.id("textButton_addAttachmentButton");
    public static final By First_Attachment_Chckbx = By.xpath("//table[@id='attachmentModel']/tbody/tr/td[1]/input");
    public static final By viewattachment_Close_button = By.id("textButton_viewAttachments_OkButton");
    public static final By report_checkbox = By.xpath("//table[@class='ui-jqgrid-btable']/tbody/tr[2]/td[1]/input[@role='checkbox']");
    public static final By open_report = By.xpath("//a[@id='icon_report_a']");
    public static final By signoffIcon_report = By.xpath("//a[@id='icon_sign_off_a']");
    public static final By signoffReport_Signoff = By.xpath("//td[@id='textButton_reportSignOff_step0_SubmitButton']");
    public static final By SignoffReport_OkButton = By.xpath("//td[@id='textButton_signOffOkButtonAction']");
    public static final By assign_report = By.xpath("//a[@id='icon_assign_a']");
    public static final By addNotes_reports = By.xpath("//a[@id='icon_add_notes_a']");
    public static final By Addnote_textarea = By.xpath("//textarea[@id='note']");
    public static final By addNotes_Ok_button = By.xpath("//td[@id='textButton__SubmitButton']");
    public static final By viewNotes_reports = By.xpath("//a[@id='icon_view_notes_a']");
    public static final By viewNotesReports_closeButton = By.xpath("//td[@id='textButton_reportViewNotes_OkButton']");
    public static final By onDemand_reports = By.xpath("//a[@id='icon_on_demand_a']");
    public static final By managementreport_Plus_icon = By.xpath("//img[@id='catpref0-plus']");
    public static final By backtoReportlist_icon = By.xpath("//i[@class='icon actions-up_light']");
    public static final By more_button_reports = By.xpath("//a[@id='icon_default_a']");
    public static final By properties_reports = By.xpath("//a[@id='icon_report_info_a']");
    public static final By viewHistory_reports = By.xpath("//a[@id='icon_view_history_a']");
    public static final By ViewHistoryReports_close_button = By.xpath("//td[@id='textButton_generalViewAudits_OkButton']");
    public static final By Reports_Delete= By.xpath("//a[@id='icon_delete_item_a']");
    public static final By AssignReport_save_button = By.id("textButton_AlertUserChange.jsp_SubmitButton");
    public static final By AssignReport_cancel_button = By.id("textButton_AlertUserChange.jsp_CancelButton");
    public static final By AssignReport_Business_chkbox = By.xpath("//input[@type='checkbox']");
    public static final By BizUnit_search = By.id("BUPickerImg");
    public static final By BizUnit_PlusExpand = By.id("webfx-tree-object-2-plus");
    public static final By BizUnit_INStaff = By.id("webfx-tree-object-3-anchor");
    public static final By BizUnit_INSTD = By.id("webfx-tree-object-4-anchor");
    public static final By BizUnit_OK_Button = By.id("textButton__SubmitButton");
    public static final By OpenReport_cancel_button = By.xpath("(//table[@class='clsButton'])[2]/tbody/tr/td[2]");
    		//table[@class='clsButton']/tbody//td[text()='Cancel']");
    
    
    
    
    
    
 
    

}
