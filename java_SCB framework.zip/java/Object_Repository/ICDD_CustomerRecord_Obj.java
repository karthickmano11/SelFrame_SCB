package Object_Repository;

import org.openqa.selenium.By;

public class ICDD_CustomerRecord_Obj {
	

			public static final By CUSTOMER_TAB=By.xpath("//a[@rel='menu.menu.customers']");
			public static final By CUSTOMERSEARCH_CUSTOMERTYPE=By.xpath("//select[@class='filterFormInput']");
			public static final By CUSTOMERSEARCH_SEARCH = By.xpath("//table[@title='Search']//td[2]");
			public static final By CUSTOMERSEARCH_LASTNAME= By.id("lastName");
			public static final By CUSTOMERSEARCH_FIRSTNAME = By.id("firstName");
			public static final By CUSTOMERSEARCH_TIN = By.id("tin");
			public static final By CUSTOMERSEARCH_ACCOUNTNUMBER = By.id("accountNumber");
			public static final By CUSTOMERSEARCH_ICDD_ID = By.id("csn");
			public static final By CUSTOMERSEARCH_ALERTDATE = By.id("alertDate");
			public static final By CUSTOMER_ICM_ID = By.xpath("//td[text()='ICM ID:']/../td[7]");
			public static final By CUSTOMER_PROFILE_TAB	= By.xpath("//td[@class='clsRegTab clsRegTab-center' and contains(.,'Customer Profile')]");
			public static final By KEY_RISK_INDICATOR_TAB= By.xpath("//td[@class='collapserCaption' and contains(.,'Key Risk Indicators')]");
			public static final By PEP_STATUS_ICDD= By.xpath("//*[text()='PEP Status:']/../td[2]");
			public static final By PEP_CATEGORY_ICDD= By.xpath("//*[text()='PEP Category:']/../td[4]");
			public static final By ADVERSE_MEDIA_STATUS_ICDD= By.xpath("//*[text()='Adverse Media Status:']/../td[6]");
			public static final By ADVERSE_MEDIA_SEVERITY_ICDD= By.xpath("//*[text()='Adverse Media Severity:']/../td[8]");
			public static final By SANCTION_STATUS_ICDD= By.xpath("//*[text()='Sanction Status:']/../td[2]");
			public static final By RISK_CODE_DETAILS=By.xpath("//td[@class='collapserCaption' and contains(.,'Risk Code Details')]");  
			public static final By E_VERIFICATION=By.xpath("//td[@class='collapserCaption' and contains(.,'E-Verification')]");
			public static final By HHP=By.xpath("//td[contains(text(),'HHP')]");
			public static final By ONBOARDING=By.xpath("//td[@class='collapserCaption' and contains(.,'On-Boarding')]");
			public static final By ADDITIONAL_DATA=By.xpath("//td[@class='collapserCaption' and contains(.,'Additional Data')]");
			
		// Customer Highlights & Profile
			public static final By ICCD_ID=By.xpath("(//td[text()='ICDD ID:']/../td[3])[1]");
			public static final By CUSTOMER_NAME=By.xpath("//td[text()='Customer Name:']/..//td[5]");
			public static final By RECORD_DATE=By.xpath("//td[text()='Record Date:']/..//td[7]");
			public static final By CUSTOMER_SCORE=By.xpath("//td[text()='Customer Score:']/../td[3]");
			public static final By RISK_RATING=By.xpath("//td[text()='Risk Level:']/../td[5]");
			
			public static final By ALERT_LEVEL_STATUS=By.xpath("//td[text()='Alert Level Status:']/../td[7]");
			public static final By ONBOARDING_STATUS=By.xpath("//td[text()='Onboarding Status:']/../td[3]");
			public static final By APPLICATION_REASON=By.xpath("//td[text()='Application Cancel/Decline Reason:']/../td[5]");
			public static final By CDD_STATUS=By.xpath("//td[text()='CDD Status:']/../td[3]");
			public static final By NEXT_REVIEW_DATE=By.xpath("//td[text()='Next review date:']/../td[5]");
			public static final By TYPE=By.xpath("//*[text()='Type:']/../td[3]");
			public static final By RELATIONSHIP_ACTIVATION_DATE=By.xpath("//*[text()='Relationship Activation Date:']/../td[3]");
			public static final By RELATIONSHIP_CLODES_IND=By.xpath("//*[text()='Relationship Closed Ind:']/../td[3]");
			public static final By PARTY_REFERENCE_ID=By.xpath("//*[text()='Party Reference Id:']/../td[3]");
			public static final By RESIDENTIAL_ADDRESS=By.xpath("//*[text()='Primary Address:']/../td[5]");
			public static final By CITY=By.xpath("//*[text()='City:']/../td[5]");
			public static final By STATE=By.xpath("//*[text()='State:']/../td[5]");
			public static final By COUNTRY=By.xpath("//*[text()='Country:']/../td[5]");
			public static final By EMAIL=By.xpath("//*[text()='Email:']/../td[5]");
			public static final By DOB=By.xpath("//*[text()='DOB:']/../td[5]");
			public static final By CLOSED_DATE=By.xpath("//*[text()='Close Date:']/../td[5]");
			public static final By NATIONALITY=By.xpath("//*[text()='Citizenship:']/../td[7]");
			public static final By FIN_NUM=By.xpath("//*[text()='FIN Num:']/../td[7]");
			public static final By EDUCATION=By.xpath("//*[text()='Education:']/../td[7]");
			public static final By PASSPORT_NUMBER=By.xpath("//*[text()='Passport Number:']/../td[7]");
			public static final By OCCUPATION=By.xpath("//*[text()='Occupation:']/../td[7]");
			public static final By SUB_SEGMENT=By.xpath("//*[text()='Sub-segment:']/../td[7]");
			public static final By CLIENT_TYPE=By.xpath("//*[text()='Client type:']/../td[7]");
			public static final By INDUSTRY=By.xpath("//*[text()='Industry:']/../td[7]");
			
			public static final By PREVIOUS_NAME=By.xpath("//*[text()='Previous Name:']/../td[2]");
			public static final By NATIONALITY1  =By.xpath("//*[text()='Nationalities / Citizenships 1:']/../td[4]");
			public static final By SEGMENT=By.xpath("(//*[text()='Segment:'])[2]/../td[6]");
			public static final By BRANCH_CODE=By.xpath("//*[text()='Branch code / Home branch:']/../td[8]");
			public static final By PREVIOUS_NAME2=By.xpath("//*[text()='Previous Name 2:']/../td[2]");
			public static final By NATIONALITY2=By.xpath("//*[text()='Nationalities / Citizenships 2:']/../td[4]");
			public static final By NATURE_OF_EMPLOYMENT=By.xpath("//*[text()='Nature of Employment (Customer Work Type):']/../td[6]");
			public static final By COUNTRY_OF_BIRTH=By.xpath("//*[text()='Country of Birth:']/../td[8]");
			public static final By ANY_OTHER_NAME_KNOWNBY1=By.xpath("//*[text()='Any other name known by:']/../td[2]");
			public static final By NATIONALITY3=By.xpath("//*[text()='Nationalities / Citizenships 3:']/../td[4]");
			public static final By ARM_CODE=By.xpath("//*[text()='ARM Code:']/../td[6]");
			public static final By US_RESIDENT=By.xpath("//*[text()='U.S. Resident?:']/../td[8]");
			public static final By ANY_OTHER_NAME_KNOWNBY2=By.xpath("//*[text()='Any other name known by 2:']/../td[2]");
			public static final By NATIONALITY4=By.xpath("//*[text()='Nationalities / Citizenships 4:']/../td[4]");
			public static final By NAME_OF_EMPLYER=By.xpath("//*[text()='Name of the Employer:']/../td[6]");
			public static final By US_PERMANENT_RESIDENT_CARD=By.xpath("//*[text()='Holder of a US Permanent Resident Card:']/../td[8]");
			public static final By NATIONALITY5=By.xpath("//*[text()='Nationalities / Citizenships 5:']/../td[4]");
			public static final By EMPLOYEE_ID=By.xpath("//*[text()='Employee ID / PWID:']/../td[6]");
			public static final By DECLARED_ANUUAL_INCOME=By.xpath("//*[text()='Declared Annual Income:']/../td[8]");
			public static final By CLIENT_STATUS=By.xpath("//*[text()='Client Status:']/../td[2]");
			public static final By ACQUISION_CHANNEL=By.xpath("//*[text()='Acquisition Channel:']/../td[4]");
			public static final By PRR_EXEMPTED=By.xpath("//*[text()='PRR Exempted:']/../td[6]");
			public static final By CASE_OWNER_ID=By.xpath("//*[text()='Case Owner Id:']/../td[8]");
			public static final By MINOR=By.xpath("//*[text()='Minor:']/../td[2]");
			
			public static final By NAME_SCREENING_HIT=By.xpath("//*[text()='Name Screening Hit:']/../td[2]");
			public static final By NAME_SCREENING_ALERT=By.xpath("//*[text()='Name Screening Alert(s):']/../td[4]");
		    public static final By MATCH_TRUE_MATCH= By.xpath("//*[text()='Is the match a true match?:']/../td[6]");
		    public static final By TYPE_NAME_SCREENING=By.xpath("//*[text()='Type(s) of Name Screening Match:']/../td[8]");
		    public static final By POTANTIAL_PEP=By.xpath("//*[text()='Potential PEP:']/../td[2]");
		    public static final By POTANTIAL_SANCTIONS=By.xpath("//*[text()='Potential Sanctions:']/../td[4]");
		    public static final By POTANTIAL_ADVERSE_MEDIA=By.xpath("//*[text()='Potential Adverse Media:']/../td[6]");
		    public static final By STP_FLAG=By.xpath("//*[text()='STP Flag:']/../td[8]");
			
			public static final By FINAL_RISK_RATING=By.xpath("//*[text()='Final Risk Rating:']/../td[2]");
			public static final By REASON_FOR_RISK_RATING=By.xpath("//*[text()='Reason for Risk Rating:']/../td[4]");
			public static final By PROHIBITION=By.xpath("//*[text()='Prohibition:']/../td[6]");
			public static final By PROHIBITION_REASON=By.xpath("//*[text()='Prohibition Reason(s):']/../td[8]");
			
			public static final By CRA_RATING=By.xpath("//*[text()='CRA Rating:']/../td[2]");
			public static final By SEGMENT_COUNTRY_OVERRIDE=By.xpath("//*[text()='Segment/Country Override:']/../td[4]");
			public static final By JOINT_ACCOUNT_OVERRIDE=By.xpath("//*[text()='Joint-Account Override:']/../td[6]");
			public static final By RELATED_ENTRY_OVERRIDE=By.xpath("//*[text()='Related Entity Override:']/../td[8]");
			
			public static final By AUM_IN_USD=By.xpath("//*[text()='AUM in USD:']/../td[2]");
			public static final By AUM_IN_LCY=By.xpath("//*[text()='AUM in LCY:']/../td[4]");
			public static final By APPROVED_BORROWING_LIMIT_IN_USD= By.xpath("//*[text()='Approved Borrowing Limit in USD:']/../td[6]");
			public static final By APPROVED_BORROWING_LIMIT_IN_LCY= By.xpath("//*[text()='Approved Borrowing Limit in LCY:']/../td[8]");
			public static final By PEP_STATUS= By.xpath("//*[text()='PEP Status:']/../td[2]");
			public static final By PEP_CATEGORY=By.xpath("//*[text()='PEP Category:']/../td[4]");
			public static final By ADVERSE_MEDIA_STATUS=By.xpath("//*[text()='Adverse Media Status:']/../td[6]");
			public static final By ADVERSE_MEDIA_SEVERITY= By.xpath("//*[text()='Adverse Media Severity:']/../td[8]");
			public static final By SANCTION_STATUS= By.xpath("//*[text()='Sanction Status:']/../td[2]");
			public static final By CLIENT_NET_WORTH_TYPE= By.xpath("//*[text()='Client Net Worth Type:']/../td[4]");
			public static final By SOW_CORROBORATION=By.xpath("//*[text()='SOW Corroboration:']/../td[6]");
			public static final By NTBR=By.xpath("//*[text()='NTBR:']/../td[8]");
			
			public static final By ONBoarding_TYPES=By.xpath("//*[text()='On-Boarding Types']/../following-sibling::tr/following-sibling::tr/td[1]");
			public static final By PRODUCT_RISK=By.xpath("//*[text()='Product Risk']/../following-sibling::tr/following-sibling::tr/td[2]");
			public static final By ACCOUNT_SERVICING=By.xpath("//*[text()='Account Servicing']/../following-sibling::tr/following-sibling::tr/td[3]");
			public static final By BUSINESS_RISK=By.xpath("//*[text()='Business Risk']/../following-sibling::tr/following-sibling::tr/td[4]");
			public static final By CROSS_BORDER_NON_RESIDENCY=By.xpath("//*[text()='Cross Border Non Residency']/../following-sibling::tr/following-sibling::tr/td[5]");
			public static final By INCIDENCE_OF_FINANCIAL_CRIME=By.xpath("//*[text()='Incidence of Financial Crime']/../following-sibling::tr/following-sibling::tr/td[6]");
			public static final By SCB_COUNTRY=By.xpath("//*[text()='SCB Country']/../following-sibling::tr/following-sibling::tr/td[7]");
			public static final By PEP_STATUS1=By.xpath("//*[text()='PEP Status']/../following-sibling::tr/following-sibling::tr/td[8]");
			public static final By SANCTION_CONNECTIONS=  By.xpath("//*[text()='Sanctions Connections']/../following-sibling::tr/following-sibling::tr/td[9]");
			public static final By LENGTH_OF_RELATIONSHIP=By.xpath("//*[text()='Length of Relationship']/../following-sibling::tr/following-sibling::tr/td[10]");
			public static final By ADVERSE_INFORMATION=By.xpath("//*[text()='Adverse Information']/../following-sibling::tr/following-sibling::tr/td[11]");
			public static final By FCC_RISK_EVENT=By.xpath("//*[text()='FCC Risk Events']/../following-sibling::tr/following-sibling::tr/td[12]");
			public static final By QUALITY_OF_REGULATION=By.xpath("//*[text()='Quality of Regulation']/../following-sibling::tr/following-sibling::tr/td[13]");
			
			public static final By PROHIBITION_BASED_ON_STATIC_DATA=By.xpath("//*[text()='Direct prohibition based on available static data']/../following-sibling::tr/following-sibling::tr/td[1]");
			public static final By PROHIBITION_BASED_ON_NAME_SCREENING=By.xpath("//*[text()='Prohibition based on name screening']/../following-sibling::tr/following-sibling::tr/td[2]");
			public static final By PROHIBITION_BASED_ON_MULTIPLE_SAR=By.xpath("//*[text()='Prohibition based on multiple SAR filed']/../following-sibling::tr/following-sibling::tr/td[3]");
			public static final By PROHIBITION_BASED_ON_PROHIBITED_INDUSTRY=By.xpath("//*[text()='Prohibition based on prohibited Industry in SOW']/../following-sibling::tr/following-sibling::tr/td[4]");
			public static final By PROHIBITION_BASED_ON_SOW=By.xpath("//*[text()='Prohibition based on SOW(Source of wealth)']/../following-sibling::tr/following-sibling::tr/td[5]");
			public static final By COUNTRY_PROHIBITION=By.xpath("//*[text()='Country Prohibition']/../following-sibling::tr/following-sibling::tr/td[6]");
			public static final By PROHIBITION_BASED_ON_RISK_RATING=By.xpath("//*[text()='Prohibition Based on Risk Rating from CRA']/../following-sibling::tr/following-sibling::tr/td[7]");
			
			public static final By TRIGGER_IS_SAR=By.xpath("//*[text()='IS SAR']/../following-sibling::tr/following-sibling::tr/td[1]");
			public static final By TRIGGER_IS_NCT=By.xpath("//*[text()='IS NCT']/../following-sibling::tr/following-sibling::tr/td[2]");
			public static final By TRIGGER_IS_DENY_BUSINESS=By.xpath("//*[text()='IS DENY BUSINESS']/../following-sibling::tr/following-sibling::tr/td[3]");
			public static final By TRIGGER_IS_CONF_ADV_MEDIA=By.xpath("//*[text()='IS CONF ADV Media']/../following-sibling::tr/following-sibling::tr/td[4]");
			public static final By TRIGGER_CHANGE_TO_HNW=By.xpath("//*[text()='Change to HNW/UHNW']/../following-sibling::tr/following-sibling::tr/td[5]");
			public static final By RP_PROHIBITION=By.xpath("//*[text()='RP Prohibition']/../following-sibling::tr/following-sibling::tr/td[6]");
			public static final By RP_NAMESCREEN=By.xpath("//*[text()='RP NameScreen']/../following-sibling::tr/following-sibling::tr/td[7]");
			public static final By CHANGE_TO_NON_RESIDENCY=By.xpath("//*[text()='Change to Non-Resident']/../following-sibling::tr/following-sibling::tr/td[8]");
			
			public static final By SELF_RESTRICTION_BENF_OWNER=By.xpath("//*[text()='Benf Owner (>=25%) of an entity existing in SCB']/../following-sibling::tr/following-sibling::tr/td[1]");
			public static final By SELF_RESTRICTION_ADVERSE_MEDIA=By.xpath("//*[text()='Adverse media against the entity']/../following-sibling::tr/following-sibling::tr/td[2]");
			public static final By SELF_RESRTICTION_UNDULY_COMPLEX=By.xpath("//*[text()='Unduly complex structure']/../following-sibling::tr/following-sibling::tr/td[3]");
			public static final By SELF_RESTRICTION_SENSITIVE=By.xpath("//*[text()='Dealing in Prohibited / sensitive industry']/../following-sibling::tr/following-sibling::tr/td[4]");
			public static final By SELF_RESTRICTION_HIGH_RISK_COUNTRY=By.xpath("//*[text()='Links to PEP from a Very High Risk Country']/../following-sibling::tr/following-sibling::tr/td[5]");
			
			public static final By CUSTOMER_ADDRESS_TYPE=By.xpath("(//*[text()='Type'])[1]/../following-sibling::tr/following-sibling::tr/td[1]");
			public static final By CUSTOMER_ADDRESS=By.xpath("//*[text()='Address']/../following-sibling::tr/following-sibling::tr/td[2]");
			public static final By CUSTOMER_COUNTRY=By.xpath("//*[text()='Country']/../following-sibling::tr/following-sibling::tr/td[3]");
			public static final By CUSTOMER_STATE=By.xpath("//*[text()='State']/../following-sibling::tr/following-sibling::tr/td[4]");
			public static final By CUSTOMER_PO_BOX=By.xpath("//*[text()='PO Box']/../following-sibling::tr/following-sibling::tr/td[5]");
			public static final By CUSTOMER_POSTAL_CODE=By.xpath("//*[text()='Postal/Zip code']/../following-sibling::tr/following-sibling::tr/td[6]");
			public static final By CUSTOMER_RETURN_MAIL_FALG=By.xpath("//*[text()='Return mail flag (Address Invalid indicator)']/../following-sibling::tr/following-sibling::tr/td[7]");
			
			public static final By PHONE_TYPE=By.xpath("((//*[text()='Type'])[2]/../following-sibling::tr/following-sibling::tr/td[1])[1]");
			public static final By PHONE_TYPE1=By.xpath("((//*[text()='Type'])[2]/../following-sibling::tr/following-sibling::tr/td[1])[2]");
			public static final By ISD_CODE=By.xpath("(//*[text()='ISD Code']/../following-sibling::tr/following-sibling::tr/td[2])[1]");
			public static final By ISD_CODE1=By.xpath("(//*[text()='ISD Code']/../following-sibling::tr/following-sibling::tr/td[2])[2]");
			public static final By PHONE=By.xpath("(//*[text()='Phone']/../following-sibling::tr/following-sibling::tr/td[3])[1]");
			public static final By PHONE1=By.xpath("(//*[text()='Phone']/../following-sibling::tr/following-sibling::tr/td[3])[2]");
			
			public static final By EMAIL_ADDRESS_TYPE=By.xpath("((//*[text()='Type'])[3]/../following-sibling::tr/following-sibling::tr/td[1])[1]");
			public static final By EMAIL_ADDRESS_TYPE1=By.xpath("((//*[text()='Type'])[3]/../following-sibling::tr/following-sibling::tr/td[1])[2]");
			public static final By EMAIL_ADDRESS_EMAIL=By.xpath("(//*[text()='Email']/../following-sibling::tr/following-sibling::tr/td[2])[1]");
			public static final By EMAIL_ADDRESS_EMAIL1=By.xpath("//td[contains(text(),'EM1')]/../td[2]");
			
			public static final By DOCUMENT_REQUIRMENT=By.xpath("//*[text()='Requirement']/../following-sibling::tr/following-sibling::tr/td[1]");
			public static final By DOCUMENT_PRIORITY=By.xpath("//*[text()='Priority']/../following-sibling::tr/following-sibling::tr/td[2]");
			public static final By DOCUMENT_STATUS=By.xpath("//*[text()='Status']/../following-sibling::tr/following-sibling::tr/td[3]");
			public static final By DOCUMENT_DUE_DATE=By.xpath("//*[text()='Due Date']/../following-sibling::tr/following-sibling::tr/td[4]");
			public static final By DOCUMENT_TYPE=By.xpath("//*[text()='Document Type']/../following-sibling::tr/following-sibling::tr/td[5]");
			public static final By DOCUMENT_NUMBER=By.xpath("//*[text()='Document Number']/../following-sibling::tr/following-sibling::tr/td[6]");
			public static final By DOCUMENT_ISSUER=By.xpath("//*[text()='Issuer']/../following-sibling::tr/following-sibling::tr/td[7]");
			public static final By DOCUMENT_ISSUE_DATE=By.xpath("//*[text()='Issue Date']/../following-sibling::tr/following-sibling::tr/td[8]");
			public static final By DOCUMENT_ISSUE_COUNTRY=By.xpath("//*[text()='Issue Country']/../following-sibling::tr/following-sibling::tr/td[9]");
			public static final By DOCUMENT_EXPITY_DATE=By.xpath("//*[text()='Document Expiry Date']/../following-sibling::tr/following-sibling::tr/td[10]");
			public static final By DOCUMENT_ALTERNATIVE_APPLIED=By.xpath("//*[text()='Alternative Applied']/../following-sibling::tr/following-sibling::tr/td[11]");
			public static final By DOCUMENT_DETAILS=By.xpath("//*[text()='Details']/../following-sibling::tr/following-sibling::tr/td[12]");
			
			public static final By ACCOUNT_TAB=By.xpath("//td[contains(text(),'Account Profile')]");
			public static final By ACCOUNT_TYPE=By.xpath("//*[text()='Account Type']/../following-sibling::tr/td[1]");
			public static final By ACCOUNT_TYPE_DESCRIPTION=By.xpath("//*[text()='Account Type Description']/../following-sibling::tr/td[2]");
		    public static final By NUMBER_OF_ACCOUNT=By.xpath("//*[text()='Number of Accounts']/../following-sibling::tr/td[3]");
		    public static final By NUMBER_OF_ALL_ACCOUNTS=By.xpath("//*[text()='Number of all Accounts']/../th[2]");
		    
		    
		    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT=By.xpath("(//*[text()='Client Relationship to Account:'])[1]/../td[3]");
			public static final By PRODUCT=By.xpath("(//*[text()='Product:'])[1]/../td[3]");
		    public static final By ACCOUNT_OPENING_CHANNEL=By.xpath("(//*[text()='Account Opening Channel:'])[1]/../td[3]");
		    public static final By FEDERAL_TAX=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[1]/../td[3]");
		    public static final By ACCOUNT_OPEN_DATE=By.xpath("(//*[text()='Open Date:'])[1]/../td[3]");
		    public static final By ACCOUNT_ACTIVE=By.xpath("(//*[text()='Account Active:'])[1]/../span[2]");
		    public static final By ACCCOUNT_SUBPRODUCT=By.xpath("(//*[text()='Sub-product Code:'])[1]/../td[5]");
		    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION=By.xpath("(//*[text()='Sub-product Description:'])[1]/../td[5]");
		    public static final By ACCOUNT_BRANCH=By.xpath("(//*[text()='Branch:'])[1]/../td[5]");
		    public static final By ACCOUNT_BRANCH_PHONE=By.xpath("(//*[text()='Branch Phone:'])[1]/../td[5]");
		    public static final By ACCOUNT_OFFICER=By.xpath("(//*[text()='Officer#:'])[1]/../td[5]");
		    public static final By ACCOUNT_OFFICER_NAME=By.xpath("(//*[text()='Officer Name:'])[1]/../td[5]");
		    public static final By ACCOUNT_CURRENCY=By.xpath("(//*[text()='Account Currency'])[1]/../td[3]");
		    public static final By PURPOSE_REASON_RELATIONSHIP=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[1]/../td[3]");
		    public static final By INITIAL_FUNDING=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[1]/../td[3]");
		    public static final By SOURCE_INITIAL_FUNDING=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[1]/../td[3]");
		    public static final By ACCOUNT_NUMBER=By.xpath("(//*[text()='Account Number'])[1]/../td[5]");
		    public static final By APPLIED_LIMIT=By.xpath("(//*[text()='Applied Limit (with currency)'])[1]/../td[5]");
		    public static final By INITIAL_DEPOSIT=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[1]/../td[5]");
		    public static final By COUNTRY_INITIAL_FUNDING=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[1]/../td[5]");
		    public static final By ACCOUNT_STATUS=By.xpath("(//*[text()='Account Status'])[1]/../td[7]");    
		    public static final By BORROWING_LIMIT=By.xpath("(//*[text()='Borrowing Limit (USD)'])[1]/../td[7]");
		    public static final By TYPE_INITIAL_FUNDING=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[1]/../td[7]");
		   
		    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT2=By.xpath("(//*[text()='Client Relationship to Account:'])[2]/../td[3]");
			public static final By PRODUCT2=By.xpath("(//*[text()='Product:'])[2]/../td[3]");
		    public static final By ACCOUNT_OPENING_CHANNEL2=By.xpath("(//*[text()='Account Opening Channel:'])[2]/../td[3]");
		    public static final By FEDERAL_TAX2=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[2]/../td[3]");
		    public static final By ACCOUNT_OPEN_DATE2=By.xpath("(//*[text()='Open Date:'])[2]/../td[3]");
		    public static final By ACCOUNT_ACTIVE2=By.xpath("(//*[text()='Account Active:'])[2]/../span[2]");
		    public static final By ACCCOUNT_SUBPRODUCT2=By.xpath("(//*[text()='Sub-product Code:'])[2]/../td[5]");
		    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION2=By.xpath("(//*[text()='Sub-product Description:'])[2]/../td[5]");
		    public static final By ACCOUNT_BRANCH2=By.xpath("(//*[text()='Branch:'])[2]/../td[5]");
		    public static final By ACCOUNT_BRANCH_PHONE2=By.xpath("(//*[text()='Branch Phone:'])[2]/../td[5]");
		    public static final By ACCOUNT_OFFICER2=By.xpath("(//*[text()='Officer#:'])[2]/../td[5]");
		    public static final By ACCOUNT_OFFICER_NAME2=By.xpath("(//*[text()='Officer Name:'])[2]/../td[5]");
		    public static final By ACCOUNT_CURRENCY2=By.xpath("(//*[text()='Account Currency'])[2]/../td[3]");
		    public static final By PURPOSE_REASON_RELATIONSHIP2=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[2]/../td[3]");
		    public static final By INITIAL_FUNDING2=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[2]/../td[3]");
		    public static final By SOURCE_INITIAL_FUNDING2=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[2]/../td[3]");
		    public static final By ACCOUNT_NUMBER2=By.xpath("(//*[text()='Account Number'])[2]/../td[5]");
		    public static final By APPLIED_LIMIT2=By.xpath("(//*[text()='Applied Limit (with currency)'])[2]/../td[5]");
		    public static final By INITIAL_DEPOSIT2=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[2]/../td[5]");
		    public static final By COUNTRY_INITIAL_FUNDING2=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[2]/../td[5]");
		    public static final By ACCOUNT_STATUS2=By.xpath("(//*[text()='Account Status'])[2]/../td[7]");    
		    public static final By BORROWING_LIMIT2=By.xpath("(//*[text()='Borrowing Limit (USD)'])[2]/../td[7]");
		    public static final By TYPE_INITIAL_FUNDING2=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[2]/../td[7]");
		    
		    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT3=By.xpath("(//*[text()='Client Relationship to Account:'])[3]/../td[3]");
			public static final By PRODUCT3=By.xpath("(//*[text()='Product:'])[3]/../td[3]");
		    public static final By ACCOUNT_OPENING_CHANNEL3=By.xpath("(//*[text()='Account Opening Channel:'])[3]/../td[3]");
		    public static final By FEDERAL_TAX3=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[3]/../td[3]");
		    public static final By ACCOUNT_OPEN_DATE3=By.xpath("(//*[text()='Open Date:'])[3]/../td[3]");
		    public static final By ACCOUNT_ACTIVE3=By.xpath("(//*[text()='Account Active:'])[3]/../span[2]");
		    public static final By ACCCOUNT_SUBPRODUCT3=By.xpath("(//*[text()='Sub-product Code:'])[3]/../td[5]");
		    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION3=By.xpath("(//*[text()='Sub-product Description:'])[3]/../td[5]");
		    public static final By ACCOUNT_BRANCH3=By.xpath("(//*[text()='Branch:'])[3]/../td[5]");
		    public static final By ACCOUNT_BRANCH_PHONE3=By.xpath("(//*[text()='Branch Phone:'])[3]/../td[5]");
		    public static final By ACCOUNT_OFFICER3=By.xpath("(//*[text()='Officer#:'])[3]/../td[5]");
		    public static final By ACCOUNT_OFFICER_NAME3=By.xpath("(//*[text()='Officer Name:'])[3]/../td[5]");
		    public static final By ACCOUNT_CURRENCY3=By.xpath("(//*[text()='Account Currency'])[1]/../td[3]");
		    public static final By PURPOSE_REASON_RELATIONSHIP3=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[3]/../td[3]");
		    public static final By INITIAL_FUNDING3=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[3]/../td[3]");
		    public static final By SOURCE_INITIAL_FUNDING3=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[3]/../td[3]");
		    public static final By ACCOUNT_NUMBER3=By.xpath("(//*[text()='Account Number'])[3]/../td[5]");
		    public static final By APPLIED_LIMIT3=By.xpath("(//*[text()='Applied Limit (with currency)'])[3]/../td[5]");
		    public static final By INITIAL_DEPOSIT3=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[3]/../td[5]");
		    public static final By COUNTRY_INITIAL_FUNDING3=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[3]/../td[5]");
		    public static final By ACCOUNT_STATUS3=By.xpath("(//*[text()='Account Status'])[3]/../td[7]");    
		    public static final By BORROWING_LIMIT3=By.xpath("(//*[text()='Borrowing Limit (USD)'])[3]/../td[7]");
		    public static final By TYPE_INITIAL_FUNDING3=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[3]/../td[7]");
		    
		    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT4=By.xpath("(//*[text()='Client Relationship to Account:'])[4]/../td[3]");
			public static final By PRODUCT4=By.xpath("(//*[text()='Product:'])[4]/../td[3]");
		    public static final By ACCOUNT_OPENING_CHANNEL4=By.xpath("(//*[text()='Account Opening Channel:'])[4]/../td[3]");
		    public static final By FEDERAL_TAX4=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[4]/../td[3]");
		    public static final By ACCOUNT_OPEN_DATE4=By.xpath("(//*[text()='Open Date:'])[4]/../td[3]");
		    public static final By ACCOUNT_ACTIVE4=By.xpath("(//*[text()='Account Active:'])[4]/../span[2]");
		    public static final By ACCCOUNT_SUBPRODUCT4=By.xpath("(//*[text()='Sub-product Code:'])[4]/../td[5]");
		    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION4=By.xpath("(//*[text()='Sub-product Description:'])[4]/../td[5]");
		    public static final By ACCOUNT_BRANCH4=By.xpath("(//*[text()='Branch:'])[4]/../td[5]");
		    public static final By ACCOUNT_BRANCH_PHONE4=By.xpath("(//*[text()='Branch Phone:'])[4]/../td[5]");
		    public static final By ACCOUNT_OFFICER4=By.xpath("(//*[text()='Officer#:'])[4]/../td[5]");
		    public static final By ACCOUNT_OFFICER_NAME4=By.xpath("(//*[text()='Officer Name:'])[4]/../td[5]");
		    public static final By ACCOUNT_CURRENCY4=By.xpath("(//*[text()='Account Currency'])[4]/../td[3]");
		    public static final By PURPOSE_REASON_RELATIONSHIP4=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[4]/../td[3]");
		    public static final By INITIAL_FUNDING4=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[4]/../td[3]");
		    public static final By SOURCE_INITIAL_FUNDING4=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[4]/../td[3]");
		    public static final By ACCOUNT_NUMBER4=By.xpath("(//*[text()='Account Number'])[4]/../td[5]");
		    public static final By APPLIED_LIMIT4=By.xpath("(//*[text()='Applied Limit (with currency)'])[4]/../td[5]");
		    public static final By INITIAL_DEPOSIT4=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[4]/../td[5]");
		    public static final By COUNTRY_INITIAL_FUNDING4=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[4]/../td[5]");
		    public static final By ACCOUNT_STATUS4=By.xpath("(//*[text()='Account Status'])[4]/../td[7]");    
		    public static final By BORROWING_LIMIT4=By.xpath("(//*[text()='Borrowing Limit (USD)'])[4]/../td[7]");
		    public static final By TYPE_INITIAL_FUNDING4=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[4]/../td[7]");
		    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT5=By.xpath("(//*[text()='Client Relationship to Account:'])[5]/../td[3]");
			
		    public static final By PRODUCT5=By.xpath("(//*[text()='Product:'])[5]/../td[3]");
		    public static final By ACCOUNT_OPENING_CHANNEL5=By.xpath("(//*[text()='Account Opening Channel:'])[5]/../td[3]");
		    public static final By FEDERAL_TAX5=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[5]/../td[3]");
		    public static final By ACCOUNT_OPEN_DATE5=By.xpath("(//*[text()='Open Date:'])[5]/../td[3]");
		    public static final By ACCOUNT_ACTIVE5=By.xpath("(//*[text()='Account Active:'])[5]/../span[2]");
		    public static final By ACCCOUNT_SUBPRODUCT5=By.xpath("(//*[text()='Sub-product Code:'])[5]/../td[5]");
		    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION5=By.xpath("(//*[text()='Sub-product Description:'])[5]/../td[5]");
		    public static final By ACCOUNT_BRANCH5=By.xpath("(//*[text()='Branch:'])[5]/../td[5]");
		    public static final By ACCOUNT_BRANCH_PHONE5=By.xpath("(//*[text()='Branch Phone:'])[5]/../td[5]");
		    public static final By ACCOUNT_OFFICER5=By.xpath("(//*[text()='Officer#:'])[5]/../td[5]");
		    public static final By ACCOUNT_OFFICER_NAME5=By.xpath("(//*[text()='Officer Name:'])[5]/../td[5]");
		    public static final By ACCOUNT_CURRENCY5=By.xpath("(//*[text()='Account Currency'])[5]/../td[3]");
		    public static final By PURPOSE_REASON_RELATIONSHIP5=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[5]/../td[3]");
		    public static final By INITIAL_FUNDING5=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[5]/../td[3]");
		    public static final By SOURCE_INITIAL_FUNDING5=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[5]/../td[3]");
		    public static final By ACCOUNT_NUMBER5=By.xpath("(//*[text()='Account Number'])[5]/../td[5]");
		    public static final By APPLIED_LIMIT5=By.xpath("(//*[text()='Applied Limit (with currency)'])[5]/../td[5]");
		    public static final By INITIAL_DEPOSIT5=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[5]/../td[5]");
		    public static final By COUNTRY_INITIAL_FUNDING5=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[5]/../td[5]");
		    public static final By ACCOUNT_STATUS5=By.xpath("(//*[text()='Account Status'])[5]/../td[7]");    
		    public static final By BORROWING_LIMIT5=By.xpath("(//*[text()='Borrowing Limit (USD)'])[5]/../td[7]");
		    public static final By TYPE_INITIAL_FUNDING5=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[5]/../td[7]");
		    
		    
		    public static final By ONBOARDING_QUESTION_TAB=By.xpath("//td[contains(text(),'Onboarding Questions')]");
		    public static final By CLIENT=By.xpath("//*[@id='sumAns_ci_1_nameOfTheCustomer_ci_ci_clientType']");
		    public static final By COUNTRY_ACCOUNT_OPENING=By.xpath("//*[@id='sumAns_ci_1_nameOfTheCustomer_ci_countryOfAccountOpening']");
		    public static final By NAME_OF_CUSTOMER=By.xpath("//*[@id='sumAns_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_label']");
		    public static final By TITLE=By.xpath("//*[@id='sumAns_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_title']");
			public static final By FIRST_NAME=By.xpath("//*[@id='sumAns_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_firstName']");
			public static final By SURNAME_NT_AVAILABLE=By.xpath("//*[@id='sumAns_ci_1_nameOfTheCustomer_ci_nameOfTheCustomer_wosurname']");
			public static final By ADDRESS_TYPE=By.xpath("//*[@id='sumAns_ci_4_AddressInformation_ci_addressInformation_customerAddressType_1']");
			public static final By ADDRESS_LINE1=By.xpath("//*[@id='sumAns_ci_4_AddressInformation_ci_addressInformation_addressLine1_1']");
			public static final By ADDRESS_LINE2=By.xpath("//*[@id='sumAns_ci_4_AddressInformation_ci_addressInformation_addressLine2_1']");
			public static final By ADDRESS_CITY=By.xpath("//*[@id='sumAns_ci_4_AddressInformation_ci_addressInformation_city_1']");
			public static final By ADDRESS_COUNTRY=By.xpath("//*[@id='sumAns_ci_4_AddressInformation_ci_addressInformation_Country_1']");
			public static final By ADDRESS_STATE=By.xpath("//*[@id='sumAns_ci_4_AddressInformation_ci_addressInformation_state_1']");
			public static final By CONTACT_PHONE_DETAILS=By.xpath("//*[@id='sumAns_ci_ci_customerPhoneDetails_ci_ci_phone_label_0']");
			public static final By CONATCT_EMAIL_DETAILS=By.xpath("//*[@id='sumAns_ci_ci_customerEmailDetails_ci_ci_email_label_0']");
			public static final By DOCUMENT_INFORMATION=By.xpath("//*[@id='sumAns_ci_6_documentInformation_ci_documentInformation_label_0']");
			public static final By CUSTOMER_DOB=By.xpath("//*[@id='sumAns_ci_7_1_CustomerDetails_ci_customerDetails_DateOfBirth']");
			public static final By CUSTOMER_COUNTRY_OFBIRTH=By.xpath("//*[@id='sumAns_ci_7_1_CustomerDetails_ci_customerDetails_countryOfBirth']");
			public static final By CUSTOMER_NATIONALITY1=By.xpath("//*[@id='sumAns_ci_7_1_CustomerDetails_ci_customerDetails_citizenships']");
			public static final By CUSTOMER_NATIONALITY2=By.xpath("//*[@id='sumAns_ci_7_1_CustomerDetails_ci_customerDetails_citizenships2']");
			public static final By GENDER=By.xpath("//*[@id='sumAns_ci_7_1_CustomerDetails_ci_customerDetails_gender']");
			public static final By EMPLOYMENT_NATURE_OF_EMPLOYMENT=By.xpath("//*[@id='sumAns_ci_8_EmploymentDetails_ci_employmentDetails_natureOfEmployment']");
			public static final By EMPLOYMENT_OCCUPATION=By.xpath("//*[@id='sumAns_ci_8_EmploymentDetails_ci_employmentDetails_occupation']");
			public static final By INCOME_CURRENCY=By.xpath("//*[@id='sumAns_ci_9_IncomeInformation_common_Currency']");
			public static final By FATCA_US_RESIDENT=By.xpath("//*[@id='sumAns_ci_10_fatca_ci_fatca_usResident']");
			public static final By FATCA_PER_US_RESIDENT=By.xpath("//*[@id='sumAns_ci_10_fatca_ci_fatca_permanentResidenceUS']");
			public static final By DOMICILE_COUNTRY_CODE=By.xpath("//*[@id='sumAns_ci_ci_domicileCountrySet_ci_hiddenDummy_domicileCountryCd']");
			public static final By INTERNAL_SEGMENT=By.xpath("//*[@id='sumAns_ii_internalInformation_ii_ii_segment']");
			public static final By INTERNAL_BRANCHCODE=By.xpath("//*[@id='sumAns_ii_internalInformation_ii_ii_branchCode']");
			public static final By INTERNAL_ARM_CODE=By.xpath("//*[@id='sumAns_ii_internalInformation_arm_code']");
			public static final By SUSPICIOUS_FLAG=By.xpath("//*[@id='sumAns_ii_suspiciousFlags_ii_sf_label']");
			public static final By SELF_RESTRICTION_CHK=By.xpath("//*[@id='sumAns_ci_11_eBundle_ci_eBundle_label']");
			
			//verify alert
			public static final By CUSTOMER_ALERT=By.xpath("//td[text()='Customer Alerts']");
			
		    public static final By CUSTOMERSEARCH_SEARCHEDLINK     = By.xpath("//table[@class='clsGridTableBase']/tbody/tr[3]/td[1]//a");
		    public static final By CUSTOMERDATA_ACTIVE             = By.xpath("//table[@class='clsGridTableBase']/tbody/tr[3]/td[2]//span/span");
		    public static final By CUSTOMERDATA_TIN                = By.xpath("//table[@class='clsGridTableBase']/tbody/tr[3]/td[3]//span/span");
		    public static final By CUSTOMERDATA_CUSTOMERNAME       = By.xpath("//table[@class='clsGridTableBase']/tbody/tr[3]/td[4]//span//a");
		    public static final By CUSTOMERDATA_CUSTOMERTYPE       = By.xpath("//table[@class='clsGridTableBase']/tbody/tr[3]/td[5]//span/span");
		    public static final By CUSTOMERDATA_RISK_SCORE         = By.xpath("//table[@class='clsGridTableBase']/tbody/tr[3]/td[6]//span/span");
		    public static final By CUSTOMERDATA_TOTAL_ROWS         = By.xpath("//table[@class='clsGridTableBase']/tbody/tr[3]");
		    
		    
		    public static final By TOTAL_RECORD                    = By.xpath("(//table[@id='alertsModel']//tr)[2]");
		    public static final By ITEM_TYPE					   = By.xpath("//td[contains(@aria-describedby,'alertsModel_alertTypeShortName')]");
		    public static final By RISK_LEVEL					   = By.xpath("//td[contains(@aria-describedby,'alertsModel_Risk Level')]");
		    public static final By BUSINESS_UNIT				   = By.xpath("//td[contains(@aria-describedby,'alertsModel_businessUnitName')]");
		    public static final By ITEM_DATE					   = By.xpath("//td[contains(@aria-describedby,'alertsModel_alertDate')]");
		    public static final By PART_KEY						   = By.xpath("//td[contains(@aria-describedby,'alertsModel_PartyKey')]");
		    public static final By CLIENT_NAME                     = By.xpath("//td[contains(@aria-describedby,'alertsModel_cdev_fullNameOfClient')]");
		    public static final By ICM_ID						   = By.xpath("//td[contains(@aria-describedby,'alertsModel_ICM ID')]");    
		    public static final By RELATIONSHIP_ID				   = By.xpath("//td[contains(@aria-describedby,'alertsModel_IMPL_REL_ID')]");
		    public static final By OWNER_ID                        = By.xpath("//td[contains(@aria-describedby,'alertsModel_case_owner_id')]");
		    public static final By LAST_REVIEW_DATE                = By.xpath("//td[contains(@aria-describedby,'alertsModel_LastReviewDate')]");
		    public static final By ORIGINAL_ALERTDATE              = By.xpath("//td[contains(@aria-describedby,'alertsModel_OriginalAlertDate')]");
		    
		    
		    public static final By WORKFLOW_TEXTROWS= By.xpath("//span[@id='rcm-tasklist-edit-mc']/table/tbody/tr");
			public static final By WORKFLOW_TEXTROW_1= By.xpath("//span[@id='rcm-tasklist-edit-mc']/table/tbody/tr[1]");
			public static final By CHECK_BUTTON=By.xpath("//*[@class='clsGrayButton clsGrayButton-center']");
			public static final By CHECK_DOCUMENT1=By.xpath("//td[contains(text(),'Check')]");
			
			public static final By PDF_MENU=By.id("icon_export_a");
			public static final By PDF_ICON=By.id("icon_pdf_a");
			public static final By ADD_ATTACHMENT=By.id("icon_add_attachment_a");
			public static final By VIEW_ATTACHMENT=By.id("icon_view_attachment");
			public static final By ATTACHEMENT_NAME=By.xpath("//a[text()='Alerts.jsp.pdf']");
			public static final By CLOSE_ATTACHMENT_VIEW=By.id("textButton_viewAttachments_OkButton");
			public static final By CHECK_ALERT=By.xpath("//td[@title='High Risk Client']");
			public static final By ADD_ATTACHMENT_FILE=By.xpath("//label[text()='Add File']");
			
			public static final By PROHIBITION_TAB=By.xpath("//td[@class='collapserCaption' and contains(.,'Prohibition')]");
            public static final By CUSTOMER_PHONE_NUM=By.xpath("//td[@class='collapserCaption' and contains(.,'Customer Phone Num')]");
            public static final By EMAIL_ADDRESS=By.xpath("//td[contains(text(),'Email Address')]");
            
            
            
            public static final By PREVIOUS_RISK_RATING_TAB=By.xpath("//td[@class='collapserCaption' and contains(.,'Previous Risk Rating')]");
            public static final By ADDITIONAL_DATA_TAB=By.xpath("//td[@class='collapserCaption' and contains(.,'Additional Data')]");
            public static final By ACTIVE_ACCOUNT_DETAILS=By.xpath("//td[@class='collapserCaption' and contains(.,'Active Account Details')]");
            public static final By ACCOUNT=By.xpath("//td[@class='collapserCaption' and contains(.,'Account:')]");
            public static final By ONBOARDING_TAB=By.xpath("//td[@class='collapserCaption' and contains(.,'On-Boarding')]");
            public static final By CRA_TAB=By.xpath("//td[@class='collapserCaption' and contains(.,'CRA')]");
            public static final By OVERRIDE_DETAILS=By.xpath("//td[@class='collapserCaption' and contains(.,'Override Details')]");
            public static final By CLIENT_RISK_RATING=By.xpath("//td[@class='collapserCaption' and contains(.,'Client Risk Rating')]");
            public static final By DOCUMENT=By.xpath("//td[@class='collapserCaption' and contains(.,'document')]");
            public static final By CUSTOMER_LAST_REVIEW_DATE=By.xpath("//*[text()='Last Review Date:']/../td[7]");
            public static final By PREVIOUS_CRA_RATING					= By.xpath("//*[text()='Previous CRA Rating']/../following-sibling::tr/following-sibling::tr/td[1]");
        	public static final By PREVIOUS_COUNTRY_OVERRIDE			= By.xpath("//*[text()='Previous Segment/Country Override']/../following-sibling::tr/following-sibling::tr/td[2]");
        	public static final By PREVIOUS_JOINT_ACCOUNT_OVERRIDE		= By.xpath("//*[text()='Previous Joint-Account Override']/../following-sibling::tr/following-sibling::tr/td[3]");
        	public static final By PREVIOUS_ENTITY_OVERRIDE				= By.xpath("//*[text()='Previous Related Entity Override']/../following-sibling::tr/following-sibling::tr/td[4]");
        	public static final By PREVIOUS_FINAL_RISKRATING			= By.xpath("//*[text()='Previous Final Risk Rating']/../following-sibling::tr/following-sibling::tr/td[5]");
        	public static final By DETECTION_DATETIME					= By.xpath("//*[text()='Detection Datetime']/../following-sibling::tr/following-sibling::tr/td[6]");	
            public static final By Prohibition_tab =By.xpath("//td[@class='collapserCaption' and contains(.,'Prohibition')]");
        	

            public static final By Customer_Status=By.xpath("//td[text()='Customer Status:']/following-sibling::td[1]");
            public static final By Sensitive_Client=By.xpath("//td[text()='Sensitive Client:']/following-sibling::td[1]");
            public static final By PEP_Status=By.xpath("//td[text()='PEP Status:']/following-sibling::td[1]");
			public static final By Details_Button = By.id("detailsBtn");
			public static final By SOW_Prohibition_code=By.xpath("//*[text()='Prohibition based on prohibited Industry in SOW']/../../tr[3]/td[4]");
			public static final By Realtion_Diagram_tab = By.xpath("//table[@class='clsTab cddTab' and contains(.,'Relation Diagram')]");
			public static final By Apply_button = By.xpath("//td[text()='Apply']");
			public static final By Risk_Level = By.xpath("//td[text()='Risk Level:']/following-sibling::td[1]");
			public static final By openBulb= By.xpath("(//img[@src='/RCM/themes/new_york_blue/images/acm3.0/Open.png'])");
			public static final By TRR_MAKER_NOTIFIER = By.xpath("//td[@class='collapserCaption' and contains(.,'TRR-MAKER NOTIFIER')]");
            public static final By FCC_RISK_EVENT_TAB=By.xpath("//td[@class='collapserCaption' and contains(.,'FCC Risk Events')]");
           // public static final By CRA_TAB=By.xpath("//td[@class='collapserCaption' and contains(.,'CRA')]");
			public static final By RISK_LEVEL_ADJUSTMENT= By.xpath("//td[@class='collapserCaption' and contains(.,'Risk Level Adjustment')]");
			public static String iFRAME_ID="frmDetails";
			public static final By VERIFICATION=By.xpath("//td[@class='collapserCaption' and contains(.,'Verification')]");
		    public static final By MANUAL_VERIFICATION=By.xpath("//td[@class='collapserCaption' and contains(.,'Manual Verification')]");

		    public static final By FILENET_MENU	= By.xpath("(//li[@class='dropdown-toggle button actimizeIconButton'])[5]");
		    public static final By UPLOAD_DOC_FILENET	= By.xpath("//li[@title='Upload Document to Filenet']");
		    public static final By FilenetDOC_Document_Title	= By.id("documentTitle");
		    public static final By FilenetDOC_Product	= By.id("transactiontype");
		    public static final By FilenetDOC_SubProduct	= By.id("subTransactionType");
		    public static final By FilenetDOC_DocCategory	= By.id("docCategory");
		    public static final By FilenetDOC_DocType	= By.id("documentType");
		    public static final By FilenetDOC_Browse	= By.id("file");
		    public static final By FilenetDOC_UploadDocButton	= By.xpath("//td[text()='Upload Document']");
		    
		    
            
            // public static final By HHP=By.xpath("//td[contains(text(),'HHP')]");
}

		
		

