package Object_Repository;

import org.openqa.selenium.By;

public class SAO_Objects {public static final By USER_NAME= By.name("userID");
public static final By PASSWORD = By.name("password");
public static final By SUBMIT= By.name("Submit");

public static final By NEW_APPLICATION_BUTTON = By.id("newapplication"); 

public static final By ACQUISITION_CHANNEL=By.xpath("//span[contains(text(),'Acquisition Channel')]/../following-sibling::td/select[@name='acquisitionChannelID']");
public static final By SAVE_BUTTON = By.id("save");
public static final By NEXT_BUTTON = By.id("next");

public static final By ID_TYPE= By.name("idType");
public static final By ID_NUMBER= By.name("idNumber");
public static final By FULL_NAME=By.name("appFullName");
public static final By DOB_DATE=By.name("dateOfBirth");
public static final By DOB_MONTH=By.name("monthOfBirth");
public static final By DOB_YEAR=By.name("yearOfBirth");
public static final By MOBILE_NUMBER=By.name("mobile");
public static final By SEARCH_APPLICANT=By.id("searchButton");
public static final By DEDUP_SEARCH =  By.id("add");
public static final By DEDUP_ICM_NUMBER = By.xpath("//table[@id='tblKeyInfoGrid']/tbody/tr[3]/td[1]/a");
public static final By PREVIOUS_BUTTON=By.id("previous");


/**********Applicant Details************/
//FACTA
public static final By US_RESIDENT=By.name("isUSResident");
public static final By US_CITIZEN=By.name("isUSCitizen");
public static final By GREENCARD_HOLDER=By.name("isUSGreenCardHolder");

//TAX
public static final By COUNTRY_OF_TAXRESIDENCE=By.name("countryOfTaxResidence");
public static final By TAX_IDENTIFICATION_NUMBER=By.name("taxIdentificationNumber");
public static final By REASON_NOT_PROVIDING_TIN=By.name("reasonNotProvidingTIN");
public static final By REMARS_TAX=By.name("taxRemars");
public static final By ADD_CR=By.id("addCRS"); 

//Personal information

public static final By TITLE=By.xpath("//select[@name='salutation']");
public static final By FULLNAME=By.name("fullName");
public static final By FIRST_AND_MIDDLE_NAME=By.name("firstAndMiddleName");
public static final By LAST_NAME=By.name("chineseLastName");
public static final By ACCOUNT_NAME_LINE_1=By.name("accountNameLine1");
public static final By ACCOUNT_NAME_LINE_2=By.name("accountNameLine2");
public static final By FORMER_NAME_ENGLISH=By.name("middleName");
public static final By FULL_NAME_IN_CHAINEES=By.name("chineseName");
public static final By ALIAS_TYPE=By.name("aliasType");
public static final By ALIAS_NAME=By.name("aliasName");
public static final By ALIAS_ADD=By.id("aliasDetAdd");

public static final By Passport_Expiry = By.xpath("//input[@name='uniqueIdDt04Str']");
public static final By CALENDER_IMG=By.xpath("//img[@src='images/Calendar.gif']");
public static final By CALENDER_DATE = By.xpath("//tr[@class='daysrow rowhilite']/child::td[@class='day hilite']");
public static final By CHAINA_ID_TYPE=By.name("chinaIdType");
public static final By MALE=By.id("GenderMale");
public static final By FEMALE=By.id("GenderFemale");
public static final By NATIONALITY =  By.xpath("//select[@name='nationality']");
public static final By NATIONALITY2 = By.xpath("//select[@name='nationality2']");
public static final By NATIONALITY3 = By.xpath("//select[@name='nationality3']");
public static final By NATIONALITY4 = By.xpath("//select[@name='nationality4']");
public static final By NATIONALITY5 = By.xpath("//select[@name='nationality5']");
public static final By COUNTRY_OF_BIRTH = By.xpath("//select[@name='countryOfBirth']");
public static final By CITY_OF_BIRTH = 	By.xpath("//input[@name='placeOfBirth']");
public static final By MARITAL_STATUS =	By.xpath("//select[@name='maritalStatus']");
public static final By PROFESSIONAL_QUALIFICATION = By.xpath("//select[@name='educationalStatus']");
public static final By WORK_TYPE  = By.xpath("//select[@name='workType']");
public static final By INDUSTRY = By.xpath("//select[@name='industryTypeId']");
public static final By EMPLOYER = By.xpath("//input[@name='nameOfEmployer']");
public static final By PROFESSION = By.xpath("//select[@name='occupation']");
public static final By INCOME =  By.xpath("//input[@name='annualIncome']");
public static final By MAIL_ID = By.xpath("//input[@name='emailID']");
public static final By ASIA_MEMBERSHIP_NUMBER = By.xpath("//input[@name='asiaMilesMemNo']");
public static final By ASIA_MEMBER_FAMILY_NAME = By.xpath("//input[@name='asiaMilesMemSurName']");
public static final By ASIA_MEMBER_GIVEN_NAME = By.xpath("//input[@name='asiaMilesMemFirstName']");
public static final By PEP_STATUS = By.xpath("//select[@name='pepStatus']");
public static final By SANCTION_LINK = By.xpath("//select[@name='sanctionLink']");
public static final By ADVERSE_INFORMATION = By.xpath("//select[@name='adverseInfo']");
public static final By PHONE_TYPE = By.xpath("//select[@name='contactTypeCode']");
public static final By PHONE_NUMBER = By.xpath("//input[@name='contactNumber']");  
public static final By COUNTRY_CODE =  By.xpath("//select[@name='isdCode']");
public static final By BUTTON_ADD = By.xpath("//td[@class='buttonbg1']//following::button[@id='contactAddButton']");
public static final By CONSERVATION_PHONE =  By.xpath("//select[@name='conversationPhoneIndicator']");
public static final By ADDRESS_TYPE =	By.xpath("//select[@id='addressType']");
public static final By ADDRESS_TYPE_CASA =	By.xpath("//select[@name='addressType']");
public static final By ADDRESS_TITLE = By.xpath("//input[@id='title1']");
public static final By ADDRESS_LINE1 = By.xpath("//input[@id='addressLine1']");
public static final By SAME_AS = By.xpath("//select[@name='sameAsAddressType']");
public static final By CITY = 	By.xpath("//input[@id='city']");
public static final By COUNTRY = By.xpath("//select[@id='country']");
public static final By ADD_ADDRESS =  By.xpath("//td[@class='buttonbg1']//following::button[@id='addAddress']");
public static final By FINAL_SAVE = By.id("save");
public static final By NEXT = By.id("next");
public static final By SECONDARY_APPLICANT=By.xpath("//table[@id='applicantList']/tbody/tr[3]/td[7]/a");
public static final By PROMOTION_EMAIL = By.xpath("//select[@name='emailIndicator']");
public static final By PROMOTION_MESSAGE = By.xpath("//select[@name='smsIndicator']");
public static final By PROMOTION_POST = By.xpath("//select[@name='postIndicator']");
public static final By PROMOTION_PHONECALL = By.xpath("//select[@name='phoneIndicator']");
public static final By PROMOTION_CONSERVATION_OVER_PHONE = By.xpath("//select[@name='conversationPhoneIndicator']");

//Time_Deposit
public static final By SUBPRODUCT_TD = By.xpath("//select[@name='productChoiceCode']");
public static final By TERM_TYPE = By.xpath("//select[@name='termType']");
public static final By TERM = By.name("term");


//--Product Selector

public static final By CASA=By.name("casa");
//public static final By CASA=By.xpath("//td[@class='idLabel1']//following::input[@name='casa']");
public static final By TIMEDEPOSIT_CDA = By.xpath("//td[@class='idLabel1']//following::input[@name='termDeposit']");
public static final By INVESTMENT_ACCOUNT = By.xpath("//td[@class='idLabel1']//following::input[@name='investmentAccount']");
public static final By CREDIT_CARDS = By.xpath("//input[@name='asiamilesCard']");


//Service Requested CASA

public static final By PRODUCT=By.name("productClass");
public static final By SUB_PRODUCT=By.name("subProductChoice");

public static final By ASIA_MILES_YES=By.id("asiaMilesSAYes");
public static final By ASIA_MILES_NO=By.id("asiaMilesSANo");

public static final By GENERATE_ACCOUNT_NUMBER=By.id("generateButton");
public static final By CURRENCY_CODE=By.name("currency");
public static final By CUSTOMER_CONFIRM_NON_RESIDENCE_CHECKBOX=By.name("cnyCurrencySFProductDeclaration");


public static final By SIGNING_INSTRUCTION=By.name("signingInstruction");
public static final By ACCOUNT_NAME=By.name("accountName");

public static final By CAPAIGN_CODE=By.name("campaignCode");
public static final By HOLD_CODE_1=By.name("holdeCode1");
public static final By HOLD_CODE_2=By.name("holdeCode2");
public static final By HOLD_CODE_1_NARRATIVE=By.name("holdeCode1Narrative");
public static final By HOLD_CODE_2_NARRATIVE=By.name("holdeCode2Narrative");

public static final By AMOUNT_INITIAL_DEPOSITE=By.name("initialFundingAmount");
public static final By AMOUNT_INITIAL_DEPOSITE_CURRENCY=By.name("initialFundingCurrency");

public static final By PURPOSEOF_ACCOUNT_OPENING=By.name("purposeOfAccountOpening");
public static final By PURPOSEOF_ACCOUNT_OPENING_ADD_BUTTON=By.id("purposeOfAccountOpeningAddButton");
public static final By PURPOSE_FOR_OFFSHORE=By.name("purposeForOffShoreClient");


public static final By BANKING_SERVICES_STATIMET_SUBSCRIPION_DETAILS=By.id("estamtCHKList");
//Document Check List

public static final By MANDATORY_DOCUMENTS = By.xpath("//input[@id='DocumentList']");

//CDD
public static final By SUBMIT_FOR_CDDPROCESS = By.id("submitId");


//Homepage
public static final By APPLICATION_NUMBER = By.xpath("//table/tbody/tr[2]/td[1]");
public static final By PRINT_APPLICATION_NUMBER = By.xpath("//table[@class='sectionHeading1']/tbody/tr/td[2]");

//ICCD_Reference_num
public static final By ICCD_NUMBER_1 = By.xpath("//table[@id='applicantList']/tbody/tr[2]/td[8]");
public static final By ICCD_NUMBER_2 = By.xpath("//table[@id='applicantList']/tbody/tr[3]/td[8]");
public static final By NameScreening_AlertID = By.xpath("//table[@id='applicantList']/tbody/tr[2]/td[10]");
public static final By NameScreening_AlertID_1 = By.xpath("//table[@id='applicantList']/tbody/tr[3]/td[10]");



//Print application
public static final By PRINT_APPLICATION=By.xpath("//button[@id='print']");
public static final By BACK_DECLINE = By.xpath("//button[@id='delete']");

//submit for fullfillment
public static final By SUBMIT_FULLFILLMENT=By.id("submitfulfillment");

public static final By ACCOUNT_OPENING_BUTTON  = By.xpath("//a[@class='tabGrey']");


// Search The Application to Get the ICM Number

public static final By SEARCH_APPLICATION_NUMBER = By.xpath("//input[@name='APPL.APPLNO']");
public static final By SEARCH_THE_DATE_OF_APPLICATION_FROM = By.xpath("//input[@name='APPL.CREATEDDATE']");
public static final By SEARCH_THE_DATE_OF_APPLICATION_TO = By.xpath("//input[@name='toAPPL.CREATEDDATE']");
public static final By IDTYPE_SEARCH = By.xpath("//select[@name='IDTYPE']");
public static final By STATUS = By.xpath("//select[@name='APPL.STATUS']");
public static final By GET_ICM_NUMBER = By.xpath("//div[@id='saocontent']/table[4]/tbody/tr/td/div/table/tbody/tr[3]/td[4]");
public static final By GET_ICM_NUMBER_Joint = By.xpath("//div[@id='saocontent']/table[4]/tbody/tr/td/div/table/tbody/tr[2]/td[4]");

public static final By SEARCH_BUTTON = By.xpath("//input[@name='btnSearch']");




//calender xpath
public static final By MONTH_YEAR_STRING=By.xpath("//table[@calendar='[object Object]']/thead/tr[1]/td[2]");
//public static final By MONTH_YEAR_STRING=By.xpath("//td[@ttip='Drag to move']");
public static final By MONTH_BACKWARD=By.xpath("//td[@ttip='Prev. month (hold for menu)']/div");
public static final By MONTH_FORWARD=By.xpath("//td[@ttip='Next month (hold for menu)']/div");

public static final By YEAR_BACKWARD=By.xpath("//td[@ttip='Prev. year (hold for menu']/div");
public static final By YEAR_FORWARD=By.xpath("//td[@ttip='Next year (hold for menu)']/div");
public static final By Logout_button = By.xpath("//a[text()='Logout']");}
