package Step_Defination;

import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.By;

import Business_Methods.ICDD_WorkItem;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import utillities.BaseTestSetup;
import utillities.DataProvider;
import Business_Methods.ICCD_OnBoardingForm;
import Business_Methods.ICDD_Clsoing_Alerts;
import Business_Methods.ICDD_CustomerRecord;

public class ICDD_CustomerRecord_Glue {
	
	DataProvider dataprovider = new DataProvider();
	//public static HashMap<String, String> log.excelHashMapValues = new HashMap<String, String>();
	Login_Glue log = new Login_Glue();	
	String arg1 = log.excelHashMapValues.get("scenarioName");
	String arg2 = log.excelHashMapValues.get("sheetName");	
	ICDD_CustomerRecord ICDD_CustomerRecord=new ICDD_CustomerRecord();
	ICDD_WorkItem ICDD_WorkItem = new ICDD_WorkItem();
	ICCD_OnBoardingForm ICDD_OnBoarding=new ICCD_OnBoardingForm();
	ICDD_Clsoing_Alerts  icdd_closing_alert=new ICDD_Clsoing_Alerts();
	
	
	
	@Given("^Search for customer using ICDD_ID and Capture Riskrating and RiskCodes$")
	public void search_for_customer_using_ICDD_ID_riskcode_riskrating() throws Throwable {
		System.out.println(log.excelHashMapValues.get("scenarioName") + "-" + log.excelHashMapValues.get("sheetName"));
		ICDD_CustomerRecord.searchCustomer_ICDD_ID(arg1, log.excelHashMapValues);
		ICDD_CustomerRecord.Details_Of_Customer();
		//ICDD_CustomerRecord.Risk_code_Details();
	}	
	
	@And("^take the screenshots of Alert details$")
	public void take_screenshots_alert() throws Throwable{
		ICDD_CustomerRecord.take_screenshots_of_alert();
	}
	@And("^Upload the evidence in filenet$")
	public void Upload_evidence_filenet() throws IOException{
		ICDD_CustomerRecord.Upload_evidence_filenet(log.excelHashMapValues);
	}
   
	@And("^click Relation Diagram and validate joint account or not by taking screen shot$")
	public void Click_Relation_Diagram() throws Throwable{
		ICDD_CustomerRecord.Relation_Diagram();
	}
	@And("^Validate Risk level of the customer in ICDD$")
	public void Validate_Risk_level_of_Customer(){
		String risklevel=log.excelHashMapValues.get("Risk");
		ICDD_CustomerRecord.validate_Risk_level_of_customer(risklevel);
	}
	
	@And("^Customer status should be \"([^\"]*)\"$")
	public void Validate_customer_status(String custStatus){
		
		ICDD_CustomerRecord.verify_Customer_Status(custStatus);
		
	}
	
	@And("^CDD Status for alert should be \"([^\"]*)\"$")
	public void Validate_CDD_status_for_alert(String Custatus){
		ICDD_CustomerRecord.verify_CDD_Status_for_alert(Custatus);
	}
	

	@And("^Customer status for alert should be \"([^\"]*)\"$")
	public void Validate_customer_status_for_alert(String Custatus){
		ICDD_CustomerRecord.verify_Customer_Status_for_alert(Custatus);
	}
	
	
	@And("^riskcode \"([^\"]*)\" should not be present$")
	public void Validate_HHP(String val){
		ICDD_CustomerRecord.Verify_HHP_should_not_Present(val);
	}
	
	@And("^riskcode \"([^\"]*)\" should  be present$")
	public void HHP_Present(String val){
		ICDD_CustomerRecord.Verify_HHP_should_present(val);
	}
	
	@And("^Validate Sensitive Client should be \"([^\"]*)\"$")
	public void Validate_(String status){
		ICDD_CustomerRecord.Validate_Sensitive_Client(status);
	}

	
	@And("^Validate PEP Status should be \"([^\"]*)\"$")
	public void Validate_PEP_Status(String status){
		ICDD_CustomerRecord.Validate_PEP_Status(status);
	}
	
	@And("^clicks on Details Button$")
	public void click_on_Details_button(){
		ICDD_CustomerRecord.click_Details_Button();
		
	
	}
	
	@And("^Validate Prohibiton code should have \"([^\"]*)\" \"([^\"]*)\"$")
	public void validate_prohibition_code(String code1,String code2){
		ICDD_CustomerRecord.Validate_prohibition_code(code1,code2);
	}
/* ---------------------------------------------------------------------
    Method Name: search_for_customer_using_ICDD_ID
    Description: Stepdefination to search the ICDD customer.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/
	@Given("^Search for customer using ICDD_ID$")
	public void search_for_customer_using_ICDD_ID() throws Throwable {
		System.out.println(log.excelHashMapValues.get("scenarioName") + "-" + log.excelHashMapValues.get("sheetName"));
		ICDD_CustomerRecord.searchCustomer_ICDD_ID(arg1, log.excelHashMapValues);
	}
	
	@And("^click on Customer Alert button$")
	public void click_on_Customer_Alerts_button()throws Throwable{
		
		ICDD_CustomerRecord.click_on_Customer_Alert();
	}
	@And("^click on Customer Alert button in alert level$")
	public void Click_Customer_Alert_in_alert_Level(){
		ICDD_CustomerRecord.click_on_Customer_Alert_alert_level();
	}
	
	@And("^filter customer by giving customer id$")
	public void Search_Customer() throws Throwable{
		
		ICDD_WorkItem.searchcustomeralerts(log.excelHashMapValues.get("ICDD_ID"));
	}
	@And("^Confirm ther is no open alerts present$")
	public void confirm_there_is_No_open_alerts() throws Throwable{
		
		ICDD_CustomerRecord.conifrm_there_is_no_open_alerts();

	}
	
	@And("^find the new generated alert and add to input data sheet$")
	public void find_new_generated_alert() throws Throwable{
		String sTempValue = ICDD_CustomerRecord.find_new_generated_alert(arg1, log.excelHashMapValues, arg2);
		log.excelHashMapValues.put("SECOND_MANUAL_TRIGGER_ALERT_ID", sTempValue);

	}

	@And("^find the new generated ICM and add to input data sheet$")
	public void find_new_generated_ICMID() throws Throwable{
		String sTempValue = ICDD_CustomerRecord.find_ICM_ID(arg1, log.excelHashMapValues, arg2);
		log.excelHashMapValues.put("icmId", sTempValue);

	} 
	
	@Given("^Get the Onboarding alert number and update in MasterData$")
	public void get_the_Onboarding_alert_number_and_update_in_MasterData() throws Exception {
		String sTempValue = ICDD_WorkItem.getOnboardingAlert(Login_Glue.excelHashMapValues);
		log.excelHashMapValues.put("ONBOARDING_ALERT_ID", sTempValue);
	}
/* ---------------------------------------------------------------------
    Method Name: create_a_manual_Trigger
    Description: Step definition to create the Manual trigger in ICDD application.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/
	@Given("^Create a manual Trigger$")
	public void create_a_manual_Trigger() throws Throwable {		
		String sTempValue = ICDD_WorkItem.CreateManualTrigger(arg1, log.excelHashMapValues, arg2);
		log.excelHashMapValues.put("MANUAL_TRIGGER_ALERT_ID", sTempValue);
	}	
/* ---------------------------------------------------------------------
    Method Name: create_a_Periodic_Trigger
    Description: Step definition to create the Periodic trigger in ICDD application.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/
	
	@Given("^Create a Periodic Review Trigger \"([^\"]*)\"$")
	public void create_a_Periodic_Trigger(String arg1) throws Throwable {
		dataprovider.extractExcelData(arg1, log.excelHashMapValues);
		//ICDD_WorkItem.CreatePeriodicReviewAlert(arg1, log.excelHashMapValues);
	}
/* ---------------------------------------------------------------------
    Method Name: create_a_Periodic_Trigger
    Description: Step definition to create the Periodic trigger in ICDD application.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/	
	@Given("^Create a Periodic Review Trigger$")
	public void create_a_Periodic_Trigger() throws Throwable {		
		System.out.println(log.excelHashMapValues.get("PERIODIC_TRIGGER_REASON"));
		String PRR_Alert = ICDD_WorkItem.CreatePeriodicReviewAlert(arg1, log.excelHashMapValues, arg2);
		log.excelHashMapValues.put("PERIODIC_ALERT_ID", PRR_Alert);
	}
	@And("^Create a periodic Review Trigger but it should not get created$")
	public void create_PRR_should_not_generate() throws Throwable{
		ICDD_WorkItem.CreatePeriodicReviewAlert_should_not_generate(log.excelHashMapValues);
	}
	
	@And("^Verify if alert is present in overdue periodic review \"([^\"]*)\"$")
	public void verify_if_alert_is_present_in_overdue_periodic_review(String arg1) throws Throwable {
		System.out.println("Overdue scenarios has to be scripted");
	}
	
	@And("^Verify Trigger review \"([^\"]*)\"$")
	public void verify_Trigger_review(String arg1) throws Throwable {
		//Verify Trigger script 
	}
	
	@And("^Verify Trigger review for joint account \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_Trigger_review_for_joint_account(String arg1, String arg2) throws Throwable {
	}
	
	@And("^Verify the overdue_periodic_alert \"([^\"]*)\"$")
	public void verify_Overdue_Periodic_alert(String arg1) throws Throwable {
		///overdue
	}
	
	@And("^Verify periodic review \"([^\"]*)\"$")
	public void verify_periodic_review(String arg1) throws Throwable {
		//Verify periodic review script 
	}
	
	@When("^verifies the alert in workflow$")
	public void verifies_the_alert_in_workflow() throws Throwable {
	}
	
	
	@Given("^is assigned to the \"([^\"]*)\" workgroup$")
	public void is_assigned_to_the_workgroup(String arg1) throws Throwable {
	}
	

	@And("^verify periodic review status Auto Close due to WIP Triggers \"([^\"]*)\"$")
	public void verify_periodic_review_status_AutoClose_duetoWIP_Triggers(String arg1) throws Throwable {
	}
	
	
	
	
	@And("^Verify Trigger review for \"([^\"]*)\" and \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_Trigger_review_for_and(String arg1, String arg2, String arg3) throws Throwable {
	 //Verify Trigger script for 2 customers
	}
	
	//For closing the alerts - data clancing 
	@And("^get all open alerts and logout then close the alert one by one$")
	public void Close_All_Open_Alerts() throws Throwable{
		
		icdd_closing_alert.Close_ALL_Alerts(log.excelHashMapValues);
		
	}
	
	
	
}
