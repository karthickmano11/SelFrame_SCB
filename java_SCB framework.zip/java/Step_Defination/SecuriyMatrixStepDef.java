package Step_Defination;



import Business_Methods.ICDD_CustomerRecord;
import Business_Methods.ICDD_WorkItem;
import Business_Methods.SecurityMatrixBusiness;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utillities.Common_Utils;

public class SecuriyMatrixStepDef {

	Login_Glue log=new  Login_Glue();
	SecurityMatrixBusiness securitymatrixbuiss=new SecurityMatrixBusiness();
	ICDD_WorkItem ICDD_WorkItem=new ICDD_WorkItem();
	

	
	
	@And("^Validate onboarding tab$")
	public void Validating_Onboarding_tab() throws Throwable{
		
		securitymatrixbuiss.validate_Onboarding_tab_Present();
	}
	
	@And("^Validate search field under onboarding tab and validating search result$")
	public void Validating_Search_Under_Onboarding_tab() throws Throwable{
		System.out.println("ICDD_ID"+Login_Glue.excelHashMapValues.get("ICDD_ID"));
		securitymatrixbuiss.Validate_customer_under_Onboardingtab(Login_Glue.excelHashMapValues);
		
	}
	
	@And("^update contact number of NTB client under onboarding tab$")
    public void Update_Contact_number_under_onboarding() throws Throwable{
		securitymatrixbuiss.Update_Contact_Number_in_OnBoarding(Login_Glue.excelHashMapValues);
		
	}
	
	@And("^Validate Workbench-WorkItem tab in ICDD$")
	public void Validate_Workbench_workitem() throws Throwable{
		
		securitymatrixbuiss.Validate_WorkBench_WorkItem_Present();		
	}
	
	@And("^Validate MyWorkItems and validate list of roles which should not be present$")
	public void Validate_list_of_roles_not_present() throws Throwable{
		
		securitymatrixbuiss.Validate_My_WorkItems_Options_Not_Present(Login_Glue.excelHashMapValues);
		
	}
	@And("click on add attachment icon and should get error message")
	public void Validate_Attachment_Icon() throws Throwable{
		
		securitymatrixbuiss.Validate_View_attachments();	
	}
    
	@Then("Validate Create RFI")
	public void Validate_Recall_Icon() throws Throwable{
		
		securitymatrixbuiss.validateCreateRFI(Login_Glue.excelHashMapValues);
	}
	
	@And("^validate multiple change step but should not able to perfom$")
	public void Validate_Multiple_change_step()throws Throwable{
		securitymatrixbuiss.validateMultipleChangeStep();
		
	}
	
	@And("^Validate multiple assign but should not able to perfom$") 
	public void Validate_Multiple_Assign() throws Throwable{
		ICDD_WorkItem.selectMultipleCheckBox_assign();
		ICDD_WorkItem.assign_to_me_access_denaid();
	}
	
	@And("^Validate Export$")
	public void Validate_Export_option() throws Throwable{
		securitymatrixbuiss.Validate_Export_Icon();
	}
	
	@And("^Validate Print List$")
	public void Validate_Print_List() throws Throwable{
		securitymatrixbuiss.Validate_Print_List();
	}
	
	@And("^search and select the alert$")
	public void search_And_select() throws Throwable{
		String alert_type=Login_Glue.excelHashMapValues.get("ALERT_TYPE");
		securitymatrixbuiss.Validate_WorkBench_WorkItem_Present();
		ICDD_WorkItem.searchcustomeralerts(Login_Glue.excelHashMapValues.get(alert_type));
		securitymatrixbuiss.select_first_check_box();

		//ICDD_WorkItem.click_ref_id_checkbox();
	}
	
	@And("^Validate Remove Attachments$")
	public void remove_attachments() throws Throwable{
		securitymatrixbuiss.remove_attachments();
		
	}
	@And("^Validate Show as pdf$")
	public void show_As_pdf() throws Throwable{
		securitymatrixbuiss.validateShowAsPDF();
	}
	
	@And("^Validate view attchments$")
	public void view_attachment() throws Throwable{
		securitymatrixbuiss.validateViewAttachment();
	}
	@And("^Validate View History$")
	public void Validate_History() throws Throwable{
		
		securitymatrixbuiss.Validate_MoreTab_and_ViewHistory();
	}
	
	@And("^Validate View Notes$")
	public void Validate_View_Notes() throws Throwable{
		
		securitymatrixbuiss.Validate_View_Notes();
	}
	
	@And("^Validate View RFI$")
	public void Validate_View_RFI() throws Throwable{
		
		securitymatrixbuiss.validateViewRFI();
	}
	@When("^click and validate assign step$")
	public void Assign() throws Throwable{
		ICDD_WorkItem.assign_to_me();
	}
	
	@And("^Validate Customer tab, search customer result$")
	public void Validate_cutstomer_search_result() throws Exception{
		securitymatrixbuiss.Validate_Customer_alert(Login_Glue.excelHashMapValues.get("ICDD_ID"));
	}
	
	@And("^Validate Add_Note icon and Free_Text$")
	public void Validate_add_note_free_Text() throws Exception{
		securitymatrixbuiss.validateAddNotes(Login_Glue.excelHashMapValues);
	}
	@And("^Validate send mail option$")
	public void Validate_Send_mail() throws Exception{
		securitymatrixbuiss.Validate_Send_Mail_Option();
		
	}
	
	@And("^Validate Print Details$")
	public void Validate_Print_Details() throws Exception{
		securitymatrixbuiss.validatePrintDetails();
	}
	
	@And("^Validate add attachment$")
	public void Validate_add_attchment() throws Exception{
		securitymatrixbuiss.add_Attachment();
	}
	
	@And("^Validate Wrokbench Reports$")
	public void Validate_workBench_reports() throws Throwable{
		securitymatrixbuiss.Validate_WorkBench_Reports();
	}
	
	@And("^Validate MyReports and All Reports$")
	public void Validate_MyReports_All_Reports() throws Throwable{
		securitymatrixbuiss.Validate_My_Reports_All_Reports();
	}

	@And("^Validate Customers Tab in ICDD$")
	public void Validate_Customer_Tab() throws Throwable{
		securitymatrixbuiss.Validate_Customer_tab_Present();
	}
	
	@And("^Validate Home Page Tab in ICDD$")
	public void Validate_Home_Page_Tab() throws Throwable{
		securitymatrixbuiss.Validate_HomePage_tab_Present();
	}
	
	@And("^Validate onboarding tab should not present$")
	public void Validate_onboarding_tab_not_present() throws Throwable{
		securitymatrixbuiss.validate_Onboarding_tab_Not_Present();
	}
	
	@And("^Validate Dashboards tab should not present$")
	public void Validate_Dashboards_tab_not_Present() throws Throwable{
		securitymatrixbuiss.Validate_Dashboard_Not_Present();
	}
	
	@And("^Validate Research tab and On Demand Reports$")
	public void Validate_Reasearch_tab() throws Throwable{
		securitymatrixbuiss.Validate_Reasearch_OnDemand_Reports_Not_Present();
	}
	
	
	@And("^Validate WorkItem List should not be present$")
	public void Validate_Work_item_list_not_Present() throws Throwable{
		securitymatrixbuiss.Validate_My_WorkItems_Options_Not_Present(Login_Glue.excelHashMapValues);
	}
	
	@And("^Validate Advance filter and size of the alerts should change$")
	public void Validate_Advance_filter() throws Throwable{
		securitymatrixbuiss.Validate_Advance_filter();
		
	}
	@And("^Validate  checker should not have access to maker options$")
	public void Validate_maker_options() throws Exception{
		securitymatrixbuiss.Validate_maker_options();
	}
	
	@And("^Validate WorkBeanch Reports$")
	public void Validate_Work_bench_reports() throws Throwable{
		securitymatrixbuiss.Validate_WorkBench_Reports();
		
	}
	
	@And("^Validate All Reports$")
	public void Validate_All_Reports() throws Throwable{
		securitymatrixbuiss.Validate_My_Reports_All_Reports();
		
	}
	
	@And("^Validate Advance filter page and filter the reports by selecting report type as \"([^\"]*)\"$")
	public void Validate_Advance_filter_page(String reportType){
		securitymatrixbuiss.Validate_Advance_filter_page(reportType);
		}
	
	@And("^Validate assign icon for Reports$")
    public void Validate_assign_Reports(){
          securitymatrixbuiss.Validate_Assign_Reports();
          
    }
    @And("^Assign the report to Business Unit$")
    public void Validate_assign_Reports_Businness_unit(){
        securitymatrixbuiss.Validate_assign_Reports_Business_unit();
    }
    @And("^Validate Delete icon for Reports$")
    public void Validate_Delete_icon(){
          securitymatrixbuiss.Validate_Delete_Icon();
    }
    @And("^Validate On-Demand Reports$")
    public void Validate_On_Demand_Report(){
          securitymatrixbuiss.Validate_On_Demand_Report();
    }
    @And("^Validate Open icon for Reports$")
    public void Validate_Open_icon(){
          securitymatrixbuiss.Validate_Open_Icon();
    }
    @And("^Validate Add note for Reports$")
    public void Validate_add_note_report() throws Exception{
    securitymatrixbuiss.Validate_Add_Note_report(log.excelHashMapValues);
    }
    @And("^Validate view history for Reports$")
    public void Validate_view_history(){
          securitymatrixbuiss.Validate_view_History();
    }
    @And("^Validate sign-off for Reports$")
    public void Validate_sign_off(){
          securitymatrixbuiss.Validate_sign_off();
    }
    @And("^Validate View Notes for Reports$")
    public void Validate_view_notes_reports(){
          securitymatrixbuiss.Validate_view_notes_reports();
    }

	@And("^Click Risk level Adjustment")
    public void Click_Risk_level_Adjustment()
    {
		securitymatrixbuiss.clickRisklevelAdjustment();
    }

	
	@And("^Validate Research - Dart Reports$")
	public void Validate_Reasearch_Dart_reports() throws Exception{
		securitymatrixbuiss.Validate_Reasearch_Dart_Present();
	}
	
	@And("^Validate Research - On-Demand Reports$")
	public void Validate_research_On_demand_reports() throws Exception{
		securitymatrixbuiss.Validate_Reasearch_OnDemand_Reports_Present();
	}
	
	
	//sathish
	@And("^User checks on alert that is Assign to Me$")
	public void User_checks_on_alert_that_is_Assign_to_Me() throws Throwable {
		securitymatrixbuiss.checkAlert_AssignToMe("Single");
		
	}
	@And("^user view will apply the display of My Work Items view page in the dropdown")
	public void display_MyWork_Closed_Items_view() throws Exception{
		
		securitymatrixbuiss.selection_My_WorkItems_Options_Present(log.excelHashMapValues);
		//securitymatrixbuiss.validateform_Not_Present(arg1, log.excelHashMapValues);
	}
	
	@Given("^that user has checked on alert that \"([^\"]*)\" alert under My WorkItems$")
	public void multiple_Alert_Change_validation(String sTempValue) throws Throwable{
		securitymatrixbuiss.Navigate_WorkBench_WorkItem();
		securitymatrixbuiss.checkAlert_AssignToMe(sTempValue);
		
	}
	
	@And ("^click on add note icon and select the \"([^\"]*)\"$")
	public void click_on_add_note_icon_and_select_the_Free_Text(String arg1) throws Throwable {
		securitymatrixbuiss.validate_AddNotes(arg1,log.excelHashMapValues);
	}
	
	@And("^Navigate to Workbench-WorkItem tab in ICDD$")
	public void Navigate_Workbench_WorkItem_tab() throws Throwable {
		securitymatrixbuiss.Navigate_WorkBench_WorkItem();
	}
	
	@And ("^Validate Dashboard tab is not present in ICDD$")
	public void Validate_Dashboard_tab_is_not_present_in_ICDD() throws Exception{
		securitymatrixbuiss.Validate_Dashboard_Not_Present();
	}
	
	@When("^user tries to click on the change step icon")
	public void click_ChangeStep_Icon(){
		securitymatrixbuiss.click_ChangeStep();
	}
	
	
	@And ("^Validate to Workbench-Reports tab is not present in ICDD$")
	public void Validate_to_Workbench_Reports_tab_is_not_present_in_ICDD() throws Throwable{
		securitymatrixbuiss.Validate_WorkBench_Reports_Not_Present();
	}
	
	@And ("User does not have access to selected Work Items from dropdown$")
	public void Validate_MyworkItems_Not_Present() throws Exception{
		securitymatrixbuiss.Validate_My_WorkItems_Options_Not_Present(log.excelHashMapValues);
	}
	@Then("^user is not able change multiple item step on the selected alerts \"([^\"]*)\"$")
	public void validate_Item_Step_Alerts(String sValue){
		securitymatrixbuiss.validate_Access_ChangeStep(sValue);
	}
	@And("^click on Assign icon and validate the window$")
	public void validate_Assign_Icon() throws Exception{
		securitymatrixbuiss.Validate_Assign_Icon();
	}
	@And("^click on Create RFI and validate the window$")
	public void validate_CreateRFI_Icon() throws Exception{
		Thread.sleep(3000);
		securitymatrixbuiss.validate_CreateRFI();
	}
	
	@And("^click on Export icon and validate user is able to export the file$")
	public void validate_ExportIcon() throws Exception{
		securitymatrixbuiss.Validate_Export_Icon();		
	}
	@And("^click on print Details and validate the window$")
	public void validate_PrintDetails() throws Exception{
		securitymatrixbuiss.validatePrintDetails();
	}
	@Given ("^User tries to perform the Remove Attachement \"([^\"]*)\"$")
	public void Add_Attachment(String sTempValue) throws Exception{
		securitymatrixbuiss.select_My_WorkItems_Options_Present(sTempValue);
		securitymatrixbuiss.checkAlert_AssignToMe("Single");
		securitymatrixbuiss.add_Attachment();
	}
	@And("^click on Attachment icon and validate user is able to remove attachement$")
	public void validate_RemoveAttachment(){
		securitymatrixbuiss.validate_RemoveAttachment();
	}
	@And("^click on the Send Email icon and validate the user is \"([^\"]*)\" to send email$")
	public void validate_Send_Email(String sTempValue) throws Exception{
		securitymatrixbuiss.Validate_Perform_Send_Mail_Option(sTempValue);
	}
	@And("^click on Show as PDF icon and validate window$")
	public void validate_ShowAsPDF() throws Exception{
		securitymatrixbuiss.validateShowAsPDF();
	}
	@And("^click on View Attachement and user is \"([^\"]*)\" to perform$")
	public void validate_ViewAttachment_not_able_to_perform(String sTempValue) throws Exception{
		if (sTempValue.equals("Not able")){
			securitymatrixbuiss.Validate_View_attachments_not_Present();
		}else{
			
		}
	}
	@And("^click on View History and user is \"([^\"]*)\" to view function$")
	public void validate_ViewHistory_not_able_to_perform(String sTempValue) throws Exception{
		if (sTempValue.equals("Not able")){
			securitymatrixbuiss.Validate_View_History_not_Present();
		}else{
			securitymatrixbuiss.Validate_MoreTab_and_ViewHistory();
		}
		
	}
	@And("^click on View Notes and user is \"([^\"]*)\" to view function$")
	public void validate_ViewNotes_not_able_to_perform(String sTempValue) throws Exception{
		if (sTempValue.equals("Not able")){
			securitymatrixbuiss.Validate_View_Notes_not_Present();
		}else{
			securitymatrixbuiss.Validate_View_Notes();
		}
	}
	@And("^click on View RFI and user is \"([^\"]*)\" to view function$")
	public void validate_ViewRFI_not_able_to_perform(String sTempValue) throws Exception{
		if (sTempValue.equals("Not able")){
			securitymatrixbuiss.Validate_View_RFI_not_Present();
		}else{
			securitymatrixbuiss.validateViewRFI();
		}
	}
	@And("click on add attachment icon and validate the window")
	public void Validate_AddAttachment_Icon() throws Throwable{
			
			securitymatrixbuiss.Validate_Add_attachments();	
		}
	@And("^User click on the \"([^\"]*)\" in the workitems dropdown$")
	public void user_Click_Workitems(String sTempValue) throws Exception{
		securitymatrixbuiss.select_My_WorkItems_Options_Present(sTempValue);
	}
	@Then("^User is able to view multiple items in the grid")
	public void user_View_MultipleItems(){
		securitymatrixbuiss.validate_MultipleItems_View();
	}
	@And("^click on print List and validate the window$")
	public void validate_PrintList() throws Exception{
		securitymatrixbuiss.validatePrintList();
	}
	@Then("^user able to change the step \"([^\"]*)\" without any error$")
	public void validate_ChangeStep_process(String sTempValue) throws Exception{
		securitymatrixbuiss.validate_Access_ChangeStep_Completion(sTempValue);
	}
	@And("^validate user is able to perform Custom forms$")
	public void validate_mulitpleFome_access(){
		securitymatrixbuiss.validateform_Not_Present(log.excelHashMapValues);
		securitymatrixbuiss.validateform("", log.excelHashMapValues);
	}
	@And("^Validate Customer tab in ICDD$")
	public void Validate_Customer_tab() throws Throwable{
			
			securitymatrixbuiss.Validate_Customer_tab_Present();		
		}
	@And("^Validate HomePage tab in ICDD$")
	public void Validate_HomePage_tab() throws Throwable{
		
		securitymatrixbuiss.Validate_HomePage_tab_Present();		
	}
	@Given("^User tries to perform the find the alert in \"([^\"]*)\"$")
	public void find_Alerts_Assgin(String sTempValue) throws Throwable{
		securitymatrixbuiss.Validate_WorkBench_WorkItem_Present();
		securitymatrixbuiss.select_My_WorkItems_Options_Present(sTempValue);
		securitymatrixbuiss.checkAlert_AssignToMe("Single");
		
	}
}