package Step_Defination;

import java.io.IOException;
import java.util.HashMap;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


import com.codoid.products.exception.FilloException;

import Business_Methods.ICCD_OnBoardingForm;
import Business_Methods.ICDD_CustomerRecord;
import Business_Methods.ICDD_WorkItem;
import Business_Methods.ICM_UpdateCustomerProfilePage;
import Object_Repository.ICDD_WorkItem_Obj;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;

public class ICDD_WorkItem_Glue extends Common_Utils {
	
	DataProvider dataprovider = new DataProvider();
	Common_Utils common = new Common_Utils();
	Login_Glue log = new Login_Glue();
	
	String scenarioName = log.excelHashMapValues.get("scenarioName");
	String sheetName = log.excelHashMapValues.get("sheetName");
	//public static HashMap<String, String> log.excelHashMapValues = new HashMap<String, String>();
	ICDD_WorkItem iCDD_WorkItem=new ICDD_WorkItem();
	ICDD_CustomerRecord ICDD_CustomerRecord = new ICDD_CustomerRecord();
	ICM_UpdateCustomerProfilePage iCM_UpdateCustomerProfilePage = new ICM_UpdateCustomerProfilePage();
	ICCD_OnBoardingForm ICCD_OnBoardingForm=new ICCD_OnBoardingForm();
	
	
	
	 @When("^logs into ICDD and navigates to the Workbench tab and selete Work Items section$")
	 public void logs_into_ICDD_and_navigates_to_the_tab_section() throws Throwable {
		 sleep(5000);
		 iCDD_WorkItem.Workbench();
		 }
	 
	 @Given("^navigates to the \"([^\"]*)\" in the dropdown view$")
	 public void navigates_to_the_in_the_dropdown_view(String arg1 ) throws Throwable {
		
		 String workitemSort = log.excelHashMapValues.get("WorkItem_Sort").trim()+" "+arg1;
		 iCDD_WorkItem.selectOptionsInMyItems(workitemSort);
		 sleep(minWaitVal);}
	 
	 @And("^navigate to the work item \"([^\"]*)\"$")
	 public void navigates_to_work_item(String workitem_sort) throws Throwable{
		 
		 iCDD_WorkItem.selectOptionsInMyItems(workitem_sort);
		 sleep(minWaitVal);
	 }
	 
	 @Then("^click on Workflow button$")
	 public void click_on_Workflow_button() throws Throwable {
		 sleep(minWaitVal);
		 webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
		 common.click(ICDD_WorkItem_Obj.WORKFLOW);
		}
	 
	 @And("check the unmandatory check \"([^\"]*)\"")
	 public void check_I_support(String checkbox) throws Throwable{
		 sleep(minWaitVal);
		 screenshot();
		 //BaseTestSetup.driver.switchTo().frame("frmDetails");
		 By ch=By.xpath("//td[contains(text(),'"+checkbox+"')]/../../../../../td[6]/table/tbody/tr/td[2]");
		 webDriverWait(ch);
		 ieButtonJSClick(ch);
		 sleep(minWaitVal);
		 screenshot();
		 //BaseTestSetup.driver.switchTo().defaultContent();
		 	
	 }
		
	 @Then("^the CDD Ops Maker clicks Check button on the mandatory task$")
	 public void the_CDD_Ops_Maker_clicks_Check_button_on_the_mandatory_task() throws Throwable {
		 iCDD_WorkItem.ValidateMandateCheck();
		}

	 @Then("^a trigger review alert should be found with Item Type as \"([^\"]*)\"$")
		public void a_trigger_review_alert_should_be_found_with_Item_Type_as(String arg1) throws Throwable {
		 	//dataprovider.extractExcelData(arg2, arg3, log.excelHashMapValues);
		 	ICDD_CustomerRecord.searchiccdId(scenarioName, log.excelHashMapValues);
		 	common.screenshot();
		 	ICDD_CustomerRecord.clickiccdid(scenarioName, log.excelHashMapValues);
		 	common.webDriverwait(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
		 	common.screenshot();
		 	common.click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
		 	common.webDriverwait(ICDD_WorkItem_Obj.SEARCH);
		 	common.screenshot();
		 	String alert = log.excelHashMapValues.get("ALERT_TYPE");
		 	common.enterInputText(ICDD_WorkItem_Obj.SEARCH, log.excelHashMapValues.get(alert));
		 	common.screenshot();
		 	iCDD_WorkItem.getIssueType(arg1);
    	    }
	 
	@And("^Get the second alert \"([^\"]*)\" \"([^\"]*)\"$") 
	public void step_filter_second_alert(String arg1,String arg2) throws FilloException, IOException, Exception{
		dataprovider.extractExcelData(arg1, arg2, log.excelHashMapValues);
    	ICDD_CustomerRecord.searchiccdId(arg2, log.excelHashMapValues);
    	ICDD_CustomerRecord.clickiccdid(arg2, log.excelHashMapValues);
	 	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);Thread.sleep(2000);
		iCDD_WorkItem.search_second_alert(log.excelHashMapValues, arg1, arg2);
		iCDD_WorkItem.assign_to_me();
    	System.out.print("done assign step");Thread.sleep(4000);
	}

		@Then("^Step column has Alert Step \"([^\"]*)\"$")
		public void step_column_has_Alert_Step(String expectedAlert) throws Throwable {
			try {
				Thread.sleep(2000);
				String actualAlert = iCDD_WorkItem.getAlertStep();
				if (actualAlert.equals(expectedAlert)) {
					System.out.println("Expected Alert step is: " + expectedAlert + ", Actual Alert of the customer is: " + actualAlert + ". And it matches");}
				else {
					System.out.println("Expected " + expectedAlert + " Actual Alert of the customer is " + actualAlert + " So it is not matched");}
			}
			catch (Exception e) {
				Assert.fail("Error while validating the Alert of the customer: " + e.getMessage());}
		 }

		@And("^the Risk Level column has value$")
		public void the_Risk_Level_column_has_value() throws Throwable {
			try {
				//dataprovider.extractExcelData(arg1, arg2, log.excelHashMapValues);
				String actualRiskScore = iCDD_WorkItem.getRiskLevel();
				if (actualRiskScore.equals(log.excelHashMapValues.get("Risk"))) {
					System.out.println("Expected risk Score is: " + log.excelHashMapValues.get("Risk") + ", Actual Alert Risk Level is: " + actualRiskScore + ". And it matches");}
				else {
					System.out.println("Expected " + log.excelHashMapValues.get("Risk") + " Actual RiskScore of the customer is " + actualRiskScore + " So it is not matched");}
			}
			catch (Exception e) {
				Assert.fail("Error while validating the riskscore of the customer: " + e.getMessage());}
	     }

		@Then("^the trigger review is s routed to the My work Items for the user who creates the manual Trigger alert\\.$")
		public void the_trigger_review_is_s_routed_to_the_My_work_Items_for_the_user_who_creates_the_manual_Trigger_alert() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			System.out.println("trigger routed");
			iCDD_WorkItem.checkAlertRoutedToUser();
		}
		
		@Given("^Assign the alert to other user \"([^\"]*)\"$")
	       public void assign_the_alert_to_other_user(String u_name) throws Throwable {
	               // Write code here that turns the phrase above into concrete actions
	             iCDD_WorkItem.assign_user(u_name);
	              
	           }

		
		@Then("^the Owner column has a ownerid name$")
		public void the_Owner_column_has_a_ownerid_name() throws Throwable {
			//dataprovider.extractExcelData(arg2, arg3, log.excelHashMapValues);
			iCDD_WorkItem.getIssue(log.excelHashMapValues);	
			
				
	     }
		
		 @When("^clicks the Assign icon in the top toolbar to open a Change Item User/BU window and click on OK$")
		    public void clicks_the_icon_in_the_top_toolbar_to_open_a_window() throws Throwable {
//		    	Thread.sleep(5000);
		    	iCDD_WorkItem.verify_ref_id();
		    	iCDD_WorkItem.click_ref_id_checkbox();
		    	iCDD_WorkItem.assign_to_me();
		    	System.out.print("done assign step");Thread.sleep(4000);
		 }
		
			
		@When("^filter the alert with the \"([^\"]*)\"$")
		    public void filter_the_alert_with_the(String arg3) throws Throwable {
		    	//query with the scenario id for the party key
		    	String alertType = log.excelHashMapValues.get(arg3);
		    	iCDD_WorkItem.searchcustomeralerts(log.excelHashMapValues.get(alertType));
		    	//ICCD_OnBoardingForm.primaryOnBoardingForm(Scenario_Name, log.excelHashMapValues);
//		    	waitForTextToLoad(By.xpath("//span[@class='clsViewChangerTitle']"), "Customer Alerts");
//		        enterInputText(By.xpath("//input[@id='toolbarFilterTextArea']"), log.excelHashMapValues.get(alertType));
//		        String date = getCurrentDate();
		    	}
		
		@And("^Open the filtered alert \"([^\"]*)\"$")
		public void open_filtered_Alert(String arg)throws Throwable {
			String alertType = log.excelHashMapValues.get(arg);
			String alertnum=log.excelHashMapValues.get(alertType);
			iCDD_WorkItem.Open_filtered_Alert(alertnum);
			
		}
		
		@And("^open customer alerts \"([^\"]*)\" \"([^\"]*)\"$")
		public void open_customer_alerts(String arg2, String arg3)throws Throwable {
			dataprovider.extractExcelData(arg2, arg3, log.excelHashMapValues);
	    	ICDD_CustomerRecord.searchiccdId(arg2, log.excelHashMapValues);
	    	ICDD_CustomerRecord.clickiccdid(arg2, log.excelHashMapValues);
	    	webDriverwait(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
	    	waitForTextToLoad(ICDD_WorkItem_Obj.CUSTOMER_ALERT, "Customer Alerts");
	    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		}
		
		@Given("^Search Customer and filter \"([^\"]*)\"$")
		public void search_Customer_and_filter(String arg3) throws Throwable {			
	    	ICDD_CustomerRecord.searchiccdId(scenarioName, log.excelHashMapValues);
	    	ICDD_CustomerRecord.clickiccdid(scenarioName, log.excelHashMapValues);
	    	String alertType = log.excelHashMapValues.get(arg3);
	    	iCDD_WorkItem.searchOpenAlerts(log.excelHashMapValues.get(alertType), log.excelHashMapValues);
		}
		
		@Given("^Search Customer and filter the second alert \"([^\"]*)\" \"([^\"]*)\"$")
		public void search_Customer_and_filter_the_second_Alert(String arg2, String arg3) throws Throwable {
			dataprovider.extractExcelData(arg2, arg3, log.excelHashMapValues);
	    	ICDD_CustomerRecord.searchiccdId(arg2, log.excelHashMapValues);
	    	ICDD_CustomerRecord.clickiccdid(arg2, log.excelHashMapValues);
	    	iCDD_WorkItem.searchOpenAlerts(log.excelHashMapValues.get("SECOND_ALERT"), log.excelHashMapValues);
		}
		
		@Given("^assign the alert to me$")
		public void assign_the_alert_to_me() throws Throwable {
		}
		
		@Given("^verifies the \"([^\"]*)\" in workflow \"([^\"]*)\"$")
		public void verifies_the_in_workflow(String arg1, String arg2) throws Throwable {
			//Verify alert 1 or 2 
		}
		
		@Given("^changes its alert step to \"([^\"]*)\"$")
		public void changes_its_alert_step_to(String arg1) throws Throwable {
		}

		@Given("^the Periodic Review alert is in the \"([^\"]*)\" queue$")
		public void the_Periodic_Review_alert_is_in_the_queue(String arg1) throws Throwable {
			
		}

		
     @Then("^trigger review alert has been assigned to the CDD Ops Maker$")
     public void trigger_review_alert_has_been_assigned_to_the_CDD_Ops_Maker() throws Throwable {
       System.out.println("Triggger Review is Assigned Sucessfully");
     }
     
     @When("^verify a new trigger review alert2 with Risk Level \"([^\"]*)\" is generated for the ETB Client$")
     public void verify_a_new_trigger_review_alert_with_Risk_Level_is_generated_for_the_ETB_Client(int arg1, String arg2) throws Throwable {
     }
     
     @When("^Verify Trigger review for second alert \"([^\"]*)\"$")
     public void verify_Trigger_review_for_second_alert(String arg1) throws Throwable {
     }

     
     @Then("^CDD Ops Maker should see customer updated static data as described in the feature in the beginning of this script \"([^\"]*)\"$")
 	public void cdd_Ops_Maker_should_see_customer_updated_static_data_as_described_in_the_feature_in_the_beginning_of_this_script(String scenarioName) throws Throwable {
    	 iCDD_WorkItem.expandButton();
    	// iCDD_WorkItem.ICDD_Verify_StaticdataChangeAndCustomerInfo(scenarioName, log.excelHashMapValues);
    	 iCDD_WorkItem.ICDD_Verify_StaticdataChangeAndCustomerInfo(scenarioName, log.excelHashMapValues);
     }
     
 	@Then("^click on alert$")
	public void click_on_alert() throws Throwable {
		iCDD_WorkItem.click_ref_id();
		Thread.sleep(3000);
	}
 	
	@When("^clicks on view notes$")
	public void clicks_on_view_notes() throws Throwable {
		iCDD_WorkItem.viewNote();
	}
	
	 @And("check button becomes \"([^\"]*)\"$")
		public void check_button_becomes(String arg1) throws Throwable {
	    	iCDD_WorkItem.verify_uncheck_button(arg1);
		    
		}
	 @When("^it is assigned to the Consolidate P Rating Approval for checking$")
		public void it_is_assigned_to_the_Consolidate_P_Rating_Approval_for_checking() throws Throwable {
		    System.out.print("it is assigned to the Consolidate P Rating Approval for checking");
		    Thread.sleep(3000);
		}
	  @Then("^alert moves to Submit to Checker step for SALT Checker Approval$")
	     public void alert_moves_to_Submit_to_Checker_step_for_SALT_Checker_Approval() throws Throwable {
	         System.out.println("alert moves to Submit to Checker step for SALT Checker Approval");
	     }

	
	@Then("^alert should be found with Item Type as \"([^\"]*)\"$")
	public void alert_should_be_found_with_Item_Type_as(String Scenario_Name) throws Throwable {
		try {
			dataprovider.extractExcelData(Scenario_Name, log.excelHashMapValues);
            String actualItemType = iCDD_WorkItem.getIssueType();
            if (actualItemType.equals(log.excelHashMapValues.get("Item_Type"))) {
                System.out.println("Expected Item Type is: " + log.excelHashMapValues.get("Item_Type") + ", Actual Item Type is: " + actualItemType + ". And it matches");}
            else {
                System.out.println("Expected " + log.excelHashMapValues.get("Item_Type") + " Actual Item Type is " + actualItemType + " So it is not matched");}
    	    }
    	 catch (Exception e) {
            Assert.fail("Error while validating the Item Type of the customer: " + e.getMessage());}

	 }
    
     	@And("^user selects \"([^\"]*)\" from the Next Steps dropdown$")
		public void user_selects_from_the_Next_Steps_dropdown(String next_value) throws Throwable {
     		System.out.println("Before next step");
			 iCDD_WorkItem.changestep(next_value);
			 System.out.println("After next step");
		}
     	@And("^New alert will be generated and click on ok$")
     	public void accept_new_alert() throws Throwable{
     		iCDD_WorkItem.Accept_new_generated_trigger();
     		System.out.println("Accepted new trigger");
     		
     	}
     	
     	@When("^CDD Maker click on the tag documents link under filenet documents actions and mandate Fill \"([^\"]*)\"$")
     	public void cdd_Maker_click_on_the_tag_documents_link_under_filenet_documents_actions_and_mandate_Fill(String scenarioName) throws Throwable {
		iCDD_WorkItem.ICDD_TagDoc_DocumentsLinkeclassify(scenarioName, log.excelHashMapValues);
		}
     	@Then("^User is able to see the document he/she tagged under Tagged Documents in ICDD Repository page loaded$")
     	public void user_is_able_to_see_the_document_he_she_tagged_under_Tagged_Documents_in_ICDD_Repository_page_loaded() throws Throwable {
 	   }

     	@When("^adds a mandatory note\"([^\"]*)\"$")
     	public void adds_a_mandatory_note(String scenarioName) throws Throwable {
    	 iCDD_WorkItem.addNote(scenarioName, log.excelHashMapValues);
 	}
     
     	@Given("^filter the Adverse Media Form by using step\"([^\"]*)\"and edit as per the requirement\"([^\"]*)\" \"([^\"]*)\"$")
     	public void editingTheForm(String form,String scenario, String sheet) throws Exception{
    	dataprovider.extractExcelData(scenario, sheet, log.excelHashMapValues);
    	iCDD_WorkItem.editPrviousForm(form);
    }
     	
 	@Then("^no trigger review alerts should be generated$")
 	public void no_trigger_review_alerts_should_be_generated() throws Throwable {
 	   
 	}
	@Then("^alert moves to Submit to Checker step for SAT Checker Approval$")
	public void alert_moves_to_Submit_to_Checker_step_for_SAT_Checker_Approval() throws Throwable {
	   
	} 
	
	@Then("^trigger review alert has been assigned to SAT Checker$")
	public void trigger_review_alert_has_been_assigned_to_SAT_Checker() throws Throwable {
	
	}
	
	@When("^SAT Checker clicks into the trigger review alert$")
	public void sat_Checker_clicks_into_the_trigger_review_alert() throws Throwable {
		iCDD_WorkItem.click_ref_id();
	}
	
	@When("^user selects \"([^\"]*)\" from the Next Steps dropdown and the alert step is \"([^\"]*)\" in the Step column$")
	public void user_selects_from_the_Next_Steps_dropdown_and_the_alert_step_is_in_the_Step_column(String next_value, String alert_step) throws Throwable {
		 iCDD_WorkItem.changestep(next_value);
	}

	@When("^it is automatically routed to \"([^\"]*)\"$")
	public void it_is_automatically_routed_to(String arg1) throws Throwable {
	   
	}
	
	@When("^verifies the trigger review alert information$")
	public void verifies_the_trigger_review_alert_information() throws Throwable {
	  
	}

	@When("^CDD Advisor selects taskname \"([^\"]*)\"$")
	public void cdd_Advisor_selects_taskname(String scenarioName) throws Throwable {
		iCDD_WorkItem.taskNameValidationCheck(scenarioName, log.excelHashMapValues);
	}

	@When("^it is assigned to the Business Head workgroup for checking$")
	public void it_is_assigned_to_the_Business_Head_workgroup_for_checking() throws Throwable {
	   
	}

	@Then("^CDD Ops Maker verifies no change in risk rating for client$")
	public void cdd_Ops_Maker_verifies_no_change_in_risk_rating_for_client() throws Throwable {
	    
	}
	
	@When("^Maker performs data entry with all data elements to create customer profile with product type as CASA$")
	public void maker_performs_data_entry_with_all_data_elements_to_create_customer_profile_with_product_type_as_CASA() throws Throwable {
	    
	}

	@Then("^system creates a unique onboarding id for the NTB client and awaits approval in ICDD system$")
	public void system_creates_a_unique_onboarding_id_for_the_NTB_client_and_awaits_approval_in_ICDD_system() throws Throwable {
	    
		
	}

	@Then("^Onboarding alert has been assigned to the CDD Maker$")
	public void onboarding_alert_has_been_assigned_to_the_CDD_Maker() throws Throwable {
	    
	}

	@Then("^the alert step is \"([^\"]*)\" in the Step column$")
	public void the_alert_step_is_in_the_Step_column(String arg1) throws Throwable {
	    	
	}

	@Then("^the CDD status is \"([^\"]*)\"$")
	public void the_CDD_status_is(String arg1) throws Throwable {
	    
	}

	@Then("^Onboarding alert has been assigned to the CDD Checker$")
	public void onboarding_alert_has_been_assigned_to_the_CDD_Checker() throws Throwable {
	   
	}

	@Then("^alert step is \"([^\"]*)\" in the Step column$")
	public void alert_step_is_in_the_Step_column(String arg1) throws Throwable {
	    
	}

	@Then("^CDD status is \"([^\"]*)\"$")
	public void cdd_status_is(String arg1) throws Throwable {
	    	}

	@Then("^CDD Ops Checker matches the client information with Customer Highlights & Customer profile tab$")
	public void cdd_Ops_Checker_matches_the_client_information_with_Customer_Highlights_Customer_profile_tab() throws Throwable {
	    
	}

	@Then("^the Checker completes client information validation$")
	public void the_Checker_completes_client_information_validation() throws Throwable {
	    
	}

	@Given("^CDD Ops Checker is able to select the next step \"([^\"]*)\"$")
	public void cdd_Ops_Checker_is_able_to_select_the_next_step(String arg1) throws Throwable {
	  
	}

	@When("^CDD Ops Checker navigates to \"([^\"]*)\" drop down$")
	public void cdd_Ops_Checker_navigates_to_drop_down(String arg1) throws Throwable {
	    
	}

	@When("^select \"([^\"]*)\"$")
	public void select(String arg1) throws Throwable {
	    
	}

	@Then("^System will reroute the workflow based on the risk rating$")
	public void system_will_reroute_the_workflow_based_on_the_risk_rating() throws Throwable {
	    
	}

	@Then("^as this is a primary rated \"([^\"]*)\", the Step will be marked as \"([^\"]*)\"$")
	public void as_this_is_a_primary_rated_the_Step_will_be_marked_as(String arg1, String arg2) throws Throwable {

	}

	@Then("^CDD Status is \"([^\"]*)\" in Customer Highlight section$")
	public void cdd_Status_is_in_Customer_Highlight_section(String arg1) throws Throwable {
	    
	}

	@Then("^the Onboarding alert status is closed - Alert indicator is greyed out$")
	public void the_Onboarding_alert_status_is_closed_Alert_indicator_is_greyed_out() throws Throwable {
	   
	}

	@Then("^ICM has been updated with the new Primary client information and product information$")
	public void icm_has_been_updated_with_the_new_Primary_client_information_and_product_information() throws Throwable {
	    
	}

	@Given("^Search Customer and filter MANUAL_TRIGGER_ALERT_ID \"([^\"]*)\" \"([^\"]*)\"$")
	public void search_Customer_and_filter_MANUAL_TRIGGER_ALERT_ID(String arg1, String arg2) throws Throwable {
	    
	}

	@Then("^check the Account profile tab that account/product has been setup correctly$")
	public void check_the_Account_profile_tab_that_account_product_has_been_setup_correctly() throws Throwable {
	   
	}


	
	
 
}
