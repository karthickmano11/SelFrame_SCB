package Step_Defination;

import java.awt.Robot;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.codoid.products.exception.FilloException;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;

import Business_Methods.ICCD_OnBoardingForm;
import Business_Methods.ICDD_COSApp;
import Business_Methods.ICDD_CustomerRecord;
import Business_Methods.ICDD_WorkItem;
import Business_Methods.ICM_UpdateCustomerProfilePage;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utillities.BaseTestSetup;
import utillities.DataProvider;
import utillities.GenericWrapper;
import utillities.SetupPropertiesLoader;
import utillities.Common_Utils;

public class Login_Glue {
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	Common_Utils Common = new Common_Utils();
	ICDD_WorkItem iCDD_WorkItem=new ICDD_WorkItem();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	public String browserName = "";
	ICDD_COSApp cs = new ICDD_COSApp();
	ICCD_OnBoardingForm ICDD_Onboarding_form = new ICCD_OnBoardingForm();
	/*String browserProp = SetupPropertiesLoader.getProperty("browser", "directory");
	String urlProp = SetupPropertiesLoader.getProperty("url1", "directory");*/
	private Scenario scenario;
	
/*	static {
		try {
			BaseTestSetup.setDriver("chrome", SetupPropertiesLoader.getProperty("ICM_Url", "directory"));
		} catch (Exception e) {
		}
	};*/
	
	

	@Before
    public void before(Scenario scenario){
		this.scenario = scenario;    	
    	System.out.println("###########################################");
    	System.out.println(scenario.getName());    	
    	StringBuffer  fileName= new StringBuffer();    	    
    	StringBuffer scenarioName = new StringBuffer();
    	StringBuffer sheetName = new StringBuffer();
    	System.out.println("################################################################");
    	scenarioName.append(scenario.getName());
    	System.out.println(scenarioName.toString());
    	fileName.append(scenarioName.substring(scenarioName.indexOf("~~")+2, scenarioName.indexOf("~@")).trim().replace("\"", ""));
    	System.out.println(fileName.toString());
    	sheetName.append(scenarioName.substring(scenarioName.indexOf("~@")+2).trim().replace("\"", ""));
    	System.out.println(sheetName.toString());
    	scenarioName.append(scenarioName.substring(0, scenarioName.indexOf("~~")).trim());
    	DataProvider dataprovider = new DataProvider();
    	excelHashMapValues.put("scenarioName", fileName.toString());
    	excelHashMapValues.put("sheetName", sheetName.toString());
    	
		try {
			dataprovider.extractExcelData(fileName.toString(), sheetName.toString(), excelHashMapValues);
		} catch (FilloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	GenericWrapper gw = new GenericWrapper();
        gw.CreateScreenshotDoc(fileName.toString(), scenarioName.toString());
    		
    	
    }
	
	
	@After
	public void after(){
/*//		BaseTestSetup.driver.close();
//		BaseTestSetup.driver.quit();
*/		
	}
	public String browserName(String browser) {
		  Capabilities caps = ((RemoteWebDriver) BaseTestSetup.driver).getCapabilities();
		  browserName = caps.getBrowserName();
		  System.out.println(browserName);
		return browserName;
		} 
	
	@Given("^ICM Application \"([^\"]*)\" is launched in browser$")
	public void icm_application_browser_is_launched(String arg1) throws Throwable {
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
		else {
			browserName(browserName);
			if( browserName.equals("chrome")){
				BaseTestSetup.driver.navigate().to(SetupPropertiesLoader.getProperty(arg1, "directory"));}
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	   }
	@Given("^Launch the \"([^\"]*)\" Application in chrome browser$")
	public void RTOB_browser_launch(String arg1) throws Exception{
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
		else {
			browserName(browserName);
			if( browserName.equals("chrome")){
				BaseTestSetup.driver.navigate().to(SetupPropertiesLoader.getProperty(arg1, "directory"));}
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	}
	
	@Given("^SCB Bridge Application is launched in browser \"([^\"]*)\" \"([^\"]*)\"$")
		public void browser_is_launched(String arg1, String arg2) throws Throwable {
		if(BaseTestSetup.driver == null){
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty("SCB_Bridge", "directory"));}
				else {
					browserName(browserName);
					if( browserName.equals("chrome")){
						BaseTestSetup.driver.navigate().to(SetupPropertiesLoader.getProperty("SCB_Bridge", "directory"));}
					else{
						BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty("SCB_Bridge", "directory"));
						}
				}
				ICDD_CustomerRecord ICDD_CustomerRecord = new ICDD_CustomerRecord();
				dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
				ICDD_CustomerRecord.bridge(arg1, excelHashMapValues, arg2);
	}

/* ---------------------------------------------------------------------
    Method Name: iccd_Application_Browser_is_launched
    Description: Launch Application.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/		
	@Given("^ICDD Application \"([^\"]*)\" is launched in browser$")	
	public void iccd_Application_Browser_is_launched(String arg1) throws Throwable {
		
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
		else {
			browserName(browserName);
			if( browserName.equals("internet explorer")){
				BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	   }
		
	/*@When("^\"([^\"]*)\" logged into RTOB application$")
	public void logged_into_RTOB_application(String UserName) throws Exception {
		try {
			if (UserName != null) {
			   String adminUserName = SetupPropertiesLoader.getProperty(UserName,"roles");
			   String adminPassword = SetupPropertiesLoader.getProperty("RTOB_pwd", "roles");
				if (adminUserName != null && adminPassword != null) {
					Common.screenshot();
					RTOB.RTOB_login(adminUserName, adminPassword);
				    System.out.println("################# "+ UserName + "Logged into ICDD Application successfully ################");
				    Log.info("################# "+ UserName + "Logged into ICDD Application successfully ################");
				}
				else {
				    throw new Exception("Error: User name or password is not set in roles.properties file");
				}
		   }
		}
		catch (Exception e) {
		    throw new Exception("Login failed" + " :" + e.getMessage());
		}
	}*/
	
	
/* ---------------------------------------------------------------------
    Method Name: cdd_Maker_is_able_to_log_as_in_ICDD
    Description: Step defination of login into ICDD Application.
    Author: Karthik & Swathi
------------------------------------------------------------------------*/	    
    @Given("^CDD Maker is able to log as \"([^\"]*)\" in ICDD$")
    public void cdd_Maker_is_able_to_log_as_in_ICDD(String userName) throws Throwable { 
		try {
			System.out.println("Entered Step 2");
			if (userName != null) {
			   String adminUserName = SetupPropertiesLoader.getProperty(userName,"roles");
			   String adminPassword = SetupPropertiesLoader.getProperty("password1", "roles");
				if (adminUserName != null && adminPassword != null) {
					Common.screenshot();
					iCDD_WorkItem.loginApplication(adminUserName, adminPassword);
				    System.out.println("################# "+ userName + "Logged into ICDD Application successfully ################");
				    Log.info("################# "+ userName + "Logged into ICDD Application successfully ################");
				}
				else {
				    throw new Exception("Error: User name or password is not set in roles.properties file");
				}
		   }
		}
		catch (Exception e) {
		    throw new Exception("Login failed" + " :" + e.getMessage());
		}
    }
    
	   @Then("^logout actimize system$")
	    public void logout_Actimize_system() throws Exception {
	    	iCDD_WorkItem.logout();
	    }
	   
/* ---------------------------------------------------------------------
		Method Name: cos_Application_is_launched_in_browser
		Description: Step Defination for the lauching the COS Application
		Author: Sathish A
------------------------------------------------------------------------*/
    
	   @Given("^Launch the \"([^\"]*)\" Application in the browser$")
	   public void cos_Application_is_launched_in_browser(String arg1) throws Throwable {	  
		   
		   if(arg1.equals("COS")){
			   if(BaseTestSetup.driver == null){
					BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
				else {
					browserName(browserName);
					if( browserName.equals("internet explorer")){
						BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
					else{
						BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
					}
		   }else{
			   if(BaseTestSetup.driver == null){
					BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser2", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
				else {
					browserName(browserName);
					if( browserName.equals("internet explorer")){
						BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
					else{
						BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
					}
		   }
	       // Write code here that turns the phrase above into concrete actions
		   
		   
		   
		   
	   }
	   
	 /* ---------------------------------------------------------------------
		Method Name: cos_Application_is_launched_in_browser
		Description: Step Defination for the lauching the COS Application
		Author: Sathish A
------------------------------------------------------------------------*/
   
	   @Given("^Launch the \"([^\"]*)\" fullfilment Application in the browser$")
	   public void cos_FullFilmentApplication_is_launched_in_browser(String arg1) throws Throwable {	  
		   
		   
			   if(BaseTestSetup.driver == null){
					BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory") + excelHashMapValues.get("Application_ID")	);}
				else {
					browserName(browserName);
					if( browserName.equals("internet explorer")){
						BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
					else{
						BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
					}
	       // Write code here that turns the phrase above into concrete actions
		   
	   }
	   
		 /* ---------------------------------------------------------------------
			Method Name: cos_Application_is_launched_in_browser
			Description: Step Defination for the lauching the COS Application
			Author: Sathish A
	------------------------------------------------------------------------*/
	   
		   @Given("^Launch the \"([^\"]*)\" fullfilment onboarding Application in the browser$")
		   public void cos_FullFilmentOnApplication_is_launched_in_browser(String arg1) throws Throwable {	  
			   
			   
				   if(BaseTestSetup.driver == null){
						BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory") + excelHashMapValues.get("Application_ID") + "&action=FULFILLMENT"	);}
					else {
						browserName(browserName);
						if( browserName.equals("internet explorer")){
							BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
						else{
							BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
						}
		       // Write code here that turns the phrase above into concrete actions
			   
		   }
/* ---------------------------------------------------------------------
		Method Name: user_is_able_to_logged_in_to_COS_Application
		Description: Step Defination for the login into the COS Application
		Author: Sathish A
------------------------------------------------------------------------*/	   
	   @Given("^\"([^\"]*)\" is able to logged in to COS Application$")
	   public void user_is_able_to_logged_in_to_COS_Application(String userName) throws Throwable {
	       // Write code here that turns the phrase above into concrete actions
			System.out.println("Entered Step 2");
			try{
			   String adminUserName = SetupPropertiesLoader.getProperty(userName,"roles");
			   String adminPassword = SetupPropertiesLoader.getProperty("password_Cos", "roles");
				if (adminUserName != null && adminPassword != null) {
					Common.screenshot();
					
					String homeWindow = cs.login_COSApplication(adminUserName, adminPassword);
					excelHashMapValues.put("homePageHandles", homeWindow);
				    System.out.println("################# "+ "Logged into COS Application successfully ################");
				    Log.info("################# "+ "Logged into COS Application successfully ################");
				
				
		   }
		}
		catch (Exception e) {
		    throw new Exception("Login failed" + " :" + e.getMessage());
		}
	   }
	   
/* ---------------------------------------------------------------------
		Method Name: user_is_able_to_logged_in_to_ICM_Application
		Description: Step Defination for the login into the ICM Application
		Author: Sathish A
------------------------------------------------------------------------*/
	   
	   @When("^ICM user logs into ICM Application \"([^\"]*)\" \"([^\"]*)\"$")
	   public void user_is_able_to_logged_in_to_ICM_Application(String userName, String country) throws Throwable {
	       // Write code here that turns the phrase above into concrete actions
			System.out.println("Entering UserName and Password");
			try{
			   String adminUserName = SetupPropertiesLoader.getProperty(userName,"roles");
			   String adminPassword = SetupPropertiesLoader.getProperty("ICM_Password", "roles");
				if (adminUserName != null && adminPassword != null) {
					Common.screenshot();
					ICM_UpdateCustomerProfilePage icm = new ICM_UpdateCustomerProfilePage();
					icm.login_ICMApplication(adminUserName, adminPassword, country);
				    System.out.println("################# "+ "Logged into ICM Application successfully ################");
				    Log.info("################# "+ "Logged into ICM Application successfully ################");
				
				
		   }
		}
		catch (Exception e) {
		    throw new Exception("Login failed" + " :" + e.getMessage());
		}
	   }
	   
	   
	@Given("^Application \"([^\"]*)\" is launched in browser$")	
	public void Application_Browser_is_launched(String arg1) throws Throwable {
		
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
		else {
			browserName(browserName);
			if( browserName.equals("internet explorer")){
				BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	   }
	
		
	
	@Given("^\"([^\"]*)\" logged into application$")
	public void login_norkom_application(String userName)throws Throwable{
		try {
			System.out.println("Logging in...");
			if (userName != null) {
			   String adminUName = SetupPropertiesLoader.getProperty(userName,"roles");
			   String adminPwd = SetupPropertiesLoader.getProperty("Norkom_pwd", "roles");
			   if (adminUName != null && adminPwd != null) {
					Common.screenshot();
					ICDD_Onboarding_form.Norkom_login(adminUName,adminPwd);
					System.out.println("################# "+ userName + "Logged into Application successfully ################");
				    Log.info("################# "+ userName + "Logged into Application successfully ################");
			   }
			}
		}
		catch (Exception e) {
		    throw new Exception("Login failed" + " :" + e.getMessage());
		}
	}
		
	  
}