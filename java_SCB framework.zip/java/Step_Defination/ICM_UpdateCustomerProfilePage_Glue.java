package Step_Defination;

import java.util.HashMap;

import Business_Methods.DataSync_ICDD_ICM;
import Business_Methods.ICCD_OnBoardingForm;
import Business_Methods.ICM_UpdateCustomerProfilePage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utillities.DataProvider;

public class ICM_UpdateCustomerProfilePage_Glue {
	
	ICM_UpdateCustomerProfilePage iCM_UpdateCustomerProfilePage=new ICM_UpdateCustomerProfilePage();
	DataProvider dataprovider = new DataProvider();
	DataSync_ICDD_ICM datasync = new DataSync_ICDD_ICM();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	
	@Given("^searches for client by ICM ID$")
	public void searches_for_client_by_ICM_ID() throws Throwable {	
	iCM_UpdateCustomerProfilePage.ICMInformation_validattion("",Login_Glue.excelHashMapValues);
	} 
    
    
	@Then("^verify updated CDD information from client which includes CDD risk code,CDD status, LRD,NRD ,ICM ID Relationship ID, CDD refernce number and determine that it matches with values in ICDD system$")
	public void verify_updated_CDD_information_from_client_which_includes_CDD_risk_code_CDD_status_LRD_NRD_ICM_ID_Relationship_ID_CDD_refernce_number_and_determine_that_it_matches_with_values_in_ICDD_system() throws Throwable {
		
		iCM_UpdateCustomerProfilePage.ICMInformation_validattion("",Login_Glue.excelHashMapValues);
		}
	
	@When("^Update CDD information for the client \"([^\"]*)\"$")
	public void update_CDD_information_for_the_client(String sTempValue) throws Throwable {	
		iCM_UpdateCustomerProfilePage.serachForIcmIdModify(Login_Glue.excelHashMapValues);
		iCM_UpdateCustomerProfilePage.ICM_Information_Modification(sTempValue, Login_Glue.excelHashMapValues);
		
	}
	
	@Then("^verify CDD information for \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_CDD_information_for(String arg1, String arg2) throws Throwable {
		
	}
	
	@Then("^check/copy the data to be verified in ICM \"([^\"]*)\" \"([^\"]*)\"$")
	public void check_copy_the_data_to_be_verified_in_ICM(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		datasync.ICM_Data(arg1, excelHashMapValues, arg2);
	}
	
	@Then("^check/copy the data to be verified in ICDD \"([^\"]*)\" \"([^\"]*)\"$")
	public void check_copy_the_data_to_be_verified_in_ICDD(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		datasync.ICDD_Data(arg1, excelHashMapValues, arg2);
	}

	@Then("^Verify the datasync between ICDD and ICM \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_the_datasync_between_ICDD_and_ICM(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		datasync.DataSyncVerify(arg1, excelHashMapValues, arg2);
	}
	@And("^Logout the ICM Application$")
	public void logut_ICM_Application(){
		iCM_UpdateCustomerProfilePage.ICM_Logout();
	}
	@And("^search the updated CDD information for the client \"([^\"]*)\"$")
	public void search_CDD_information(String sTempValue) throws Exception{
		iCM_UpdateCustomerProfilePage.ICMInformation_modifn_validattion(sTempValue, Login_Glue.excelHashMapValues);
	}
	@And("^user is able to click on the update button$")
	public void click_Update_Button(){
		iCM_UpdateCustomerProfilePage.updateChange_ICMApplication();
	}
	@Given("^that verify the existing risk rating of customer$")
	public void existing_riskRating() throws Exception{
		iCM_UpdateCustomerProfilePage.verify_existingRiskLevel(Login_Glue.excelHashMapValues);
	}
	
	@And("^Click on risk tab and take screenshot$")
	public void click_risk_tab() throws Exception{
		iCM_UpdateCustomerProfilePage.click_risk_tab();
	}
	
	@And("^Click on Cross Refernce tab and click on VIEW CLOSED PRODUCT check box to see all closed items$")
	public void Validating_Closed_Product() throws Exception{
		
		iCM_UpdateCustomerProfilePage.Validate_Closed_Products();
	}
	
	@And("^click on Basic tab and Status should be \"([^\"]*)\"$")
	public void Basic_tab_status(String status)throws Exception{
		
		iCM_UpdateCustomerProfilePage.Validate_staus_under_Basic_tab(status);
	}
	
	
	@And("^CDD Status should be \"([^\"]*)\"$")
	public void validate_cdd_status(String cddstatus) throws Exception{
		
		iCM_UpdateCustomerProfilePage.validate_CDD_Status(cddstatus);
	}
	
	@And("^riskcode HHP should be present \"([^\"]*)\"$")
	public void Validate_HHP_Presence(String riskcode) throws Exception{
		
		iCM_UpdateCustomerProfilePage.Validate_HHP(riskcode);
		
	}
	
	@And("^riskcode HHP should not be present \"([^\"]*)\"$")
	public void Validate_HHP_Should_not_Present(String riskcode)throws Exception{
		iCM_UpdateCustomerProfilePage.Validate_HHP_not_present(riskcode);
	}
	
	@And("^click on Cross Reference and validate joint account or not and take screen shot$")
	public void Validate_Joint_account()throws Exception{
		
		iCM_UpdateCustomerProfilePage.Validate_Joint_account(Login_Glue.excelHashMapValues);
	}
	
	@And("^Validate CDD Risk Code in ICM$")
	public void Validate_CDD_Risk_Code() throws Exception{
		String riskcode=Login_Glue.excelHashMapValues.get("Risk");
		iCM_UpdateCustomerProfilePage.Validate_CDD_Risk_code(riskcode);
	}
	@And("^User to Create profile in ICM$")
	public void Create_Profile_in_ICM() throws Exception{
		iCM_UpdateCustomerProfilePage.Create_Profile_ICM(Login_Glue.excelHashMapValues);
	}

}
