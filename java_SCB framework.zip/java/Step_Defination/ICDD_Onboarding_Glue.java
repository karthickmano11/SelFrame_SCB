package Step_Defination;

import java.util.HashMap;

import Business_Methods.ICCD_OnBoardingForm;
import Business_Methods.ICDD_Clsoing_Alerts;
import Business_Methods.ICDD_CustomerRecord;
import Business_Methods.ICDD_Forms;
import Business_Methods.ICDD_WorkItem;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import utillities.DataProvider;

public class ICDD_Onboarding_Glue {
	Login_Glue log = new Login_Glue();	
	String arg1 = log.excelHashMapValues.get("scenarioName");
	String arg2 = log.excelHashMapValues.get("sheetName");	
	ICDD_CustomerRecord ICDD_CustomerRecord=new ICDD_CustomerRecord();
	ICDD_WorkItem ICDD_WorkItem = new ICDD_WorkItem();
	ICDD_Clsoing_Alerts  icdd_closing_alert=new ICDD_Clsoing_Alerts();
	ICCD_OnBoardingForm icdd_Onboard = new ICCD_OnBoardingForm();

	@When("^Click on onboarding tab and create a \"([^\"]*)\" in ICDD$")
    public void Create_Customer_Using_ICDD_OB(String temp) throws Exception{          
	 	icdd_Onboard.primaryOnBoardingForm(arg1, log.excelHashMapValues,arg2,temp);
    }
	
	@And("^decision the Name screening alert$")
	public void decision_Namescreening() throws Exception{
		icdd_Onboard.dettica_decision(log.excelHashMapValues);
		
	}
	@When("^user resubmits OB application$")
	public void resubmits_OB_application() throws Exception{
		icdd_Onboard.resubmit_OB_application(log.excelHashMapValues);
	}
	@And("^Search and click convert RP customer in Onboarding tab$")
	public void search_customer_OB_tab() throws Exception
	{
		icdd_Onboard.Search_customer_OB_Tab(log.excelHashMapValues);
	}
	@And("^fill in the OB form$")
	public void fill_in_the_OB_form() throws Exception
	{
	 	icdd_Onboard.OB_Form_filling(arg1, log.excelHashMapValues, arg2);
	}
	
	
	
}
