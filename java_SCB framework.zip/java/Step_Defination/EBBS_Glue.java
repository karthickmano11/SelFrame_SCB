package Step_Defination;

import java.util.HashMap;

import Business_Methods.ICDD_CustomerRecord;
import Business_Methods.ICDD_WorkItem;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import utillities.DataProvider;

public class EBBS_Glue {

	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	ICDD_CustomerRecord ICDD_CustomerRecord=new ICDD_CustomerRecord();
	ICDD_WorkItem ICDD_WorkItem = new ICDD_WorkItem();
	
	
	@Given("^eBBS Application is launched in browser$")
	public void ebbs_Application_is_launched_in_browser() throws Throwable {
	}
	
	@Given("^user is logged as \"([^\"]*)\" into eBBSapp$")
	public void user_is_logged_as_into_eBBSapp(String arg1) throws Throwable {
	}

	@Given("^user validates the account details in eBBS \"([^\"]*)\"$")
	public void user_validates_the_account_details_in_eBBS(String arg1) throws Throwable {
	}



	
	
	
	
	
}
