package Step_Defination;

import java.awt.AWTException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.codoid.products.exception.FilloException;

import Business_Methods.ICDD_WorkItem;
import Business_Methods.ICM_UpdateCustomerProfilePage;
import Business_Methods.SAO_AC_Business;
import Object_Repository.SAO_Objects;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;
import utillities.GenericWrapper;
import utillities.SetupPropertiesLoader;

public class SAO_ACCOUNT_OPENING extends Common_Utils{
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	public static HashMap<String, String> JointHashMapValues=new HashMap<String, String>();
	public static String secondary_scenario_name=null;
	Common_Utils Common = new Common_Utils();
	//ICDD_WorkItem iCDD_WorkItem=new ICDD_WorkItem();
	SAO_AC_Business sao_business=new SAO_AC_Business();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	public String browserName = "";
	/*String browserProp = SetupPropertiesLoader.getProperty("browser", "directory");
	String urlProp = SetupPropertiesLoader.getProperty("url1", "directory");*/
	private Scenario scenario;	
	
	
	@Before
    public void before(Scenario scenario) throws FilloException, IOException{
    	this.scenario = scenario;
    	
    	System.out.println("###########################################");
    	System.out.println(scenario.getName());
    	StringBuffer scenarioName = new StringBuffer();
    	StringBuffer  fileName= new StringBuffer();
    	StringBuffer  sheetName = new StringBuffer();    
    	
    	System.out.println("################################################################");
    	scenarioName.append(scenario.getName());
    	System.out.println(scenarioName.toString());
    	fileName.append(scenarioName.substring(scenarioName.indexOf("~~")+2, scenarioName.indexOf("~@")).trim().replace("\"", ""));
    	System.out.println(fileName.toString());
    	sheetName.append(scenarioName.substring(scenarioName.indexOf("~@")+2).trim().replace("\"", ""));
    	System.out.println(sheetName.toString());
    	scenarioName.append(scenarioName.substring(0, scenarioName.indexOf("~~")).trim());
    	DataProvider dataprovider = new DataProvider();
		try {
			dataprovider.extractExcelData(fileName.toString(), sheetName.toString(), excelHashMapValues);
			excelHashMapValues.put("SheetName", sheetName.toString());
			
		} catch (FilloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
    	GenericWrapper gw = new GenericWrapper();
        gw.CreateScreenshotDoc(fileName.toString(), scenarioName.toString());
    	
    	
    }
	public String browserName(String browser) {
		  Capabilities caps = ((RemoteWebDriver) BaseTestSetup.driver).getCapabilities();
		  browserName = caps.getBrowserName();
		  System.out.println(browserName);
		return browserName;
		} 
	
	
	@Given("^SAO Application \"([^\"]*)\" is launched in browser$")
public void SAO_Application_Browser_is_launched(String arg1) throws Throwable {
		
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser2", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));

		}
		else {
			browserName(browserName);
			if( browserName.equals("internet explorer")){
				BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));
								
			}
			
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser2", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	   }
		
	@Given("^login into SAO application$")
	public void Login_SAO_Application() throws Throwable { 
		try {
			System.out.println("Entered into Login page");
			//if (userName != null) {
			   String adminUserName = SetupPropertiesLoader.getProperty("SAO_UserName","roles");
			   String adminPassword = SetupPropertiesLoader.getProperty("SAO_Password", "roles");
			   
				if (adminUserName != null && adminPassword != null) {
					Common.screenshot();
					sao_business.loginApplication(adminUserName, adminPassword);
				    System.out.println("################# "+ adminUserName + "Logged into SAO Application successfully ################");
				    Log.info("################# "+ adminUserName + "Logged into SAO Application successfully ################");
			    	  
				}
				else {
				    throw new Exception("Error: User name or password is not set in roles.properties file");
				}
		   //}
		}
		catch (Exception e) {
		    throw new Exception("Login failed" + " :" + e.getMessage());
		}
    }
	
	
    
	@And("^create New Application by filling the details$")
	public void Create_New_Application() throws Throwable{
		
		String ScenarioName = excelHashMapValues.get("ScenarioName");
		String SheetName = excelHashMapValues.get("SheetName");
		System.out.println("Scenario Name"+ScenarioName);
		System.out.println("Sheet Name"+SheetName);
		
		
		sao_business.Create_New_Application_Sourcing_Details(excelHashMapValues);
		
		//For Primary account
		String SAO_App_number=sao_business.Applicant_Key_Details(ScenarioName,excelHashMapValues,SheetName);
		excelHashMapValues.put("SAO_APPLICATION_NUMBER", SAO_App_number);
		
		//For joint customer only -- entering secondary customer details
		if(excelHashMapValues.get("IS_JOINT_ACCOUNT")!= null && !excelHashMapValues.get("IS_JOINT_ACCOUNT").isEmpty()){
		    secondary_scenario_name=ScenarioName.replace(ScenarioName.charAt(ScenarioName.length()-1),'2');
			System.out.println("Seconary scenario name"+secondary_scenario_name);
			dataprovider.extractExcelData(secondary_scenario_name, SheetName, JointHashMapValues);
			sao_business.Applicant_Key_Details(secondary_scenario_name,JointHashMapValues,SheetName);
		}
		
		
		//For Primary account
		sao_business.Applicant_Detais(excelHashMapValues);
		
		//For joint customer only -- entering secondary customer details
		if(excelHashMapValues.get("IS_JOINT_ACCOUNT")!= null && !excelHashMapValues.get("IS_JOINT_ACCOUNT").isEmpty())
		{
			ieButtonJSClick(SAO_Objects.SECONDARY_APPLICANT);
			sleep(minWaitVal);
			sao_business.Applicant_Detais(JointHashMapValues);
		}
		
		
		sao_business.Product_Selection(excelHashMapValues);
		sao_business.Service_Requested_CASA(excelHashMapValues);
		sao_business.Relationship_Package(excelHashMapValues);
    	sao_business.Banking_Services();
		sao_business.FATCA_CRS_Document(excelHashMapValues);
        sao_business.Document_Check_List(excelHashMapValues);
       
		sao_business.CDD(ScenarioName,secondary_scenario_name, excelHashMapValues, SheetName);
		
		}
	
	//Newly added code
	
	@And("^Click on New Application and fill sourcing details$")
	public void Create_New_App_and_Fill_Sourcing_Details() throws Exception{

		sao_business.Create_New_Application_Sourcing_Details(excelHashMapValues);
		
	}
	
	@And("^Fill Applicant Key Details$")
	public void Fill_Applicant_Key_Details() throws Exception{
		String ScenarioName = excelHashMapValues.get("ScenarioName");
		String SheetName = excelHashMapValues.get("SheetName");
		System.out.println("Scenario Name"+ScenarioName);
		System.out.println("Sheet Name"+SheetName);
		
		
		//For Primary account
		String SAO_App_number=sao_business.Applicant_Key_Details(ScenarioName,excelHashMapValues,SheetName);
		excelHashMapValues.put("SAO_APPLICATION_NUMBER", SAO_App_number);
				
		//For joint customer only -- entering secondary customer details
		if(!excelHashMapValues.get("IS_JOINT_ACCOUNT").isEmpty()){
	       secondary_scenario_name=ScenarioName.substring(0, ScenarioName.length()-1).concat("2");
	      //ScenarioName.replace(ScenarioName.charAt(ScenarioName.length()-1),'2');
		   System.out.println("Seconary scenario name"+secondary_scenario_name);
		   dataprovider.extractExcelData(secondary_scenario_name, SheetName, JointHashMapValues);
		   sao_business.Applicant_Key_Details(secondary_scenario_name,JointHashMapValues,SheetName);
				}
		
	}
	
	@And("^Fill Applicant Details$")
	public void Fill_Applicant_Details() throws Exception{
		
		//For Primary account
		if(!excelHashMapValues.get("IS_ETB").isEmpty())
		{
			sao_business.Applicant_Details_ETB(excelHashMapValues);
		}
		else{
		sao_business.Applicant_Detais(excelHashMapValues);
		}
		
		sleep(mediumWaitVal);
		
		//For joint customer only -- entering secondary customer details
		if(!excelHashMapValues.get("IS_JOINT_ACCOUNT").isEmpty())
		{
		   ieButtonJSClick(SAO_Objects.SECONDARY_APPLICANT);
		   sleep(minWaitVal);
		   
		   if(!JointHashMapValues.get("IS_ETB").isEmpty()){
			   sao_business.Applicant_Details_ETB(JointHashMapValues);
		   }
		   else{
		   sao_business.Applicant_Detais(JointHashMapValues);
		   }
		}
		
	}
	
	@And("^Fill Production Selection$")
	public void Fill_Product_Selection() throws Exception{
		sao_business.Product_Selection(excelHashMapValues);
		
	}
	
	@And("^Fill Service Requested CASA$")
	public void Fill_Service_Requested_CASA() throws Exception{
		
		sao_business.Service_Requested_CASA(excelHashMapValues);	
	}
	
	@And("^Fill The TDAccount Details$")
	public void Fill_TD_Account_Details() throws Exception
	{
		sao_business.Time_Deposit(excelHashMapValues);
	}
	
	@And("^Fill Relationship Package$")
	public void Fill_Relationship_Package() throws Exception{
		
		sao_business.Relationship_Package(excelHashMapValues);	
	}
	
	@And("^Fill Banking Services$")
	public void Fill_Banking_Services() throws Exception{
		
		sao_business.Banking_Services();
	}
	
	@And("^Fill FACTA CRA Document$")
	public void Fill_FACTA_CRA_Document() throws Exception{
		
		sao_business.FATCA_CRS_Document(excelHashMapValues);
	}
	
	@And("^Fill Document Checklist$")
	public void Fill_Document_CheckList() throws Exception{
		
		sao_business.Document_Check_List(excelHashMapValues);
	}
	
	@And("^Fill CDD and get ICDD Number and Update in MasterData Sheet$")
	public void Fill_CDD_And_Get_ICDD_Number() throws Exception{
		String ScenarioName = excelHashMapValues.get("ScenarioName");
		String SheetName = excelHashMapValues.get("SheetName");
		sao_business.CDD(ScenarioName,secondary_scenario_name, excelHashMapValues, SheetName);
		
	}
	
	
	
	
	@And("^Open the application and perfom full-fillment$")
	public void Open_SAO_App_Perform_fullfillment() throws Exception{
	
		sao_business.Search_SAO_app_Complete_fullfillment(excelHashMapValues);
		
	}
	
	@And("^Search for the SAO application number$")
	public void Search_SAO_app_application_number() throws Exception
	{
		sao_business.Search_SAO_app_application_number(excelHashMapValues);
	}
	
	@And("^Get the ICM Number in Fullfilment$")
	public void Get_the_ICM_Number_in_Fullfilment()
	{
		sao_business.Search_for_application_to_Get_ICM_Number(excelHashMapValues);
	}
	
	@And("^insert the ICM Number to The datasheet$")
	public void insert_the_ICM_Number_to_The_datasheet() throws Exception
	{
		String ScenarioName = excelHashMapValues.get("ScenarioName");
		String SheetName = excelHashMapValues.get("SheetName");
		
		if(!excelHashMapValues.get("IS_JOINT_ACCOUNT").isEmpty())
		{
		       secondary_scenario_name=ScenarioName.substring(0, ScenarioName.length()-1).concat("2");
			   System.out.println("Seconary scenario name"+secondary_scenario_name);
			   dataprovider.extractExcelData(secondary_scenario_name, SheetName, JointHashMapValues);
		}
    	
		
		String ICM = sao_business.Get_ICM_Number(ScenarioName,secondary_scenario_name,excelHashMapValues,SheetName);
		excelHashMapValues.put("icmId", ICM);
	}
	@And("^Open the application for rejected customer$")
    public void Open_Application_Rejected_Customer()
    {
         sao_business.Open_Application_Rejected_Customer(excelHashMapValues);
    }

	@Then("^Logout SAO application$")
	public void Logout_SAO(){
		sao_business.Logout_SAO_application();
	}

	@Then("^Close the Current Browser$")
	public void Close_the_Current_Browser()
	{
		sao_business.Close_Browser();
	}
	
	
}
