package Step_Defination;

import java.awt.AWTException;

import Business_Methods.ICDD_COSApp;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import utillities.BaseTestSetup;

public class ICDD_CosApp_Glue {
	Login_Glue login = new Login_Glue();
	ICDD_COSApp cs = new ICDD_COSApp();

	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_click_on_the_create_new_button Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@When("^User click on the create new button and proceed with basic Details of the applicant$")
	public void user_click_on_the_create_new_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		cs.createnew_COSApplication(login.excelHashMapValues);
	}

	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_click_on_the_create_new_button Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^User proceed to select the product details of the applicant$")
	public void user_Proceed_ProductDetails() throws Throwable {
		cs.cos_ProductDetails(login.excelHashMapValues);
		
	}
	
	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_Proceed_ApplicantDetails Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^User to fill the applicant details in AIP Screen$")
	public void user_Proceed_ApplicantDetails() throws Throwable {
		cs.cos_customerDetailedView(login.excelHashMapValues);
		
	}
	
	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_Proceed_ApplicantDetails Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^User to fill the applicant details in CrossSell Screen$")
	public void user_Proceed_CrossSell() throws Throwable {
		cs.cos_CrossSell(login.excelHashMapValues);
		
	}
	
	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_Proceed_ApplicantDetails Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^User to fill the applicant details in DataCompletion Screen$")
	public void user_Proceed_DataCompletion() throws Throwable {
		cs.cos_DataCompletion(login.excelHashMapValues);
		
	}	

	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_Proceed_OfferConfirmation Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^User to fill the applicant details in Offer Confrimation Screen$")
	public void user_Proceed_OfferConfirmation() throws Throwable {		
		cs.cos_OfferConfirmation(login.excelHashMapValues);
		
	}	
	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_Proceed_OfferConfirmation Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^User to fill the applicant details in Assign KIV in DocumentHandling Screen$")
	public void user_Proceed_AssignKIV_DocumentHandling() throws Throwable {	
		
		cs.cos_DocumentHandling(login.excelHashMapValues);
	}	
	
	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_Proceed_OfferConfirmation Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^Find and Select the application in \"([^\"]*)\"$")
	public void find_Select_Application(String sTempValue) throws Throwable {	
		switch (sTempValue) {
		case "Create New":
			cs.find_Application_ID(login.excelHashMapValues);
			break;
		case "KIV":
			cs.Find_Select_Application_KIV_Process(login.excelHashMapValues);
			break;
		case "Document Handling":
			cs.find_Assigned_Application_DocumentHandling(login.excelHashMapValues);
			
			break;
		case "Verification":
			cs.find_Appliaction_Verification(login.excelHashMapValues);
			break;
			
		case "Final Decision":
			cs.find_Appliaction_Final_Decision(login.excelHashMapValues);
			break;
		case "Offer Confirmation":
			cs.find_Appliaction_OfferConfirmation(login.excelHashMapValues);
			break;
		case "Credit Initiation":
			cs.find_Appliaction_CreditInitiation(login.excelHashMapValues);
		default:
			break;
		}
		
	}	
	/*
	 * ---------------------------------------------------------------------
	 * Method Name: user_Proceed_OfferConfirmation Description: Step
	 * Defination for click on the create new button in the COS Application and
	 * move to the COS Form Author: Sathish A
	 * ------------------------------------------------------------------------
	 */
	@And("^process the KIV application$")
	public void process_KIV_application() throws Throwable {	
		cs.cos_Document_Waiver_KIV(login.excelHashMapValues);
		
	}
	
	
	@And("^Waiver Process in Document Handling$")
	public void waiver_Process_DocumentHandling() throws Exception{
		cs.cos_Waived_DocumentHandlingProcess(login.excelHashMapValues);
	}
	
	@And("^Process the Verification$")
	public void process_Verification() throws Exception{
		cs.cos_Verification(login.excelHashMapValues);
	}
	
	@And("^Initiate the KIV$")
	public void initiate_KIV() throws Exception{
		cs.Raise_Kiv(login.excelHashMapValues);
	}
	
	@And("^Find and Release the application$")
	public void find_Release_the_application() throws Exception{
		cs.find_ReleaseApplication(login.excelHashMapValues);
	}
	
	@And("^Process the OfferConfirmation process$")
	public void process_OfferConfirmationprocess() throws InterruptedException, AWTException{
		cs.cos_OfferConfirmation_FD(login.excelHashMapValues);
	}
	
	@And("^Process the CreditInitiation process$")
	public void process_CreditInitiationprocess() throws Exception{
		cs.cos_CreditInitiation(login.excelHashMapValues);
	}
	
	 
	 @And("^user fetch the fulfilment Status$")
		public void process_fulfilmentStatus() throws Exception{
			cs.getFulfilmentStatus(login.excelHashMapValues);
		}
	@And("^Save and exit the Application$")
	public void save_Exit() throws Exception{
		cs.Save_Exit(login.excelHashMapValues);
	}

	@And("^Logout the Application$")
	public void logout_Close_Application() {
		cs.logout();
		
	}
	@And("^Quit the Application")
	public void Quit_Close_Application() {
		BaseTestSetup.driver.close();
		BaseTestSetup.driver.quit();
		
	}

	/*
	 * ---------------------------------------------------------------------
	 * Method Name: fill_the_customer_details_in_the_IdentifyTabs Description:
	 * Step Defination fill the customer details in the Identify Tab. Author:
	 * Sathish A
	 * ------------------------------------------------------------------------
	 */
	@When("^verify the customer$")
	public void fill_the_customer_details_in_the_IdentifyTabs() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@And("^Find the customer in homepage$")
	public void find_customer_homePage() throws Exception {
		cs.find_Application_ID(login.excelHashMapValues);
	}

}
