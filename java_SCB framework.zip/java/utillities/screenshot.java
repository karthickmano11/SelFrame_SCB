package utillities;

import java.io.File;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.standardchartered.genie.util.FileUtils;
import utillities.BaseTestSetup;
import utillities.SetupPropertiesLoader;


public class screenshot {
	
	protected WebDriver driver;
	protected WebDriverWait wait;
	
	 public String screenshotDir = SetupPropertiesLoader.getProperty("screenshot_dir", "directory");
	
	 public void takeScreenshot(){
	      File scrFile = ((TakesScreenshot)BaseTestSetup.driver).getScreenshotAs(OutputType.FILE);
	      String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmssSSS").format(Calendar.getInstance().getTime());
	      int randNo=(int)Math.random() ;
	      String conString= String.valueOf(randNo);
	      timeStamp.concat(conString );
	      System.out.println("conString"+timeStamp);
	      try {
	          FileUtils.copy(scrFile, new File(screenshotDir + timeStamp + ".png"));
	      } catch (IOException e1) {
	          e1.printStackTrace();
	      }
	  }
	
}
