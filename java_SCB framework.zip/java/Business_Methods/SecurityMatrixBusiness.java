package Business_Methods;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.fasterxml.jackson.databind.deser.Deserializers.Base;


import Object_Repository.ICCD_OnboardingForm_Obj;
import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICDD_Forms_Obj;
import Object_Repository.ICDD_WorkItem_Obj;
import Object_Repository.SecurityMatrixObj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;

public class SecurityMatrixBusiness extends Common_Utils{

	//ICDD_WorkItem ICDD_WorkItem=new ICDD_WorkItem();
	ICDD_WorkItem ICDD_WorkItem=new ICDD_WorkItem();
	ICDD_CustomerRecord ICDD_CustomerRecord=new ICDD_CustomerRecord();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	
	public void Validate_WorkBench_WorkItem_Present() throws Throwable {
		
		//Checking workbench tab is present or not then checking work item is present or not then click work bench and validate page is loaded or not
		waitForElement(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB));
		//test
		mouseHoverClick_tab(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB, ICDD_WorkItem_Obj.WORKITEM);
		sleep(minWaitVal);
		screenshot();
		String work_items=BaseTestSetup.driver.findElement(SecurityMatrixObj.Work_items).getText();
		Assert.assertEquals("Work Items", work_items);
	
		
	}
	
	public void Validate_WorkBench_WorkItem_Not_Present() throws Throwable{
		
		Assert.assertFalse(isWebElementPresent(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB));
		
	}
     public void Validate_WorkBench_Reports() throws Throwable {
		
		//Checking workbench tab is present or not
    	 try{
	    sleep(mediumWaitVal);
		screenshot();
	    waitForElement(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB));
	    mouseHoverClick_tab(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB, SecurityMatrixObj.Reports_Under_WorkBench);
		sleep(minWaitVal);
		Assert.assertTrue(BaseTestSetup.driver.findElement(SecurityMatrixObj.Reports_Label).isDisplayed());
    	 }
    	 catch(Exception e){
    		 System.out.println("Not able to open reports tab"+e.getMessage());
    	 }
		
	 }
     
     public void Validate_My_Reports_All_Reports() throws Throwable{
    	 
    	sleep(minWaitVal);
    	ieButtonJSClick(SecurityMatrixObj.dropdown_icon);
    	screenshot();
    	ieButtonJSClick(SecurityMatrixObj.All_Reports);
    	
    	
     }
     
	
	
	public void Validate_Customer_tab_Present() throws Exception{
		
			//checking customer tab is present or not and clicking on customer and validated customersearch field is displayed or not
			waitForElement(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
			Assert.assertTrue(isWebElementPresent(ICDD_CustomerRecord_Obj.CUSTOMER_TAB));
			ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_TAB);
			screenshot();
			
			waitForElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID);
			screenshot();
			Assert.assertTrue(isWebElementPresent(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID));
			
			
		
	}
	
	public void Validate_HomePage_tab_Present() throws Exception{
		
		
			//checking HomePage tab is present or not and clicking on HomePage and validating "Home Page" heading is loaded or not
			waitForElement(SecurityMatrixObj.Home_PAGE_TAB);
			Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Home_PAGE_TAB));
			ieButtonJSClick(SecurityMatrixObj.Home_PAGE_TAB);
	
			
			waitForElement(SecurityMatrixObj.Home_page_title);
			screenshot();
			Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Home_page_title));
			
					
	}
   public void validate_Onboarding_tab_Present() throws Exception{
		
		sleep(minWaitVal);
		webDriverwait(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		Assert.assertTrue(isWebElementPresent(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING));
		ieButtonJSClick(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		waitForElement(SecurityMatrixObj.OnBoarding_label);
	    screenshot();
	    Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.OnBoarding_label));
						
	}
   
    public void validate_Onboarding_tab_Not_Present() throws Exception{
		
		sleep(minWaitVal);
		Assert.assertFalse(isWebElementPresent(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING));
						
	}
	
		
	
	public void Validate_Reasearch_Dart_Present()throws Exception{
		
			//checking Reasearch tab is present or not and clicking on Reasearch and validating "DART" Label is loaded or not
			waitForElement(SecurityMatrixObj.Reasearch_tab);
			Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Reasearch_tab));

			mouseHoverClick_tab(SecurityMatrixObj.Reasearch_tab,SecurityMatrixObj.Dart_Under_Reasearch_tab);
			sleep(minWaitVal);
						
			waitForElement(SecurityMatrixObj.Dart_label);
			screenshot();
			Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Dart_label));
				
	}
	
	
	public void Validate_Reasearch_OnDemand_Reports_Not_Present()throws Exception{
		//Login with 1273626K
		//checking Reasearch tab is present or not and Reasearc_onDemand_report should not present
		//waitForElement(SecurityMatrixObj.Reasearch_tab);
		sleep(minWaitVal);
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Reasearch_tab));
		mouseOver(SecurityMatrixObj.Reasearch_tab);
		screenshot();
		sleep(2000);
		
		Assert.assertFalse(isWebElementPresent(SecurityMatrixObj.On_Demand_Reports));
		
		
		/*mouseOver(SecurityMatrixObj.Reasearch_tab);
		screenshot();
		sleep(2000);
		isWebElementPresent(SecurityMatrixObj.On_Demand_Reports);
		ieButtonJSClick(SecurityMatrixObj.On_Demand_Reports);
		screenshot();
	
	*/
			
   }
	public void Validate_Reasearch_OnDemand_Reports_Present()throws Exception{
		//Login with 1273626K
		//checking Reasearch tab is present or not and Reasearc_onDemand_report should not present
		//waitForElement(SecurityMatrixObj.Reasearch_tab);
		sleep(minWaitVal);
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Reasearch_tab));
		mouseOver(SecurityMatrixObj.Reasearch_tab);
		screenshot();
		sleep(2000);
		
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.On_Demand_Reports));
		mouseHoverClick_tab(SecurityMatrixObj.Reasearch_tab,SecurityMatrixObj.On_Demand_Reports);
		screenshot();
		sleep(minWaitVal);
		Assert.assertEquals("On-Demand Reports", BaseTestSetup.driver.findElement(SecurityMatrixObj.On_demand_report_label).getText());
		/*mouseOver(SecurityMatrixObj.Reasearch_tab);
		screenshot();
		sleep(2000);
		isWebElementPresent(SecurityMatrixObj.On_Demand_Reports);
		ieButtonJSClick(SecurityMatrixObj.On_Demand_Reports);
		screenshot();
	
	*/
			
   }
	
	public void Validate_Dashboard_Not_Present() throws Exception{
		
		sleep(minWaitVal);
		Assert.assertFalse(isWebElementPresent(SecurityMatrixObj.DashBoard_Tab));

	}
	
	
	//Search the cutsomer search and validate the alert
	
	public void Validate_Customer_alert(String ICDD_ID)  throws Exception{
		
		try{
		sleep(mediumWaitVal);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
		waitForElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID);
		Assert.assertTrue(isWebElementPresent(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID));
		
	    enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, ICDD_ID.trim());sleep(minWaitVal);
	    screenshot();
	    BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).sendKeys("");
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);
		screenshot();
		
		sleep(mediumWaitVal);
		waitForElement(By.xpath("//a[@class='customerLink'][text()='"+ICDD_ID+"']"));
		Assert.assertTrue(isWebElementPresent(By.xpath("//a[@class='customerLink'][text()='"+ICDD_ID+"']")));
		ieButtonJSClick(By.xpath("//a[@class='customerLink'][text()='"+ICDD_ID+"']"));
		screenshot();
		
		sleep(mediumWaitVal);
		waitForElement(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.CUSTOMER_ALERT));
		
		}
		catch(Exception e){			
			System.out.println("Not able to search the alert");		
		}	
	} 	
	
	//Check assign icon is present or not and click on that icon and validate the page
	
	public void Validate_Assign_Icon() throws Exception{
	
		try {
	     sleep(minWaitVal);
	     webDriverWait(ICDD_WorkItem_Obj.ASSIGN_TO_ME);
	     Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.ASSIGN_TO_ME));

	     //click on assign to me and verify assign to me by face icon
		ICDD_WorkItem.assign_to_me();
		ICDD_WorkItem.verify_assigntome();
				
	} catch (Exception e) {	
		System.out.println("assign icon validation has failed"+e.getMessage());
	}
  }
	
	//validate More Icon and validate view History option as well
	public void Validate_MoreTab_and_ViewHistory() throws Exception{
		
		try{
		sleep(minWaitVal);
		webDriverWait(SecurityMatrixObj.More_tab);
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.More_tab));
		
		mouseHoverClick(SecurityMatrixObj.More_tab,SecurityMatrixObj.View_History);
		screenshot();
		switchToWindow();
		Assert.assertTrue(getTitleOfWebPage().contains("[Actimize] View History"));
		screenshot();
		ieButtonJSClick(SecurityMatrixObj.Close_view_history);
		switchToParentWindow();
//				
		}
		catch(Exception e){
			
			System.out.println("View History under more icon has failed "+e.getMessage());	
		}		
	}
	
	
	//Validate Export icon and Export Option
	public void Validate_Export_Icon() throws Exception{
		
		//login with 1535755AN and click on work-bench , work-item and  Trigger Reviw- Alert Status
		try{
			sleep(minWaitVal);
			webDriverWait(SecurityMatrixObj.Export_Icon);
			Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Export_Icon));
			//mouseHoverClick_tab(SecurityMatrixObj.Export_Icon,SecurityMatrixObj.Export_Option);
			Actions act=new Actions(BaseTestSetup.driver);
			act.moveToElement(BaseTestSetup.driver.findElement(SecurityMatrixObj.Export_Icon)).doubleClick().build().perform();
			
			sleep(minWaitVal);
			screenshot();
			ieButtonJSClick(SecurityMatrixObj.Export_Option);
			sleep(mediumWaitVal);
			screenshot();
			
			
		}
		catch(Exception e){
			System.out.println("Validate Export icon has failed"+e.getMessage());	
		}
		
	}
	
	
	//validating list of Options should present under My Work Items
   public void Validate_My_WorkItems_Options_Present(HashMap<String, String> testData) throws Exception{
	   
	   ieButtonJSClick(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN);
	   screenshot();
	   List<String> listfromUI=new ArrayList<>();
	   List<WebElement> listOfOptions = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.WORKITEMS_ALL_OPTIONS);
	   for(WebElement wb:listOfOptions){
		   
		   listfromUI.add(wb.getText());
	   }
	   
	   //validating Expected_Present_list of options under My Work Items
	   try{
	   String[] Expected_present_list=testData.get("Expected_present_list").split("\\|");
	   for(String options:Expected_present_list){	
		   
		  Assert.assertTrue(listfromUI.contains(options));
	   }
	   }catch(Exception e){
		   System.out.println("Expected option under my work items is not present"+e.getMessage());
	   }
			  
   } 
   
 //validating list of Options should Not present under My Work Items
  public void Validate_My_WorkItems_Options_Not_Present(HashMap<String, String> testData) throws Exception{
	   
	   ieButtonJSClick(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN);
	   screenshot();
	   List<String> listfromUI=new ArrayList<>();
	   List<WebElement> listOfOptions = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.WORKITEMS_ALL_OPTIONS);
	   for(WebElement wb:listOfOptions){
		   
		   listfromUI.add(wb.getText());
	   }
	
	   //validating Expected_Not_Present_list of options under My Work Items
	   try{
	   String[] Expected_Not_present_list=testData.get("Expected_Not_present_list").split("\\|");
	   for(String options:Expected_Not_present_list){	
		   
		  Assert.assertFalse(listfromUI.contains(options));
	   }
	   }catch(Exception e){
		   System.out.println("Unexpected option under my work item is present"+e.getMessage());
	   }
      }
	
	
   
   //Enter icdd number in under on_boarding tag and validate the search list
   
    public void Validate_customer_under_Onboardingtab(HashMap<String, String> testData) throws Exception{
    	
    	//validate_Onboarding_tab_Present();
    	sleep(mediumWaitVal);
    	inputText(SecurityMatrixObj.ICDD_ID_Under_Onboarding, testData.get("ICDD_ID"));
    	screenshot();
    	ieButtonJSClick(SecurityMatrixObj.Search_Under_Onboarding);
    	sleep(maxWaitVal);

    	webDriverWait(By.xpath("//a[text()='"+testData.get("ICDD_ID")+"']"));
    	screenshot();
    	Assert.assertTrue(isWebElementPresent(By.xpath("//a[text()='"+testData.get("ICDD_ID")+"']")));
    	
    	ieButtonJSClick(By.xpath("//a[text()='"+testData.get("ICDD_ID")+"']"));
    	sleep(15000);
    	screenshot();
    	

 	
    }
    
  
    
    //Validating View_Notes Icon and click the icon and validate the notes page
   public void Validate_View_Notes() throws Exception{
	   
	   sleep(minWaitVal);
	   waitForElement(SecurityMatrixObj.View_Notes);
	   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.View_Notes));
	   screenshot();
	   
	   ieButtonJSClick(SecurityMatrixObj.View_Notes);
	   sleep(minWaitVal);
	   
	   switchToWindow();
	   sleep(minWaitVal);
	   BaseTestSetup.driver.manage().window().maximize();
	   sleep(minWaitVal);
	   screenshot();
	   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.View_Notes_Label));
	   ieButtonJSClick(SecurityMatrixObj.Close_button);
	   switchToParentWindow();
	  	   
	   
   }
   
   //Validating Print_List option
   public void Validate_Print_List() throws Exception{
	   
	   try{
	    sleep(minWaitVal);
		webDriverWait(SecurityMatrixObj.Export_Icon);
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Export_Icon));
		mouseHoverClick_tab(SecurityMatrixObj.Export_Icon,SecurityMatrixObj.Print_List);
		sleep(minWaitVal);
		switchToWindow();
		screenshot();
		ieButtonJSClick(SecurityMatrixObj.Print_list_close);
		switchToParentWindow();
		sleep(minWaitVal);
		
	   }
	   catch(Exception e){
		   System.out.println("validation of Print list has failed"+e.getMessage());
	   }	   
   }
   
   //Validating Send Mail option
   
   public void Validate_Send_Mail_Option() throws Exception{
	   
	   try{
		    sleep(minWaitVal);
			webDriverWait(SecurityMatrixObj.Export_Icon);
			Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Export_Icon));
			mouseHoverClick_tab(SecurityMatrixObj.Export_Icon,SecurityMatrixObj.Send_Mail);
			sleep(minWaitVal);
			screenshot();
			enterbyRobot();
		   }
		   catch(Exception e){
			   System.out.println("validation of 'Send Mail' has failed"+e.getMessage());
		   }	   
	 
   }
   
   
   //Validating View Attachment option
   //should login with 1535755AY to see this option
   public void Validate_View_attachments() throws Exception{
	   
	   try{
		   sleep(minWaitVal);
		   webDriverWait(SecurityMatrixObj.More_tab);
		   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.More_tab));
		   mouseHoverClick(SecurityMatrixObj.More_tab,SecurityMatrixObj.View_Attachments);
		   sleep(minWaitVal);
		   screenshot();
		   
		   switchToWindow();
		   sleep(minWaitVal);
		   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Cancel_button));
		   ieButtonJSClick(SecurityMatrixObj.Cancel_button);
		   switchToParentWindow();
		   
	   }catch(Exception e){
		   
		   System.out.println("Validation of view attachments has failed"+e.getMessage());
	   } 
   }
   
   //use "Validate_customer_under_Onboardingtab" method after the click and open the alert and update customer contact number
   
   public void Update_Contact_Number_in_OnBoarding(HashMap<String, String> testData)throws Exception{
	   
	   //ieButtonJSClick(By.xpath("//a[text()='"+testData.get("ICDD_ID")+"']"));
	   sleep(maxWaitVal);
	   webDriverWait(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS);
	   BaseTestSetup.driver.findElement(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS).clear();
	   enterInput(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS, testData.get("PHONEDETAILS"));
	   screenshot();
	   
	   Thread.sleep(1000);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SAVE);
	    Thread.sleep(7000);
	    screenshot();
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    Thread.sleep(18000);
	    screenshot();
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    Thread.sleep(10000);

	   
	   
   }
   /* ---------------------------------------------------------------------
	Method Name: Validate_Advance_filter
	Description: Validating advance filter having differnt number of size
	Author: sheefa
------------------------------------------------------------------------*/	
		
	
	
	public void Validate_Advance_filter() throws Exception{
		
		
			sleep(minWaitVal);
			
			//int prvious_num=getNumOFAlerts();	
			int prvious_num=BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
			
			sleep(minWaitVal);
			webDriverWait(SecurityMatrixObj.Advance_filter);
			Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Advance_filter));
			ieButtonJSClick(SecurityMatrixObj.Advance_filter);
			switchToWindow();
			sleep(minWaitVal);
			screenshot();
			BaseTestSetup.driver.findElement(SecurityMatrixObj.Risk_Level_colomn).clear();
			enterInputText(SecurityMatrixObj.Risk_Level_colomn, "6");
			enterInputText(SecurityMatrixObj.Risk_Level_colomn, "6");
			BaseTestSetup.driver.findElement(SecurityMatrixObj.Risk_Level_colomn).sendKeys(Keys.ENTER);
			sleep(minWaitVal);
			ieButtonJSClick(SecurityMatrixObj.Go_Filter);
			sleep(mediumWaitVal);
			switchToParentWindow();
			sleep(mediumWaitVal);
			
			//int After_filter_num=getNumOFAlerts();
			int After_filter_num=BaseTestSetup.driver.findElements(By.xpath("//*[@id='alertsModel']/tbody/tr")).size();
			
			if(prvious_num!=After_filter_num){
				Assert.assertTrue(true);
			}else{
				Assert.assertTrue(false);
			}	
			
		}
	
	
	public void Validate_maker_options()throws Exception
	{
		
		
		sleep(minWaitVal);
		webDriverWait(SecurityMatrixObj.Advance_filter);
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Advance_filter));
		ieButtonJSClick(SecurityMatrixObj.Advance_filter);
		switchToWindow();
		sleep(minWaitVal);
		screenshot();
		ieButtonJSClick(SecurityMatrixObj.status_filter_icon);
		sleep(minWaitVal);
		switchBackToParentWindow("[Actimize] Select Step");
		screenshot();
		
		List<WebElement> options = BaseTestSetup.driver.findElements(By.xpath("//*[@id='valuesSelect']/option"));
		List<String> text = new ArrayList<>();
		for(int i=1; i<options.size(); i++) {
		    text.add(options.get(i).getText());
		}
		
	    Assert.assertFalse(text.contains("Name Screening Resolution"));
	    Assert.assertFalse(text.contains("Perfom Checking - High Risk"));
	    Assert.assertFalse(text.contains("Perfom Checking - Low Risk"));
	    screenshot();
	    ieButtonJSClick(SecurityMatrixObj.status_filter_ok);
		sleep(minWaitVal);
		switchBackToParentWindow("[Actimize] Advanced Filter");
		screenshot();
		sleep(minWaitVal);
		ieButtonJSClick(SecurityMatrixObj.filter_cancel);
		//switchToWindow();
		screenshot();
		
			

	}

	public void Validate_Advance_filter_page(String reportType) {
       
		sleep(minWaitVal);
		webDriverWait(SecurityMatrixObj.Advance_filter_Reports);
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Advance_filter_Reports));
		ieButtonJSClick(SecurityMatrixObj.Advance_filter_Reports);
		switchToWindow();
		sleep(minWaitVal);
		screenshot();
		Assert.assertEquals("Advanced Filter", BaseTestSetup.driver.findElement(SecurityMatrixObj.Advance_filter_label).getText().trim());
		sleep(minWaitVal);
		selectDropdown(SecurityMatrixObj.Report_type, reportType);
		sleep(minWaitVal);
		screenshot();
		ieButtonJSClick(SecurityMatrixObj.Go_Filter);
		sleep(minWaitVal);
		switchToParentWindow();
		sleep(minWaitVal);

		
	}
	
	

   
   /*
     Method Name: 
     Description: Security Matrix method 
     Author     : Swathi
    
    */
   
   
   
   public void validateform(String scenarioName, HashMap<String, String> testData)
	{
			String[] expectedForms= testData.get("Perform_Review_Check_Forms").split("\\|");
			for(int i=0; i<expectedForms.length; i++){
				switch (expectedForms[i]){
				case "SOW":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.SOWFORM);
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
		
					break;
					
				case "PEP":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.PEP_EFORM);
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
					break;	
				
				case "AdverseMedia":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.ADVERSE_MEDIA_FORM);  
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
					break;	
					
				case "Tax-E":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.TAXE_FORM);
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
					break;
					
				case "AdditionalCDD":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.ADDITIONAL_CDD_FORM);
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
					break;
					
				case "CreateReviewChecklist":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CREATE_REVIEW_CHECKLIST_FORM);  
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
					break;
					
				case "Create Client Contact":
					sleep(minWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLIENT_CONTACT_FORM);
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
					break;
					
				case "Create UHNW":
					sleep(minWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.UHNW_FORM);
					switchToWindow();sleep(minWaitVal);
					Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
					break;
				
				}
			}
		}
	
	public void validateAddNotes(HashMap<String, String> testData) throws Exception{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.ADDNOTE));
		ieButtonJSClick(ICDD_WorkItem_Obj.ADDNOTE);
		sleep(mediumWaitVal);
       String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
	    Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
       for (String win : chwin1) { 
       if (!originalWindow1.equals(win)) {
       BaseTestSetup.driver.switchTo().window(win);
       sleep(minWaitVal);
       BaseTestSetup.driver.switchTo().frame("noteModelFreeTextNote_ifr");
       screenshot();
       BaseTestSetup.driver.findElement(ICDD_Forms_Obj.AM_NOTE).click();
	    List<WebElement> listOfOptions = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.WORKITEMS_ALL_OPTIONS);
	    for (WebElement option : listOfOptions) {
	    	Assert.assertEquals(option.getText(), "Free Text");
	    	break;}
	    for (WebElement option : listOfOptions) {
	    	Assert.assertEquals(option.getText(), "Predefined");
	    	break;}
	    actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
	    screenshot();
	    BaseTestSetup.driver.switchTo().defaultContent();
       ieButtonJSClick(ICDD_WorkItem_Obj.OKBUTTON);
       BaseTestSetup.driver.switchTo().window(originalWindow1);
	   // BaseTestSetup.driver.findElement(By.id("textButton_addNoteDialog_CancelButton")).click();
		}
	}
}
	
	
	
		public void validateCreateRFI(HashMap<String, String> testData) throws Exception
	       {
			     // ICDD_WorkItem.click_ref_id_checkbox();
	              Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.CREATE_RFI_ICON));
	              mouseHoverClick(ICDD_WorkItem_Obj.CREATE_RFI_ICON, ICDD_WorkItem_Obj.CREATE_RFI);
	              switchToWindow();sleep(minWaitVal);
	              Assert.assertEquals("Create RFI", BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.RFI_TITLE).getText());
	              screenshot();
	              //test
	              inputText(ICDD_WorkItem_Obj.RFI_NAME, testData.get("RFI_NAME"));
	              inputText(ICDD_WorkItem_Obj.MAIL_TO, testData.get("MAIL_TO"));
	              inputText(ICDD_WorkItem_Obj.SUBJECT, testData.get("SUBJECT"));
	              inputText(ICDD_WorkItem_Obj.BODY, testData.get("BODY"));
	              screenshot();
	              ieButtonJSClick(ICDD_WorkItem_Obj.SEND_BUTTON);
	              sleep(maxWaitVal+2000);
	              Assert.assertTrue(BaseTestSetup.driver.findElement(By.xpath("//*[@class='successMessage']")).getText().contains("RFI created but there was an error in sending the message"));       
	              screenshot();
	              ieButtonJSClick(SecurityMatrixObj.RFI_close);
	              switchToParentWindow();
	              
	       }

	
	public void validateViewRFI() throws Exception
	{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.CREATE_RFI_ICON));
		mouseHoverClick(ICDD_WorkItem_Obj.CREATE_RFI_ICON, ICDD_WorkItem_Obj.VIEW_RFI);
		screenshot();
		switchToWindow();sleep(minWaitVal);
		screenshot();
		Assert.assertTrue(BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.RFI_TITLE).getText().contains("View RFIs"));
	    ieButtonJSClick(SecurityMatrixObj.Close_View_RFI);
	    switchBackToParentWindow("[Actimize] WorK Items");
	    sleep(mediumWaitVal);
	}
	
	public void validatePrintDetails()
	{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.EXPORT_ICON));
		mouseHoverClick(ICDD_WorkItem_Obj.EXPORT_ICON, ICDD_WorkItem_Obj.PRINT_DETAILS);
		switchToWindow();sleep(minWaitVal);
		sleep(minWaitVal);
		screenshot();
		String Title=BaseTestSetup.driver.getTitle();
		Assert.assertEquals("[Actimize] Print Details", Title);
		webDriverwait(SecurityMatrixObj.Close_Print_details);
		ieButtonJSClick(SecurityMatrixObj.Close_Print_details);
		switchToParentWindow();
		sleep(minWaitVal);
		
	}
	
	public void validateShowAsPDF()
	{
		try{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.EXPORT_ICON));
		mouseHoverClick(ICDD_WorkItem_Obj.EXPORT_ICON, ICDD_WorkItem_Obj.SHOW_AS_PDF);
		sleep(minWaitVal);
		screenshot();
		/*switchToWindow();sleep(minWaitVal);
		String url=BaseTestSetup.driver.getTitle();
		System.out.println("url of show as pdf"+url);
		Assert.assertEquals("[Actimize] Work Items]", url);
		screenshot();
		switchToParentWindow();*/
		}
		catch(Exception e){
			System.out.println("show as pdf not working "+e.getMessage());
		}
		
	}
	
	public void validateAddAttachment()
	{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.MORE_OPTION));
		mouseHoverClick(ICDD_WorkItem_Obj.MORE_OPTION, ICDD_WorkItem_Obj.ADD_ATTACHMENT);
		switchToWindow();sleep(minWaitVal);
		String Title=BaseTestSetup.driver.getTitle();
		Assert.assertEquals("[Actimize] Add Attachments", Title);
	}
	
	public void validateViewAttachment()
	{
		try{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.MORE_OPTION));
		mouseHoverClick(ICDD_WorkItem_Obj.MORE_OPTION, ICDD_WorkItem_Obj.VIEW_ATTACHMENT);
		switchToWindow();sleep(minWaitVal);
		//String Title=BaseTestSetup.driver.getTitle();
		//Assert.assertEquals("[Actimize] Work Items", Title);
		sleep(minWaitVal);
		screenshot();
		webDriverWait(SecurityMatrixObj.Cancel_attachment);
		Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Cancel_attachment));
		ieButtonJSClick(SecurityMatrixObj.Cancel_attachment);
		switchToParentWindow();
		}
		catch(Exception e){
			System.out.println("Validation of view attachment failed"+e.getMessage());
		}
		
		
	}
	
	public void ValidateRiskScoringTab()
	{
		String text=BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.RISK_LEVEL_ADJUSTMENT).getText();
		Assert.assertEquals("Risk Scoring", text);
	}
	
	public void validateRiskLevelAdjustment(){
		String text=BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.RISK_SCORING_TAB).getText();
		Assert.assertEquals("Risk Level Adjustment", text);
		
	}
	
	public void validateMultipleChangeStep() throws Exception
	{       
		sleep(mediumWaitVal);
		    //ICDD_WorkItem.selectMultipleCheckBox();
			ieButtonJSClick(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP);
	        BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(2));
	        switchWindow("[Actimize] Change Step");
	        Thread.sleep(3000);
	        Assert.assertEquals("There are no available steps", BaseTestSetup.driver.findElement(By.xpath("//*[@id='topChagneStatusTable']/div[2]")).getText());
            ieButtonJSClick(ICDD_WorkItem_Obj.CANCEL_BUTTON);
            Thread.sleep(3000);
            switchBackToParentWindow("[Actimize] Work Items");
	        screenshot();
	        BaseTestSetup.driver.switchTo().defaultContent();
	        Thread.sleep(2000);
	        //BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.CANCEL_BUTTON).click();
	        //ieButtonJSClick(ICDD_WorkItem_Obj.CANCEL_BUTTON);
	 }	
	
	public void validateSingleChangeStep(String scenarioName,HashMap<String, String> testData, String Sheetname) throws Exception
	{
		ICDD_WorkItem.CreateManualTrigger(scenarioName, testData, Sheetname);
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
		ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
		ICDD_WorkItem.click_ref_id_checkbox();
		Assert.assertTrue(BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP).isDisplayed());
		ICDD_WorkItem.changestep("Open");
		int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
       int StepColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "Step");
       for (int i = 2; i <= n; i++) {
           WebElement we1 = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + StepColumnNumber + "]"));
           if (we1.getText().equals("Open")) {
           	Assert.assertEquals("Open", "we1.getText()");
           	break;
           }
         }
	}
	
	public void validatelogin()
	{
	    Assert.assertEquals("http://10.20.161.31:3245/RCM/HomePage.jsp", BaseTestSetup.driver.getCurrentUrl());
	}
	
	
	public void validateAlertFromCustomerAlert()
	{
		click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
		int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
	    if(n>2){
	    	System.out.println("Multiple Record present after clicked on Customer Alert");
	    }
	    else{
	    	System.out.println("Multiple Record present after clicked on Customer Alert");
	    }
	}
	
	public void validateCustomerPage()
	{
		Assert.assertEquals("http://10.20.161.31:3245/RCM/plugin?plugin=Customers&module=customers&page=customerList&tabAuthForListener=customers", BaseTestSetup.driver.getCurrentUrl());}

	public void select_first_check_box() {
		sleep(minWaitVal);
		webDriverwait(SecurityMatrixObj.Select_first_checkBox);
		ieButtonJSClick(SecurityMatrixObj.Select_first_checkBox);
		screenshot();
		
	}
	
	public void remove_attachments() throws Exception{
		Boolean remove_attachment=false;
		try{
			sleep(mediumWaitVal);
			webDriverwait(SecurityMatrixObj.Attachment_icon);
			ieButtonJSClick(SecurityMatrixObj.Attachment_icon);
			switchToWindow();
			screenshot();
			webDriverwait(SecurityMatrixObj.First_attchment_checkbox);
			ieButtonJSClick(SecurityMatrixObj.First_attchment_checkbox);
			sleep(minWaitVal);
			screenshot();
			if(isWebElementPresent(SecurityMatrixObj.Delete_attachment)){
			remove_attachment=true;
			Assert.assertTrue(remove_attachment);	
			ieButtonJSClick(SecurityMatrixObj.Delete_attachment);
			sleep(minWaitVal);
			screenshot();
			enterbyRobot();
			sleep(minWaitVal);
			webDriverwait(SecurityMatrixObj.Save_attachment);
			ieButtonJSClick(SecurityMatrixObj.Save_attachment);
			
			switchToParentWindow();
			}else{
				Assert.assertFalse(remove_attachment);
				ieButtonJSClick(SecurityMatrixObj.Cancel_attachment);
			}
				
			
		}
		catch(Exception e){
			Assert.assertFalse(remove_attachment);
			System.out.println("Not able to remove the attachment"+e.getMessage());
		}
		
	}

	public void validate_Add_Attchment() {
		try{
			sleep(mediumWaitVal);
			webDriverwait(SecurityMatrixObj.Attachment_icon);
			ieButtonJSClick(SecurityMatrixObj.Attachment_icon);
			switchToWindow();
			screenshot();
			
			/*Screen s = new Screen();
			patt
		*/
	        
	 
						
		}
		catch(Exception e){
			
		}
		
	}
	
	
	/* ---------------------------------------------------------------------
    Method Name: webElementClick
    Description: Method to Click the webelements.
    Author: Sathish A
------------------------------------------------------------------------*/
	
	public void Navigate_WorkBench_WorkItem() throws Throwable {
		
		//Checking workbench tab is present or not then checking work item is present or not then click work bench and validate page is loaded or not
		System.out.println("Navigate to Customer Alert");
		ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);		
		sleep(minWaitVal);
		validate_MultipleItems_View();
		
	}
/* ---------------------------------------------------------------------
    Method Name: checkAlert_AssignToMe
    Description: Method to Click the webelements.
    Author: Sathish A
------------------------------------------------------------------------*/
	public void checkAlert_AssignToMe(String select){
		try{
			System.out.println("Checking that the any alert assign to me");
			
			int n, stepColumnNumber, bFlag;
			switch (select) {
			case "Single":
				sleep(minWaitVal);
				System.out.println("Entering into router");
				n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
		        stepColumnNumber = getColumnNumberAssignImg("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "OwnerID");
		        bFlag = 0;
		        for (int i = 2 ; i<=n;i++){
		        	List<WebElement> we = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + stepColumnNumber + "]/div/img"));
				       if (we.size() != 0){
				    	   System.out.println("Alert Routed to the current user");
				    	   screenshot();	
				    	   if (!webElement_isSelected(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + 1 + "]/input"))){
				    		   ieButtonJSClick(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + 1 + "]/input"));
				    	   }
				    	   				       
				    	   bFlag = 1;
				    	   break;
			        }
		        }
		        
		        if (bFlag == 0){
		        	System.out.println("Assign to me");
		        	WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + 2+ "]/td[" + 1 + "]/input"));
		        	we.click();
		        	ICDD_WorkItem.assign_to_me();
		        }
				
				
				break;
			case "Multiple":
				int iCount = 0;
				sleep(minWaitVal);
				System.out.println("Entering into router");
				n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
				stepColumnNumber = getColumnNumberAssignImg("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "OwnerID");
		        bFlag = 0;
		        for (int i = 2 ; i<=n;i++){
		        	List<WebElement> we = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + stepColumnNumber + "]/div/img"));
				       if (we.size() !=0){
				    	   System.out.println("Alert Routed to the current user");
				    	   screenshot();	    	 
				    	   iCount = iCount++;
				    	   break;
			        }
		        }
		        System.out.println("Assigned " + iCount);
				if (iCount <=1){
					WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + 2+ "]/td[" + 1 + "]/input"));
		        	we.click();
		        	we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + 3+ "]/td[" + 1 + "]/input"));
		        	we.click();
		        	we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + 4+ "]/td[" + 1 + "]/input"));
		        	we.click();
		        	ICDD_WorkItem.assign_to_me();
		        	
				}
				
				break;
			default:
				break;
			}
				        	
	       }
		catch (Exception e) {
			e.printStackTrace();
	    	Log.error("Error while getting the step of the alert" + " :" + e.getMessage());}
	      
		
	}
	
	public void validate_AddNotes(String listOption, HashMap<String, String> testData) throws Exception{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.ADDNOTE));
		ieButtonJSClick(ICDD_WorkItem_Obj.ADDNOTE);Thread.sleep(5000);
       String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
	    Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
       for (String win : chwin1) { 
       if (!originalWindow1.equals(win)) {
       BaseTestSetup.driver.switchTo().window(win);
       sleep(minWaitVal);
       
       if (listOption.equalsIgnoreCase("Free Text")){
    	   selectDropDownByText(ICDD_WorkItem_Obj.AddNote_Dropdown, "[ Free Text ]" );
    	   BaseTestSetup.driver.switchTo().frame("noteModelFreeTextNote_ifr");
           BaseTestSetup.driver.findElement(ICDD_Forms_Obj.AM_NOTE).click(); 
           actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
           BaseTestSetup.driver.switchTo().defaultContent();
       }else if(listOption.equalsIgnoreCase("Predefined")){
    	   //selectDropDownByText(, "Client documents are validated, verified and found to be correct." );
    	   WebElement element = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.AddNote_Dropdown);
    	   Select select = new Select(element);
    	   select.selectByIndex(2);
    	   
       }
       screenshot();
       ieButtonJSClick(ICDD_WorkItem_Obj.OKBUTTON);
       BaseTestSetup.driver.switchTo().window(originalWindow1);
	   // BaseTestSetup.driver.findElement(By.id("textButton_addNoteDialog_CancelButton")).click();
		}
	}
}
	
/* ---------------------------------------------------------------------
    Method Name: Selection_My_WorkItems_Options_Present
    Description:Select the items and validate the disp
    Author: Sathish A
------------------------------------------------------------------------*/
	//validating list of Options should present under My Work Items
public void selection_My_WorkItems_Options_Present(HashMap<String, String> testData) throws Exception{ 
			System.out.println("Validate the list of items in My WorkItems");
		   String[] Expected_present_list=testData.get("Expected_present_list").split("\\|");
		   for(String options:Expected_present_list){	
			   ieButtonJSClick(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN);
			   screenshot();
			   List<WebElement> listOfOptions = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.WORKITEMS_ALL_OPTIONS);
			   for(WebElement wb:listOfOptions){			
			   String sTempValue = wb.getText() ;
			   if (options.contains(sTempValue)){					   
					   System.out.println(sTempValue + " is selected");
					   ieButtonJSClick(By.xpath("//table[@id='dropDownMenuOps']//td//div[contains(text(),'"+ options +"')]"));
					   sleep(minWaitVal);
					   screenshot();
					   BaseTestSetup.wait.until(ExpectedConditions.visibilityOfElementLocated(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN));
					   
					   checkAlert_displayInfo(sTempValue);					   
					   screenshot();
					   break;
				   }
				   	
			   }
			   
			   
		   }
		   
		  
	   } 	
	
/* ---------------------------------------------------------------------
Method Name: checkAlert_AssignToMe
Description: Method to Click the webelements.
Author: Sathish A
------------------------------------------------------------------------*/
public void checkAlert_displayInfo(String items){
	String srcValue = null;
	switch (items) {
	
	case "My WorkItems":
		srcValue = "Open.png";		
		break;
	case "Closed Items":
		srcValue = "Open_Closed_default.png";
		
	case "Periodic Review - Closed Items":
		srcValue = "Open_Closed_default.png";
	
	case "Trigger Review - Closed Items":
		srcValue = "Open_Closed_default.png";
		
		break;
	default:
		srcValue = "Open.png";	
		break;
	}
	
	try{
		sleep(minWaitVal);
		System.out.println("Entering into My WorkItems");
		int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
        int stepColumnNumber = getColumnNumberAssignImg("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "State");
        int bFlag = 0;
        for (int i = 2 ; i<n;i++){
        	List<WebElement> we = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + stepColumnNumber + "]/div/img"));
		       if (we.size() !=0){
		    	   if (!we.get(1).getAttribute("src").contains(srcValue)){
			        	 bFlag = 1;
			        }
		    	  
		    	  
	        }
        }
        
        Assert.assertTrue(bFlag == 0);}
	catch (Exception e) {
		e.printStackTrace();
    	Log.error("Error while getting the step of the alert" + " :" + e.getMessage());}
      
	
}	

/* ---------------------------------------------------------------------
Method Name: validateform_Not_Present
Description: Validating the forms are present for the selected Users
Author: Sathish A
------------------------------------------------------------------------*/

public void validateform_Not_Present(HashMap<String, String> testData)
	{
			System.out.println("Validating Forms");
			String[] expectedForms= testData.get("Perform_Review_Check_Forms_Not").split("\\|");
			for(int i=0; i<expectedForms.length; i++){
				switch (expectedForms[i]){
				case "SOW":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.SOWFORM));
					
					//mouseHoverClick(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.SOWFORM);
					//switchToWindow();sleep(minWaitVal);
					//Assert.assertEquals("NEW_ITEM", ICDD_Forms_Obj.NEW_ITEM);
		
					break;
					
				case "PEP":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.PEP_EFORM));
					break;	
				
				case "AdverseMedia":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.ADVERSE_MEDIA_FORM));
					break;	
					
				case "Tax-E":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.TAXE_FORM));
					break;
					
				case "AdditionalCDD":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.ADDITIONAL_CDD_FORM));
					
					break;
					
				case "CreateReviewChecklist":
					sleep(mediumWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.CREATE_REVIEW_CHECKLIST_FORM));
					break;
					
				case "Create Client Contact":
					sleep(minWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.CLIENT_CONTACT_FORM));
					break;
					
					
				case "Create UHNW":
					sleep(minWaitVal);
					Assert.assertTrue(isWebElementPresent(ICDD_Forms_Obj.FORMSTAB));
					ieButtonJSClick(ICDD_Forms_Obj.FORMSTAB);
					screenshot();
					Assert.assertFalse(isWebElementPresent(ICDD_Forms_Obj.UHNW_FORM));
					break;
				
				}
			}
		}

/* ---------------------------------------------------------------------
Method Name: click_ChangeStep
Description: Validating the forms are present for the selected Users
Author: Sathish A
------------------------------------------------------------------------*/
	public void click_ChangeStep(){
		sleep(minWaitVal);
		ieButtonJSClick(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP);
	}

/* ---------------------------------------------------------------------
Method Name: validate_Access_ChangeStep
Description: Validating the forms are present for the selected Users
Author: Sathish A
------------------------------------------------------------------------*/
	public void validate_Access_ChangeStep(String sTempValue){
		
		//table[@id='mainTable']//tr[2]/td/table//tr/td
		sleep(minWaitVal);
		switchToWindow();
		String title = BaseTestSetup.driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(sTempValue, BaseTestSetup.driver.findElement(By.xpath("//table[@id='mainTable']//tr[2]/td/table//tr/td")).getText());
		screenshot();
	}
	
/* ---------------------------------------------------------------------
	Method Name: validate_Access_ChangeStep_Completion
	Description: Validating the forms are present for the selected Users
	Author: Sathish A
------------------------------------------------------------------------*/
		public void validate_Access_ChangeStep_Completion(String sTempValue) throws Exception{
			
			//table[@id='mainTable']//tr[2]/td/table//tr/td
			sleep(minWaitVal);
			switchToWindow();
			String title = BaseTestSetup.driver.getTitle();
			System.out.println(title);
			Assert.assertEquals("[Actimize] Change Step", title);			
			screenshot();
			System.out.println("Starting of next Step");
		    sleep(mediumWaitVal);	        
	        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP_DROPDWN));
	        ieButtonJSClick(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP_DROPDWN);
	        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='statusesDropdownTable']//tr/td[3]")));
	        BaseTestSetup.waitForTitleisPresent(By.xpath("//table[@id='statusesDropdownTable']//tr/td[3]"));
	        sTempValue= BaseTestSetup.driver.findElement(By.xpath("//table[@id='statusesDropdownTable']//tr/td[3]")).getText();
	        triggerOnClick(BaseTestSetup.driver.findElement(By.xpath("//table[@id='statusesDropdownTable']//tr/td[3]")));
	        BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.id("changeStatusNoteModelFreeTextNote_ifr")));
	        WebElement we = BaseTestSetup.driver.findElement(By.id("changeStatusNoteModelFreeTextNote_ifr"));
	        BaseTestSetup.driver.switchTo().frame(we);		      
	        sleep(mediumWaitVal);		        
	        enterInput(ICDD_WorkItem_Obj.ALERTSDETAIL_CHANGESTEP_TEXTFIELD, "Change alert step to " + sTempValue);
	        BaseTestSetup.driver.switchTo().defaultContent();
	        screenshot();
	        WebElement ok =BaseTestSetup.driver.findElement(By.id("textButton_changeStatusDialog_SubmitButton"));
		       if (ok.isDisplayed()){
		    	   //ok.click();
		    	   ieButtonJSClick(By.id("textButton_changeStatusDialog_SubmitButton"));
		       }
	       switchBackToParentWindow("[Actimize] Work Items");
			
		}
/* ---------------------------------------------------------------------
	Method Name: add_Attachment
	Description: Add the Attachment
	Author: Sathish A
------------------------------------------------------------------------*/
	
	public void add_Attachment(){
		
		 sleep(mediumWaitVal);
		   ieButtonJSClick(SecurityMatrixObj.Add_Attachments);			   
		   sleep(mediumWaitVal);
		   screenshot();
//		int num = BaseTestSetup.driver.findElements(SecurityMatrixObj.Attachement_GridTable).size();
//		List<WebElement> elements= BaseTestSetup.driver.findElements(By.xpath("//table[@id='attachmentsDialog_attachmentsGrid']/tbody/tr[1]/td[1]/input"));
//		if (num <= 2 && elements.size() == 0){
		   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Link_Button));
			ieButtonJSClick(SecurityMatrixObj.Link_Button);
			screenshot();
			enterInputText(SecurityMatrixObj.attachement_Text, "Test");
			enterInputText(SecurityMatrixObj.attachment_URL, "https;//Test.com/");
			screenshot();
			ieButtonJSClick(SecurityMatrixObj.attachment_add);	
			sleep(minWaitVal);
			screenshot();
			ieButtonJSClick(SecurityMatrixObj.SaveAttachment_Button);
			
//		}else{
//			sleep(minWaitVal);
//			ieButtonJSClick(SecurityMatrixObj.CancelAttachment_Button);
//		}
	}
	/* ---------------------------------------------------------------------
	Method Name: validateform_Not_Present
	Description: Validating the forms are present for the selected Users
	Author: Sathish A
	------------------------------------------------------------------------*/	
	public void validate_RemoveAttachment(){
		sleep(minWaitVal);
		ieButtonJSClick(SecurityMatrixObj.Add_Attachments);			   
		   String fileName;
			sleep(minWaitVal);
			List<WebElement> elements= BaseTestSetup.driver.findElements(By.xpath("//table[@id='attachmentsDialog_attachmentsGrid']/tbody/tr[2]/td[1]/input"));			
			
			sleep(minWaitVal);
			int num = BaseTestSetup.driver.findElements(SecurityMatrixObj.Attachement_GridTable).size();
			if (num >= 2 && elements.size() !=0 ){
				fileName = getTextFromWebElement(By.xpath("//table[@id='attachmentsDialog_attachmentsGrid']/tbody/tr[2]/td[4]/div/a"));
				ieButtonJSClick((By.xpath("//table[@id='attachmentsDialog_attachmentsGrid']/tbody/tr[2]/td[1]/input")));
				ieButtonJSClick(SecurityMatrixObj.RemoveAttachment_Button);
				sleep(1000);
				ieButtonJSClick(SecurityMatrixObj.message_delete);
			}
			sleep(minWaitVal);
			screenshot();
			ieButtonJSClick(SecurityMatrixObj.SaveAttachment_Button);
			
		
	}
/* ---------------------------------------------------------------------
	Method Name: validateform_Not_Present
	Description: Validating the forms are present for the selected Users
	Author: Sathish A
------------------------------------------------------------------------*/
	public void Validate_Add_attachments() throws Exception{
		   
		   try{
			   sleep(minWaitVal);
			   
			   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.More_tab));
			   ieButtonJSClick(SecurityMatrixObj.Add_Attachments);			   
			   sleep(minWaitVal);
			   screenshot();
			   
			   switchToWindow();
			   sleep(minWaitVal);
			   String title = getTextFromWebElement(SecurityMatrixObj.Attachement_Title);
				System.out.println(title);
			   Assert.assertEquals("Attachments", title);
			   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Cancel_button));
			   ieButtonJSClick(SecurityMatrixObj.Cancel_button);
			   switchToParentWindow();
			   
		   }catch(Exception e){
			   
			   System.out.println("Validation of view attachments has failed"+e.getMessage());
		   } 
	   }
/* ---------------------------------------------------------------------
	Method Name: Validate_View_attachments_not_Present
	Description: Validating the view attachment is not present for the user.
	Author: Sathish A
------------------------------------------------------------------------*/	
	public void Validate_View_attachments_not_Present() throws Exception{
		   
		   try{
			   sleep(minWaitVal);
			   webDriverWait(SecurityMatrixObj.More_tab);
			   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.More_tab));
			   Assert.assertFalse(isWebElementPresent(SecurityMatrixObj.View_Attachments));			   
			   
		   }catch(Exception e){
			   
			   System.out.println("Validation of view attachments has failed"+e.getMessage());
		   } 
	   }
/* ---------------------------------------------------------------------
	Method Name: Validate_View_History_not_Present
	Description: Validating the view history is not present for the user.
	Author: Sathish A
------------------------------------------------------------------------*/	
	public void Validate_View_History_not_Present() throws Exception{
		   
		   try{
			   sleep(minWaitVal);
			   webDriverWait(SecurityMatrixObj.More_tab);
			   Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.More_tab));
			   ieButtonJSClick(SecurityMatrixObj.More_tab);
			   screenshot();
			   Assert.assertFalse(isWebElementPresent(SecurityMatrixObj.View_History));			   
			   
		   }catch(Exception e){
			   
			   System.out.println("Validation of view attachments has failed"+e.getMessage());
		   } 
	   }	
	
/* ---------------------------------------------------------------------
	Method Name: Validate_View_Notes_not_Present
	Description: Validating the view Notes is not present for the user.
	Author: Sathish A
------------------------------------------------------------------------*/	
	public void Validate_View_Notes_not_Present() throws Exception{
		   
		   try{
			   sleep(minWaitVal);		  			   
			   Assert.assertFalse(isWebElementPresent(SecurityMatrixObj.View_Notes));
			   screenshot();
			   
		   }catch(Exception e){
			   
			   System.out.println("Validation of view attachments has failed"+e.getMessage());
		   } 
	   }	
/* ---------------------------------------------------------------------
	Method Name: Validate_View_Notes_not_Present
	Description: Validating the view Notes is not present for the user.
	Author: Sathish A
------------------------------------------------------------------------*/	
	public void Validate_View_RFI_not_Present() throws Exception{
		   
		   try{
			   sleep(minWaitVal);	
			   Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.CREATE_RFI_ICON));
			   Assert.assertFalse(isWebElementPresent(ICDD_WorkItem_Obj.VIEW_RFI));
			   screenshot();
			   
		   }catch(Exception e){
			   
			   System.out.println("Validation of view attachments has failed"+e.getMessage());
		   } 
	   }	
		
	public void validatePrintList() throws Exception
	{
		Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.EXPORT_ICON));
		mouseHoverClick(ICDD_WorkItem_Obj.EXPORT_ICON, ICDD_WorkItem_Obj.PRINT_LIST);
		switchToWindow();sleep(minWaitVal);
		String Title=BaseTestSetup.driver.getTitle();
		System.out.println(Title);
		screenshot();
		Assert.assertEquals("[Actimize] Work Items", Title);
		sleep(minWaitVal);
		ieButtonJSClick(By.linkText("Close"));
		switchBackToParentWindow("[Actimize] Work Items");
	}
/* ---------------------------------------------------------------------
    Method Name: Selection_My_WorkItems_Options_Present
    Description:Select the items and validate the disp
    Author: Sathish A
------------------------------------------------------------------------*/
	//validating list of Options should present under My Work Items
	public void select_My_WorkItems_Options_Present(String myWorkItems) throws Exception{ 
		String currentItem = getTextFromWebElement(SecurityMatrixObj.workItem_Title);
		if(!currentItem.equals(myWorkItems)){
			ieButtonJSClick(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN);
			screenshot();
		   ieButtonJSClick(By.xpath("//table[@id='dropDownMenuOps']//td//div[contains(text(),'"+ myWorkItems +"')]"));
		   BaseTestSetup.wait.until(ExpectedConditions.visibilityOfElementLocated(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN));	   		   
		   screenshot();
		}
	  } 	
	public void validate_MultipleItems_View(){
		sleep(minWaitVal);
		int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']//tr")).size();
		System.out.println("Size of the grid is " + n);
		Assert.assertTrue(n >= 2);
	}
/* ---------------------------------------------------------------------
    Method Name: validate_CreateRFI
    Description:Select the items and validate the disp
    Author: Sathish A
------------------------------------------------------------------------*/	
	public void validate_CreateRFI() throws Exception
    {
    Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.CREATE_RFI_ICON));
          mouseHoverClick(ICDD_WorkItem_Obj.CREATE_RFI_ICON, ICDD_WorkItem_Obj.CREATE_RFI);
          switchToWindow();sleep(minWaitVal);
          Assert.assertEquals("Create RFI", BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.RFI_TITLE).getText());
          screenshot();
          ieButtonJSClick(ICDD_WorkItem_Obj.RFI_Cancel);
          switchBackToParentWindow("[Actimize] Work Items");
    }
/* ---------------------------------------------------------------------
    Method Name: validate_CreateRFI
    Description:Select the items and validate the disp
    Author: Sathish A
------------------------------------------------------------------------*/	
	public void Validate_WorkBench_Reports_Not_Present() throws Throwable {
        
        //Checking workbench tab is present or not then Reports tab should not present
		   System.out.println("Validate Report Tab");
		      sleep(minWaitVal);
		        screenshot();
		  Assert.assertTrue(isWebElementPresent(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB));
		  Assert.assertFalse(isWebElementPresent(ICDD_WorkItem_Obj.REPORT)); 
        
  }
	/* ---------------------------------------------------------------------
    Method Name: Validate_Perform_Send_Mail_Option
    Description:Select the items and validate the disp
    Author: Sathish A
------------------------------------------------------------------------*/	
	
	public void Validate_Perform_Send_Mail_Option(String sTempValue) throws Exception{
        
        try{
               sleep(minWaitVal);
                  webDriverWait(SecurityMatrixObj.Export_Icon);
           Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.Export_Icon));
           mouseHoverClick(SecurityMatrixObj.Export_Icon,SecurityMatrixObj.Send_Mail);
                  sleep(minWaitVal);
                  screenshot();
                  if (sTempValue.equals("Not able")){
                        sTempValue = getText_AcceptAlert();
                         Assert.assertTrue(sTempValue.contains("You do not have permission"));
                  }
                  
              }
              catch(Exception e){
                     System.out.println("validation of 'Send Mail' has failed"+e.getMessage());
              }      
      
 }

		
//Ramya	
	
	public void clickRisklevelAdjustment(){
        screenshot();
        BaseTestSetup.driver.switchTo().frame(ICDD_CustomerRecord_Obj.iFRAME_ID);
         ieButtonJSClick(ICDD_CustomerRecord_Obj.RISK_LEVEL_ADJUSTMENT);
        screenshot();
        sleep(minWaitVal);
        BaseTestSetup.driver.switchTo().defaultContent();
  }

	public void Validate_Assign_Reports()
    {
       sleep(minWaitVal);
       webDriverWait(SecurityMatrixObj.report_checkbox);
       ieButtonJSClick(SecurityMatrixObj.report_checkbox);
       sleep(mediumWaitVal);
       screenshot();
       webDriverWait(SecurityMatrixObj.assign_report);
     Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.assign_report));
           ieButtonJSClick(SecurityMatrixObj.assign_report);
           switchToWindow();
           sleep(minWaitVal);
           screenshot();
         ieButtonJSClick(SecurityMatrixObj.AssignReport_save_button);
           sleep(minWaitVal);
           switchToParentWindow();
                     
   }
    
    public void Validate_assign_Reports_Business_unit(){
      try{
            sleep(minWaitVal);
             webDriverWait(SecurityMatrixObj.report_checkbox);
             ieButtonJSClick(SecurityMatrixObj.report_checkbox); 
       sleep(mediumWaitVal);
       screenshot();
       webDriverWait(SecurityMatrixObj.assign_report);
      Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.assign_report));
            ieButtonJSClick(SecurityMatrixObj.assign_report);
            switchWindow("Assign Report");
            sleep(minWaitVal);
            screenshot();
      ieButtonJSClick(SecurityMatrixObj.AssignReport_Business_chkbox);
       sleep(minWaitVal);
       screenshot();
       ieButtonJSClick(SecurityMatrixObj.BizUnit_search);
       sleep(minWaitVal);
       switchWindow("Business Unit Explorer");
       sleep(minWaitVal);
       ieButtonJSClick(SecurityMatrixObj.BizUnit_PlusExpand);
       sleep(minWaitVal);
       ieButtonJSClick(SecurityMatrixObj.BizUnit_INStaff);
       ieButtonJSClick(SecurityMatrixObj.BizUnit_OK_Button);
       switchWindow("Assign Report");
       sleep(minWaitVal);
          ieButtonJSClick(SecurityMatrixObj.AssignReport_save_button);
            sleep(minWaitVal);
            switchWindow("Reports");
       }
       catch (Exception e)
       {
             System.out.println("Assign report to Business unit has been failed "+ e.getMessage());
       }
    }
      public void Validate_Delete_Icon(){
                   sleep(minWaitVal);
              webDriverWait(SecurityMatrixObj.report_checkbox);
              ieButtonJSClick(SecurityMatrixObj.report_checkbox);
              sleep(minWaitVal);
              screenshot();
              mouseHoverClick(SecurityMatrixObj.more_button_reports, SecurityMatrixObj.Reports_Delete);
              screenshot();
              sleep(minWaitVal);
              enterbyRobot();
              sleep(minWaitVal);
                   }
      
      public void Validate_Open_Icon(){
            sleep(minWaitVal);
       webDriverWait(SecurityMatrixObj.report_checkbox);
       ieButtonJSClick(SecurityMatrixObj.report_checkbox);
       sleep(minWaitVal);
       screenshot();
       ieButtonJSClick(SecurityMatrixObj.open_report);
       switchToWindow();
       screenshot();
       sleep(mediumWaitVal);
       screenshot();
       ieButtonJSClick(SecurityMatrixObj.OpenReport_cancel_button);
       sleep(minWaitVal);
       switchToParentWindow();
       
      }
      public void Validate_On_Demand_Report(){
            sleep(minWaitVal);
              webDriverWait(SecurityMatrixObj.report_checkbox);
              ieButtonJSClick(SecurityMatrixObj.report_checkbox);
              sleep(minWaitVal);
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.onDemand_reports);
              sleep(minWaitVal);
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.managementreport_Plus_icon);
              sleep(minWaitVal);
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.backtoReportlist_icon);
              sleep(minWaitVal);
              screenshot();
      
      }
      public void Validate_Add_Note_report(HashMap<String, String> testData) throws Exception{
            sleep(minWaitVal);
              webDriverWait(SecurityMatrixObj.report_checkbox);
              ieButtonJSClick(SecurityMatrixObj.report_checkbox);
              sleep(minWaitVal);
              screenshot();
              Assert.assertTrue(isWebElementPresent(SecurityMatrixObj.addNotes_reports));
              ieButtonJSClick(SecurityMatrixObj.addNotes_reports);
              sleep(minWaitVal);
              screenshot();
             String originWindow1 =BaseTestSetup.driver.getWindowHandle();
          Set <String> childwin1 = BaseTestSetup.driver.getWindowHandles();
      for (String win : childwin1) { 
      if (!originWindow1.equals(win)) {
      BaseTestSetup.driver.switchTo().window(win);
      sleep(minWaitVal);
      BaseTestSetup.driver.findElement(SecurityMatrixObj.Addnote_textarea).click(); 
      screenshot();
      actionEnterData(SecurityMatrixObj.Addnote_textarea, testData.get("Addnote_textarea"));
      sleep(minWaitVal);    
      screenshot();
      ieButtonJSClick(SecurityMatrixObj.addNotes_Ok_button);
      sleep(minWaitVal);
      BaseTestSetup.driver.switchTo().window(originWindow1);
      }
      }
              
      }
      public void Validate_view_History(){
            sleep(minWaitVal);
              webDriverWait(SecurityMatrixObj.report_checkbox);
              ieButtonJSClick(SecurityMatrixObj.report_checkbox);
              sleep(minWaitVal);
              screenshot();
              mouseHoverClick(SecurityMatrixObj.more_button_reports, SecurityMatrixObj.viewHistory_reports);
              switchToWindow();
              sleep(mediumWaitVal);
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.ViewHistoryReports_close_button);
              switchToParentWindow();
            
      }
      public void Validate_sign_off(){
            sleep(minWaitVal);
              webDriverWait(SecurityMatrixObj.report_checkbox);
              ieButtonJSClick(SecurityMatrixObj.report_checkbox);
              sleep(minWaitVal);
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.signoffIcon_report);
              switchToWindow();
              screenshot();
              sleep(minWaitVal);
              ieButtonJSClick(SecurityMatrixObj.signoffReport_Signoff);
              sleep(minWaitVal);
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.SignoffReport_OkButton);
              screenshot();
                          
      }
      public void Validate_view_notes_reports(){
            sleep(minWaitVal);
              webDriverWait(SecurityMatrixObj.report_checkbox);
              ieButtonJSClick(SecurityMatrixObj.report_checkbox);
              sleep(minWaitVal);
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.viewNotes_reports);
              sleep(mediumWaitVal);
              switchToWindow();
              screenshot();
              ieButtonJSClick(SecurityMatrixObj.viewNotesReports_closeButton);
              
      }

		
	
}


   
   
   
	
	
	

