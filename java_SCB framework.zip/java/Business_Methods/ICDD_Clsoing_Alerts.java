package Business_Methods;

import java.util.HashMap;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.fasterxml.jackson.databind.ser.std.StdKeySerializers.Default;
import com.google.common.collect.Multiset.Entry;

import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICDD_WorkItem_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;

public class ICDD_Clsoing_Alerts extends Common_Utils{
	
	ICDD_WorkItem iCDD_WorkItem=new ICDD_WorkItem();
	ICDD_CustomerRecord ICDD_CustomerRecord=new ICDD_CustomerRecord();
	
	HashMap<String, String> alertDetails= new HashMap<>();
	
	public void Close_ALL_Alerts(HashMap<String, String> testData) throws Exception{
		
	
		
		List<WebElement> alertTable = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr"));
        
        for(int i=2; i<= alertTable.size();i++){
               
               String imgSrc = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']/tbody/tr[" + i + "]/td[5]//img")).getAttribute("src");
               if (imgSrc.contains("Open.png")){
                     String alertId= BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']/tbody/tr[" + i + "]/td[9]")).getText();
                     String alertStatus =BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']/tbody/tr[" + i + "]/td[14]")).getText();
                     
                     if(!alertId.contains("PRR")){
                    	 alertDetails.put(alertId, alertStatus); 
                     }
                     for(String alertID: alertDetails.keySet()){
                    	 
                    	 System.out.println("Open alserts :"+alertID);
                    	 
                     }
                     System.out.println("*****No of Open Alerts******* :"+alertDetails.keySet().size());
                     
               }
        }
        //Logout the application 
        iCDD_WorkItem.logout();
    	try{
        //Now close the alerts by login to the application
        
        for(String alertId: alertDetails.keySet()){
               String status = alertDetails.get(alertId);
               	
		switch (status){
		
			case "Ready":
				
				//login as assigner
				iCDD_WorkItem.loginApplication("1581121G", "abc12345");
				
				//click on customer tab
				sleep(minWaitVal);
				webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				
				sleep(minWaitVal);
				//Search 
				enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
				waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
				ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
				
				
				sleep(minWaitVal);
			 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
			 	sleep(mediumWaitVal);
			 	
			 	//search alert id
			 	//iCDD_WorkItem.searchcustomeralerts(alertId);
			 	
			 	//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				
				//Assign to me
				iCDD_WorkItem.assign_to_me();

				
				//next step and perform review checks
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Perform_checks);
				
				//click on work flow 
				sleep(minWaitVal);
				webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
				
				//select mandatory task
				iCDD_WorkItem.ValidateMandateCheck();
				
				//click on Details button
				//sleep(minWaitVal);
				//ICDD_CustomerRecord.click_Details_Button();
				
				/*//next step and client contact in progress
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Client_Contact_Progress);
				
				//next step and Client_Contact_Completed
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Client_Contact_Completed);
               */				
				//next step and Documment tagging
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Document_tagging);
				
				//next step and Reacessement
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Re_assess_client_risk);
				
			 	
				//Change step to submit to checker
				iCDD_WorkItem.changestep("Submit to Checker");
				sleep(mediumWaitVal);
				
				//Logout the application
				iCDD_WorkItem.logout();
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
				
			      System.out.println("Sucessfully close the alert"+alertId);
			      
			    //Logout the application
					iCDD_WorkItem.logout();
				
				
				break;
				
                case "Open":
				
				//login as assigner
				iCDD_WorkItem.loginApplication("1581121G", "abc12345");
				
				//click on customer tab
				sleep(minWaitVal);
				webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				
				sleep(minWaitVal);
				//Search 
				enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
				waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
				ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
				
				
				sleep(minWaitVal);
			 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
			 	sleep(mediumWaitVal);
			 	
			 	//search alert id
			 	//iCDD_WorkItem.searchcustomeralerts(alertId);
			 	
			 	//open the search alert
			 	sleep(minWaitVal);
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				
				//Assign to me
				iCDD_WorkItem.assign_to_me();

				
				//next step and perform review checks
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Perform_checks);
				
				//click on work flow 
				sleep(minWaitVal);
				webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
				
				//select mandatory task
				iCDD_WorkItem.ValidateMandateCheck();
				
//				//click on Details button
//				sleep(minWaitVal);
//				ICDD_CustomerRecord.click_Details_Button();
//				
//				//next step and client contact in progress
//				sleep(minWaitVal);
//				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Client_Contact_Progress);
//				
//				//next step and Client_Contact_Completed
//				sleep(minWaitVal);
//				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Client_Contact_Completed);
//				
				
				//next step and Documment tagging
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Document_tagging);
				
				//next step and Reacessement
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Re_assess_client_risk);
				
			 	
				//Change step to submit to checker
				iCDD_WorkItem.changestep("Submit to Checker");
				sleep(mediumWaitVal);
				
				//Logout the application
				iCDD_WorkItem.logout();
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
				
			      System.out.println("Sucessfully close the alert"+alertId);
			      
			    //Logout the application
					iCDD_WorkItem.logout();
				
				
				break;

				
			case "Perform Review Checks":
				
				//login as assigner
				iCDD_WorkItem.loginApplication("1581121G", "abc12345");
				
				//click on customer tab
				sleep(minWaitVal);
				webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				
				sleep(minWaitVal);
				//Search and open the customer 
				enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
				waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
				ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
				
				//Open the alert 
				sleep(minWaitVal);
			 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(mediumWaitVal);
			 	sleep(mediumWaitVal);
			 	
			 	//search alert id
			 	iCDD_WorkItem.searchcustomeralerts(alertId);
			 	
			 	//open the search alert
			 	sleep(minWaitVal);
				 iCDD_WorkItem.Open_filtered_Alert(alertId);

			 	
			 	//assign to me
			 	iCDD_WorkItem.assign_to_me();
			 	
			 	//click on work flow 
				sleep(minWaitVal);
				webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
				
				//select mandatory task
				iCDD_WorkItem.ValidateMandateCheck();
				
				//click on Details button
				sleep(minWaitVal);
				ICDD_CustomerRecord.click_Details_Button();
				
				/*//next step and client contact in progress
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Client_Contact_Progress);
				
				//next step and Client_Contact_Completed
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Client_Contact_Completed);
				*/
				
				//next step and Documment tagging
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Document_tagging);
				
				//next step and Reacessement
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Re_assess_client_risk);
				
			 	
				//Change step to submit to checker
				iCDD_WorkItem.changestep("Submit to Checker");
				sleep(mediumWaitVal);
				
				//Logout the application
				iCDD_WorkItem.logout();
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
			      
			      System.out.println("Sucessfully close the alert"+alertId);
				
			    //Logout the application
					iCDD_WorkItem.logout();

				
				break;	
				
			case "Client Contact in Progress":
				
				//login as assigner
				iCDD_WorkItem.loginApplication("1581121G", "abc12345");
				
				//click on customer tab
				sleep(minWaitVal);
				webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				
				sleep(minWaitVal);
				//Search and open the customer 
				enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
				waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
				ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
				
				//Open the alert 
				sleep(minWaitVal);
			 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(mediumWaitVal);
			 	sleep(mediumWaitVal);
			 	//search alert id
			 	iCDD_WorkItem.searchcustomeralerts(alertId);
			 	
			 	//open the search alert
			 	sleep(minWaitVal);
				 iCDD_WorkItem.Open_filtered_Alert(alertId);

			 	
			 	//assign to me
			 	iCDD_WorkItem.assign_to_me();
			 	
			 	//click on work flow 
				sleep(minWaitVal);
				webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
				
				//select mandatory task
				iCDD_WorkItem.ValidateMandateCheck();
				
				//click on Details button
				sleep(minWaitVal);
				ICDD_CustomerRecord.click_Details_Button();
				
				
				//next step and Client_Contact_Completed
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Client_Contact_Completed);
				
				//next step and Documment tagging
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Document_tagging);
				
				//next step and Reacessement
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Re_assess_client_risk);
				
			 	
				//Change step to submit to checker
				iCDD_WorkItem.changestep("Submit to Checker");
				sleep(mediumWaitVal);
				
				//Logout the application
				iCDD_WorkItem.logout();
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
			      
			      System.out.println("Sucessfully close the alert"+alertId);
				
			    //Logout the application
					iCDD_WorkItem.logout();
					
				break;
				
			case "Client Contact Completed":
				
				//login as assigner
				iCDD_WorkItem.loginApplication("1581121G", "abc12345");
				
				//click on customer tab
				sleep(minWaitVal);
				webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				
				sleep(minWaitVal);
				//Search and open the customer 
				enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
				waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
				ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
				
				//Open the alert 
				sleep(minWaitVal);
			 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(mediumWaitVal);
			 	sleep(mediumWaitVal);
			 	
			 	//search alert id
			 	iCDD_WorkItem.searchcustomeralerts(alertId);
			 	
			 	//open the search alert
			 	sleep(minWaitVal);
				 iCDD_WorkItem.Open_filtered_Alert(alertId);

			 	
			 	//assign to me
			 	iCDD_WorkItem.assign_to_me();
			 	
			 	//click on work flow 
				sleep(minWaitVal);
				webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
				
				//select mandatory task
				iCDD_WorkItem.ValidateMandateCheck();
				
				//click on Details button
				sleep(minWaitVal);
				ICDD_CustomerRecord.click_Details_Button();
				
				
				//next step and Documment tagging
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Document_tagging);
				
				//next step and Reacessement
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Re_assess_client_risk);
				
			 	
				//Change step to submit to checker
				iCDD_WorkItem.changestep("Submit to Checker");
				sleep(mediumWaitVal);
				
				//Logout the application
				iCDD_WorkItem.logout();
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
			      
			      System.out.println("Sucessfully close the alert"+alertId);
				
			    //Logout the application
					iCDD_WorkItem.logout();
					
				break;
				
			case "Document Tagging":	
				
				//login as assigner
				iCDD_WorkItem.loginApplication("1581121G", "abc12345");
				
				//click on customer tab
				sleep(minWaitVal);
				webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				
				sleep(minWaitVal);
				//Search and open the customer 
				enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
				waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
				ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
				
				//Open the alert 
				sleep(minWaitVal);
			 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(mediumWaitVal);
			 	sleep(mediumWaitVal);
			 	
			 	//search alert id
			 	iCDD_WorkItem.searchcustomeralerts(alertId);
			 	
			 	//open the search alert
			 	sleep(minWaitVal);
				 iCDD_WorkItem.Open_filtered_Alert(alertId);

			 	
			 	//assign to me
			 	iCDD_WorkItem.assign_to_me();
			 	
			 	//click on work flow 
				sleep(minWaitVal);
				webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
				
				//select mandatory task
				iCDD_WorkItem.ValidateMandateCheck();
				
				//click on Details button
				sleep(minWaitVal);
				ICDD_CustomerRecord.click_Details_Button();
				
				//next step and Reacessement
				sleep(minWaitVal);
				mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Re_assess_client_risk);
				
			 	
				//Change step to submit to checker
				iCDD_WorkItem.changestep("Submit to Checker");
				sleep(mediumWaitVal);
				
				//Logout the application
				iCDD_WorkItem.logout();
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
			      
			      System.out.println("Sucessfully close the alert"+alertId);
				
			    //Logout the application
					iCDD_WorkItem.logout();
                    break;
              
         case "Re-assess client risk":	
				
				//login as assigner
				iCDD_WorkItem.loginApplication("1581121G", "abc12345");
				
				//click on customer tab
				sleep(minWaitVal);
				webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
				
				sleep(minWaitVal);
				//Search and open the customer 
				enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
				ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
				waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
				ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
				
				//Open the alert 
				sleep(minWaitVal);
			 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(mediumWaitVal);
			 	sleep(mediumWaitVal);
			 	
			 	//search alert id
			 	iCDD_WorkItem.searchcustomeralerts(alertId);
			 	
			 	//open the search alert
			 	sleep(minWaitVal);
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
			 	
			 	
			 	//assign to me
			 	iCDD_WorkItem.assign_to_me();
			 	
			 	//click on work flow 
				sleep(minWaitVal);
				webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
				
				//select mandatory task
				iCDD_WorkItem.ValidateMandateCheck();
				
				//click on Details button
				sleep(minWaitVal);
				ICDD_CustomerRecord.click_Details_Button();
				
			 	
				//Change step to submit to checker
				iCDD_WorkItem.changestep("Submit to Checker");
				sleep(mediumWaitVal);
				
				//Logout the application
				iCDD_WorkItem.logout();
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
			      
			      System.out.println("Sucessfully close the alert"+alertId);
				
			    //Logout the application
					iCDD_WorkItem.logout();
                    break;
                    
         case "Submit to Checker":	
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
			      
			      System.out.println("Sucessfully close the alert"+alertId);
				
			    //Logout the application
					iCDD_WorkItem.logout();
                 break;
   		
         case "Approval B - Checker":	
				
				//Login as Checker
				iCDD_WorkItem.loginApplication("1273626E", "abc12345");
				
				//click on workbench workitem
				ieButtonJSClick(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
				
				//click on dropdown and select All Items
				iCDD_WorkItem.selectOptionsInMyItems("All Items");
				 sleep(minWaitVal);
				 
				//search the alert 
				 iCDD_WorkItem.searchcustomeralerts(alertId);
				 
				//open the search alert
				 iCDD_WorkItem.Open_filtered_Alert(alertId);
				 
				//Assign to me
					iCDD_WorkItem.assign_to_me();
			    //click on work flow 
				  sleep(minWaitVal);
				  webDriverWait(ICDD_WorkItem_Obj.WORKFLOW);
				  ieButtonJSClick(ICDD_WorkItem_Obj.WORKFLOW);
					
			    //select mandatory task
				  iCDD_WorkItem.ValidateMandateCheck();
					
				 //change step to reviewd and closed by checker
				  sleep(minWaitVal);
			      mouseHoverClick(ICDD_WorkItem_Obj.Next_step_tab, ICDD_WorkItem_Obj.Reviewed_Closed_By_Checker);
			      
			      System.out.println("Sucessfully close the alert"+alertId);
				
			    //Logout the application
					iCDD_WorkItem.logout();
              break;
 
			}	
        }
		}
        catch(Exception e){
        	
        	System.out.println("There is no open alerts present for the customer id:"+testData.get("ICDD_ID"));
        }
		
		
	
	}
	
public  void assign_the_alert() throws Exception{
	
	webDriverWait(ICDD_WorkItem_Obj.ASSIGN_TO_ME);
	ieButtonJSClick(ICDD_WorkItem_Obj.ASSIGN_TO_ME);
	sleep(mediumWaitVal);
	switchWindow("[Actimize] Change Item User/BU");
	
	webDriverwait(ICDD_WorkItem_Obj.OK_BUTTON);
    ieButtonJSClick(ICDD_WorkItem_Obj.OK_BUTTON);
    sleep(minWaitVal);
    switchToParentWindow();
	

}
	

}
