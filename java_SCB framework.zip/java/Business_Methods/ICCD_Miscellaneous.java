package Business_Methods;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICDD_Forms_Obj;
import Object_Repository.ICDD_WorkItem_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;

public class ICCD_Miscellaneous extends Common_Utils{
	
	public void viewSettingTab(String Platform_Lists)
	{
		List<WebElement> listOfOptionsSettingTab=BaseTestSetup.driver.findElements(By.xpath("//*[@id='rcmMenu']/ul/li[2]/ul/li"));
		for (WebElement option : listOfOptionsSettingTab) {
			   if (option.getText().trim().equalsIgnoreCase("Platform_Lists"))
			   {
				   System.out.println("CRA Configs Group is able to view the module tab/section" +Platform_Lists +"in Setting Tab");}
			   else{
				   System.out.println("CRA Configs Group is not able to view the module tab/section" +Platform_Lists +"in Setting Tab");}
		       }
	}
	
	public void clickSettingTab(String Platform_Lists_page) throws Exception
	{
		List<WebElement> listOfOptionsSettingTab=BaseTestSetup.driver.findElements(By.xpath("//*[@id='rcmMenu']/ul/li[2]/ul/li"));
		for (WebElement option : listOfOptionsSettingTab) {
			   if (option.getText().trim().equalsIgnoreCase("Platform_Lists"))
			   {   
				   triggerOnClick(option);
			       WebElement title=BaseTestSetup.driver.findElement(By.xpath("//*[@class='panel']/div[1]/h2"));  
				   if(title.getText().equalsIgnoreCase("Platform_Lists_page")){
					   System.out.println(Platform_Lists_page +"is page loaded sucessfully  ");}
			       else{
			    	   System.out.println(Platform_Lists_page + "is page loaded sucessfully");}
			   }else{
				   System.out.println("CRA Configs Group is unable to click on module tab" +Platform_Lists_page +"in Setting Tab");}
		}
	}

	public void cra_Code(String cra_code)
	{
		List<WebElement> tr_collection =BaseTestSetup.driver.findElements(By.xpath("//*[@id='internalListsGridModel']//tr"));
		int row_num=2,col_num=2;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(By.tagName("td")); 
			col_num=2;
			for (WebElement tdElement  :td_collection)
			{
				WebElement ActualValue = driver.findElement(By.xpath("//*[@id='internalListsGridModel']//tr["+row_num+"]/td[2]"));
				if(ActualValue.getAttribute("title").trim().equalsIgnoreCase(cra_code))
				{
					ActualValue.click();
					System.out.println("Sub Page"+cra_code + "is loaded sucessfully");}
				else
				{
					System.out.println("Sub Page"+cra_code + "is not loaded sucessfully");}
				}
	     }
		}
	
	public void click_Action(String action) throws Exception
	{
		List<WebElement> listOfOptionsActionTab=BaseTestSetup.driver.findElements(By.xpath("(//*[@class='showAll'])[2]//tr/td[2]"));
		for (WebElement option : listOfOptionsActionTab) {
			   if (option.getText().trim().equalsIgnoreCase(action))
			   {   
				   triggerOnClick(option);
				   String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
					System.out.println("Original wingow:" +originalWindow1);
				    Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
			        for (String win : chwin1) { 
			        if (!originalWindow1.equals(win)) {;
			        BaseTestSetup.driver.switchTo().window(win);
			        String errormessage=BaseTestSetup.driver.findElement(By.xpath("//*[@class='error404text']//tr[2]/td")).getText();
			        
			        if(errormessage.equalsIgnoreCase("Access to this action is denied for the current user role")){
			        	System.out.println("CRA Group does not have permission to perform the function of the" +action);}
			        else{
			        	System.out.println("CRA Group have permission to perform the function of the" +action);}
			        }}
			   }
	}
	
	
	}
	
	public void view_item()
	{
		List<WebElement> listOfViewItem=driver.findElements(By.xpath("//*[@class='cbox'][1]"));
		System.out.println(listOfViewItem);
		System.out.println("CRA Group is able to view the item");
		
	}
	
	public void click_on_item()
	{
		BaseTestSetup.driver.findElement(By.xpath("(//*[@class='cbox'][1])[1]")).click();
		
	}
	
	public void export_import(String fileoption) throws Exception
	{
		List<WebElement> listOfOptionsActionTab=BaseTestSetup.driver.findElements(By.xpath("//*[@class='dropdown-toggle button actimizeIconButton']//ul//a/i"));
		for (WebElement option : listOfOptionsActionTab) {
			   if (option.getText().trim().equalsIgnoreCase(fileoption))
			   {   
				   BaseTestSetup.driver.findElement(By.xpath("(//*[@class='cbox'][1])[1]")).click();
				   triggerOnClick(option);
				   String errormessage=BaseTestSetup.driver.findElement(By.xpath("//*[@class='error404text']//tr[2]/td")).getText();
			        
			        if(errormessage.equalsIgnoreCase("Access to this action is denied for the current user role")){
			        	System.out.println("CRA Group does not have permission to perform the function of the" +fileoption);}
			        else{
			        	System.out.println("CRA Group is able to export the file" +fileoption);}
			   }
	}
	}
	public void click_approve_button()
	{
		BaseTestSetup.driver.findElement(By.xpath("//*[@title='Approve']']")).click();
	}
	
	public void View_History()
	{
		BaseTestSetup.driver.findElement(By.xpath("//*[@id='icon_view_history']")).click();	
	}
	
	public void view_workbench_report(String ReportTab)
	{
		WebElement mainMenu = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
	    Actions action = new Actions(BaseTestSetup.driver);
		action.moveToElement(mainMenu).build().perform();
		WebElement subMenu = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.REPORT);
		if(subMenu.getText().equalsIgnoreCase(ReportTab))
		{
			System.out.print("User is able to view"+ReportTab+"from Workbench Dropdown");
		}
	}
	
	public void click_workbench_report(){
		WebElement mainMenu = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
	    Actions action = new Actions(BaseTestSetup.driver);
		action.moveToElement(mainMenu).build().perform();
		WebElement subMenu = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.REPORT);
		action.moveToElement(subMenu).click().build().perform();
		System.out.println("User is able to click on Report From WorkBench Item Dropdown");
		
	}
	
	
	 public void selectOptionsInMyItems(String workitem) throws Exception {
	     Thread.sleep(10000);
	     WebElement element1=BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN);
	     element1.click();
	     List<WebElement> listOfOptions = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.WORKITEMS_ALL_OPTIONS);
	     for (WebElement option : listOfOptions) {
	     if (option.getText().trim().equalsIgnoreCase(workitem.trim())) {
	     triggerOnClick(option);
	     System.out.print("Value is selected from drop down");
	       }
	    }
	 }   
	     public void clickCustomerTab() throws Exception
	 	{
	 		try{
	 			BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(ICDD_CustomerRecord_Obj.CUSTOMER_TAB));
	             clickPerform(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
	             System.out.println("User is able to click on Customer Tab");
	 		}
	 		catch(Exception e)
	 		{
	 			throw new Exception("Error while searching customer with ICCD Reference Id"+" :"+e.getMessage());
	 		}
	 	 }

	     public void clickiccdid() throws Exception
	     {
	     	try{
	     		System.out.println(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCHEDLINK).getText());
	     		WebDriverWait wait = new WebDriverWait(BaseTestSetup.driver, 50);
	     		clickPerform(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCHEDLINK);	
	     		System.out.println("Customer Alert Page is loaded");
	     	}
	     	catch(Exception e)
	 		{
	 			throw new Exception("Error while clicking on ICCD Reference Id"+" :"+e.getMessage());
	 		}
	     }
	     
	    public void searchCustomerType(String customerType ) throws Exception
	    {
	    	selectElementByName(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_CUSTOMERTYPE, customerType);
	    	driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).click();
	    	System.out.println("User is able to see list of Alert");
	        System.out.print("Click on Customer Alert");
			BaseTestSetup.driver.findElement(By.id("detailsBtn")).click();
	        Thread.sleep(2000);
	        BaseTestSetup.driver.switchTo().frame("frmDetails");
			WebElement link = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.CUSTOMER_ALERT_BUTTON);
	        Actions action = new Actions(BaseTestSetup.driver);
	        action.moveToElement(link).click(link).build().perform();	 
		 } 
	    
	    public void itemOnCustomerAlertPage(String addnote) throws Exception
	    {
	    	switch (addnote) {
			case "Add Note":
				clickPerform(ICDD_WorkItem_Obj.ADDNOTE);
		        Thread.sleep(10000);
		        String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
			    Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin1) { 
		        if (!originalWindow1.equals(win)) {
		        BaseTestSetup.driver.switchTo().window(win);
		        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
		        if(message.contains("addnote")){
		        	System.out.println("the window titled "+addnote+" is loaded");}
		        else{
		        	System.out.println("the window titled "+addnote+" is not loaded");
		        }
		       }      }
		        break;
		        
			case "View Notes":
				clickPerform(ICDD_WorkItem_Obj.VIEWNOTE);
		        Thread.sleep(10000);
		        String originalWindow2 =BaseTestSetup.driver.getWindowHandle();
			    Set<String> chwin2 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin2) { 
		        if (!originalWindow2.equals(win)) {
		        BaseTestSetup.driver.switchTo().window(win);
		        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
		        if(message.contains("addnote")){
		        	System.out.println("the window titled "+addnote+" is loaded");}
		        else{
		        	System.out.println("the window titled "+addnote+" is not loaded");
		        }
		       }      }
				break;
				
			case "Add Attachments":
				clickPerform(ICDD_WorkItem_Obj.ADD_ATTACHMENT);
		        Thread.sleep(10000);
		        String originalWindow3 =BaseTestSetup.driver.getWindowHandle();
			    Set<String> chwin3 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin3) { 
		        if (!originalWindow3.equals(win)) {
		        BaseTestSetup.driver.switchTo().window(win);
		        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
		        if(message.contains("addnote")){
		        	System.out.println("the window titled "+addnote+" is loaded");}
		        else{
		        	System.out.println("the window titled "+addnote+" is not loaded");
		        }
		        BaseTestSetup.driver.findElement(By.xpath("//*[@id='CSaddNoteTab_text']")).click();
		        Select addNoteSlt = new Select(BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ADDNOTEDROP));
		        addNoteSlt.selectByIndex(1);
		        System.out.println("User ia bale to select value from Dropdown");
		        BaseTestSetup.driver.switchTo().frame("noteModelFreeTextNote_ifr");
		        BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.id("tinymce")));
		        BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.COMMENTS).click();
		        BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.COMMENTS).sendKeys("testing");
		        BaseTestSetup.driver.switchTo().defaultContent();
		        clickPerform(ICDD_WorkItem_Obj.OKBUTTON);
		        BaseTestSetup.driver.switchTo().window(originalWindow3);
		        
		       }      }
				break;
				
			case "View Attachments":
				clickPerform(ICDD_WorkItem_Obj.VIEW_ATTACHMENT);
		        Thread.sleep(10000);
		        String originalWindow4 =BaseTestSetup.driver.getWindowHandle();
			    Set<String> chwin4 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin4) { 
		        if (!originalWindow4.equals(win)) {
		        BaseTestSetup.driver.switchTo().window(win);
		        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
		        if(message.contains("addnote")){
		        	System.out.println("the window titled "+addnote+" is loaded");}
		        else{
		        	System.out.println("the window titled "+addnote+" is not loaded");
		        }
		       }      }
				break;
			case "Export":	
				mouseOver(ICDD_Forms_Obj.EXPORT_ICON);
		        int export = BaseTestSetup.driver.findElements(ICDD_Forms_Obj.EXPORT).size();
		        if (export != 0) {
		            sub_menu(ICDD_Forms_Obj.EXPORT_ICON, ICDD_Forms_Obj.EXPORT);
		        System.out.println("User ia able to Export the File Sucessully");    
		        }
				break;
			case "Send Mail":
				sub_menu(ICDD_Forms_Obj.EXPORT_ICON, ICDD_Forms_Obj.SEND_MAIL);
				System.out.println("window pops-up with the alert details shown in PDF format");
				break;
			case "Create RFI":
				int createRFI = BaseTestSetup.driver.findElements(ICDD_Forms_Obj.CREATE_RFI).size();
		        if (createRFI != 0) {
		            sub_menu(ICDD_Forms_Obj.RFI_ICON, ICDD_Forms_Obj.CREATE_RFI);
		            String originalWindow5 =BaseTestSetup.driver.getWindowHandle();
				    Set<String> chwin5 = BaseTestSetup.driver.getWindowHandles();
			        for (String win : chwin5) { 
			        if (!originalWindow5.equals(win)) {
			        BaseTestSetup.driver.switchTo().window(win);
			        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
			        if(message.contains("addnote")){
			        	System.out.println("the window titled "+addnote+" is loaded");}
			        else{
			        	System.out.println("the window titled "+addnote+" is not loaded");
			        }
			       }      }}
				break;	
			case "View RFIs":
				int viewRFI = BaseTestSetup.driver.findElements(ICDD_Forms_Obj.VIEW_RFIS).size();
		        if (viewRFI != 0) {
		            sub_menu(ICDD_Forms_Obj.RFI_ICON, ICDD_Forms_Obj.VIEW_RFIS);
		            String originalWindow5 =BaseTestSetup.driver.getWindowHandle();
				    Set<String> chwin5 = BaseTestSetup.driver.getWindowHandles();
			        for (String win : chwin5) { 
			        if (!originalWindow5.equals(win)) {
			        BaseTestSetup.driver.switchTo().window(win);
			        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
			        if(message.contains("addnote")){
			        	System.out.println("the window titled "+addnote+" is loaded");}
			        else{
			        	System.out.println("the window titled "+addnote+" is not loaded");
			        }
			       }      }}
				break;	
			case "Print List":
				mouseOver(ICDD_Forms_Obj.EXPORT_ICON);
		        int printlist = BaseTestSetup.driver.findElements(ICDD_Forms_Obj.EXPORT).size();
		        if (printlist != 0) {
		            sub_menu(ICDD_Forms_Obj.EXPORT_ICON, ICDD_Forms_Obj.PRINT_LIST);
		            String originalWindow5 =BaseTestSetup.driver.getWindowHandle();
				    Set<String> chwin5 = BaseTestSetup.driver.getWindowHandles();
			        for (String win : chwin5) { 
			        if (!originalWindow5.equals(win)) {
			        BaseTestSetup.driver.switchTo().window(win);
			        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
			        if(message.contains("addnote")){
			        	System.out.println("the window titled "+addnote+" is loaded");}
			        else{
			        	System.out.println("the window titled "+addnote+" is not loaded");
			        }
			       }      }}
				break;
			case "Print Details":
				mouseOver(ICDD_Forms_Obj.EXPORT_ICON);
		        int printdetails = BaseTestSetup.driver.findElements(ICDD_Forms_Obj.EXPORT).size();
		        if (printdetails != 0) {
		            sub_menu(ICDD_Forms_Obj.EXPORT_ICON, ICDD_Forms_Obj.PRINT_DETAILS);
		            System.out.println("Print Details is displayed Sucessfully");}
				break;
			case "Advanced Filter":
				BaseTestSetup.driver.findElement(By.xpath("//*[@id='icon_advancedFilter']")).click();
				String originalWindow5 =BaseTestSetup.driver.getWindowHandle();
			    Set<String> chwin5 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin5) { 
		        if (!originalWindow5.equals(win)) {
		        BaseTestSetup.driver.switchTo().window(win);
		        String message=BaseTestSetup.driver.findElement(By.xpath("//*[@id='dialogHeader']")).getText();
		        if(message.contains("addnote")){
		        	System.out.println("the window titled "+addnote+" is loaded");}
		        else{
		        	System.out.println("the window titled "+addnote+" is not loaded");
		        }
		        BaseTestSetup.driver.findElement(By.xpath("//*[@id='textButton__SubmitButton']")).click();
		      
		       }      }
				break;
			case "General Picker":
				BaseTestSetup.driver.findElement(By.xpath("//*[@id='icon_advancedFilter']")).click();
				String originalWindow6 =BaseTestSetup.driver.getWindowHandle();
			    Set<String> chwin6 = BaseTestSetup.driver.getWindowHandles();
		        for (String win1 : chwin6) { 
		        if (!originalWindow6.equals(win1)) {
		        BaseTestSetup.driver.switchTo().window(win1);
		        BaseTestSetup.driver.findElement(By.xpath("//*[@id='statusId_picker'])")).click();
		        System.out.println("All step will is Displayed");
		        BaseTestSetup.driver.findElement(By.xpath("//*[@id='alertTypeInternalId_picker']")).click();
		        System.out.println("All Item Type is Displayed");
		        }  } 	
				break;	
			
			default:
				
	            break;
				
				
				
	    	}    	}    
	    
	    public void assign_to_me() throws Exception{
			 try {
				Thread.sleep(10000);			 
				clickPerform(ICDD_WorkItem_Obj.ASSIGN_TO_ME);
				Thread.sleep(40000);
				String originalWindow =BaseTestSetup.driver.getWindowHandle();
				System.out.println("Original wingow:" +originalWindow);
		        Set<String> chwin = BaseTestSetup.driver.getWindowHandles();
		        for (String win1 : chwin) {
		        	if (BaseTestSetup.driver.switchTo().window(win1).getTitle().equals("")){
		        		BaseTestSetup.driver.switchTo().window(win1).close();}}
		        String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
		        System.out.println("Original wingow:" +originalWindow1);
				Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin1) { 
		            if (!originalWindow.equals(win)) {
		                BaseTestSetup.driver.switchTo().window(win);
		                System.out.print("child window:" +win);
		                Thread.sleep(3000);
		                BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.OK_BUTTON).click();
		                Thread.sleep(1000);
		                BaseTestSetup.driver.switchTo().window(originalWindow);}}
		      }
		      catch (Exception e) {
		          throw new Exception("Error while assigning the alert to user himself" + " :" + e.getMessage());}
		}
	    public void changestep(String next_value) throws Exception {
	        try {
	        	
	            String aftrchangestep;
	            triggerOnClick(BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP));
	            BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(2));
	            switchWindow("[Actimize] Change Step");
	            Thread.sleep(3000);
	            BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP_DROPDWN));
	            clickPerform(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP_DROPDWN);
	            BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[contains(text(),'" + next_value + "')]")));
	            BaseTestSetup.waitForTitleisPresent(By.xpath("//td[contains(text(),'" + next_value + "')]"));
	            triggerOnClick(BaseTestSetup.driver.findElement(By.xpath("//td[contains(text(),'" + next_value + "')]")));
	            BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.id("changeStatusNoteModelFreeTextNote_ifr")));
	            WebElement we = BaseTestSetup.driver.findElement(By.id("changeStatusNoteModelFreeTextNote_ifr"));
	            BaseTestSetup.wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(we));
	            BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(ICDD_WorkItem_Obj.ALERTSDETAIL_CHANGESTEP_TEXTFIELD));
	            enterInput(ICDD_WorkItem_Obj.ALERTSDETAIL_CHANGESTEP_TEXTFIELD, "Change alert step to " + next_value);
	            BaseTestSetup.driver.switchTo().defaultContent();
	            clickPerform(By.id("textButton_changeStatusDialog_SubmitButton"));
	            if (next_value.equals("Submit to Checker") || next_value.equals("Re-assess client risk")) {
	            	Thread.sleep(10000);
	                BaseTestSetup.driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	            	Set<String> currentWindows = null;
	                while (currentWindows == null || currentWindows.size() < 1) {
	                    currentWindows = BaseTestSetup.driver.getWindowHandles();
	                }
	                if (currentWindows.size() > 1) {
	                    for (String window : currentWindows) {
	                        BaseTestSetup.driver.switchTo().window(window);
	                        if (BaseTestSetup.driver.getTitle().contains("[Actimize] Error")) {
	                            Thread.sleep(3000);
	                            BaseTestSetup.driver.findElement(By.id("textButton_close_button")).click();
	                            Thread.sleep(2000);
	                            break;
	                        }
	                    }
	                }
	            }
	            if (next_value.startsWith("Decision on")||next_value.contains("Submit")) {
	            	BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
	            	switchBackToParentWindow("[Actimize] Work Items");
	            }
	            else {
	                BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1)); 
	                switchBackToParentWindow("[Actimize] Item Details");
	            }
	            
	        }
	        catch (Exception e) {
	            throw new Exception("Error while changing the alert step" + next_value + " :" + e.getMessage());
	        }
	    }
	    public void click_ref_id() throws Exception
		{
			try {
				int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
	            int stateColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "State");
	            for (int i = 2; i <= n; i++) {
	                WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + stateColumnNumber + "]/div/img"));
	               
	                if (we.getAttribute("src").contains("/RCM/themes/new_york_blue/images/acm3.0/Open.png")) {
	                	if(we.getText().contains("")){
	                    Thread.sleep(2000);
	                    clickPerform(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[1]"));
	                    
	                	}
	                }
	                  
	            }
	        }
			catch (Exception e) {
	            throw new Exception("Error while selecting customer alerts" + " :" + e.getMessage());
	        }
		}
}