package Business_Methods;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICDD_Forms_Obj;
import Object_Repository.ICDD_WorkItem_Obj;
import java.*;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;
import utillities.ScreenshotUtil_old;
import utillities.SetupPropertiesLoader;

public class ICDD_CustomerRecord extends Common_Utils{
	DataProvider dataprovider = new DataProvider();
//	ScreenshotUtil_old screenshot = new ScreenshotUtil_old();
	ICDD_WorkItem iCDD_WorkItem = new ICDD_WorkItem();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	public HashMap<String, String> testData = null;
	public static WebDriverWait wait = null;
	public int i;
	public void allInputSearch(String scenarioName,HashMap<String, String> testData) throws Exception {
        try {
        	driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_TAB).click();
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_LASTNAME, testData.get("UserLastName"));
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_FIRSTNAME, testData.get("UserFirstName"));
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_TIN, testData.get("UserTIN"));
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ACCOUNTNUMBER, testData.get("UserAccountNo"));;
            selectElementByName(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_CUSTOMERTYPE, testData.get("UserCustomerType"));
            enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ALERTDATE, testData.get("UserAlertDate"));
            driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).click();
        }
        catch (Exception e) {
            throw new Exception("Error while searching customer with all inputs"+" :"+e.getMessage());
        }

    }
	
	public void enterUserNameSearch(String scenarioName,HashMap<String, String> testData) throws Exception
	{
		try{
			driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_TAB).click();
			enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_LASTNAME, testData.get("UserLastName"));
			enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_FIRSTNAME, testData.get("UserFirstName"));
		}
		catch (Exception e) {
	            throw new Exception("Error while searching customer with name: "+testData.get("UserLastName")+" "+testData.get("UserFirstName")+" :"+e.getMessage());
	        }
	}
	
	public void searchiccdId(String scenarioName,HashMap<String, String> testData) throws Exception
	{
		try{
			BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(ICDD_CustomerRecord_Obj.CUSTOMER_TAB));
            ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
            waitForElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID);
            enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID").trim());sleep(minWaitVal);
			 screenshot();
			 BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).sendKeys("");
			 ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);
			 //BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).click();sleep(minWaitVal);
			 screenshot();
			// BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH));
		}
		catch(Exception e)
		{
			screenshot();
			throw new Exception("Error while searching customer with ICCD Reference Id"+" :"+e.getMessage());
		}
	 }

    public void clickiccdid(String scenarioName,HashMap<String, String> testData) throws Exception
    {
    	try{
    		//System.out.println(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCHEDLINK).getText());
    		//WebDriverWait wait = new WebDriverWait(BaseTestSetup.driver, 50);
    		sleep(minWaitVal);
    		//waitForTextToLoad(By.xpath("//a[@class='customerLink'][text()='"+testData.get("ICDD_ID")+"']"), testData.get("ICDD_ID"));
    		//sleep(minWaitVal);webDriverWait(By.xpath("//a[@class='customerLink'][text()='"+testData.get("ICDD_ID")+"']"));
    		waitForElement(By.xpath("//a[@class='customerLink'][text()='"+testData.get("ICDD_ID")+"']"));
    		click(By.xpath("//a[@class='customerLink'][text()='"+testData.get("ICDD_ID")+"']"));
    		screenshot();
    		sleep(mediumWaitVal);
    	}
    	catch(Exception e)
		{
    		screenshot();
			throw new Exception("Error while clicking on ICCD Reference Id"+" :"+e.getMessage());
		}
    }
	
	public void Verify_the_details(String scenarioName,HashMap<String, String> testData)
	{
		try
		{
			List<WebElement> tr_collection = BaseTestSetup.driver.findElements(ICDD_CustomerRecord_Obj.CUSTOMERDATA_TOTAL_ROWS);
			int row_num=1,col_num=1;
			for (WebElement trElement : tr_collection) {
			     List<WebElement> td_collection = trElement.findElements(By.tagName("td")); 
			     int n = td_collection.size();
			    	col_num=1;
			     for (WebElement tdElement  :td_collection) {
			    	String ActualValue = BaseTestSetup.driver.findElement(By.xpath("(//table[@class='clsGridTableBase']/tbody/tr[2]/td)["+col_num+"]")).getText().trim();
			    	System.out.println("Actual Value"+ActualValue);
			    	switch (ActualValue) {
					case "ICDD ID":
						if (!testData.get("referenceID").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("referenceID"))){
									   System.out.println("Actual ICCD Reference Number is: " +tdElement.getText() + ", Expected ICCD Reference Number is: " + testData.get("referenceID") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Active":
						if (!testData.get("Active").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("Active"))){
									   System.out.println("Actual Active Value is: " +tdElement.getText() + ", Expected Actual Value is: " + testData.get("Active") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "TIN":
						if (!testData.get("UserTIN").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("TIN"))){
									   System.out.println("Actaul TIN Value is: " +tdElement.getText() + ", Expected TIN Value is: " + testData.get("TIN") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Customer Name":
						if (!testData.get("CustomerName").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("CustomerName"))){
									   System.out.println("Actual Customer Name is: " +tdElement.getText() + ", Expected Customer Name Value is: " + testData.get("CustomerName") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Customer Type":
						if (!testData.get("UserCustomerType").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("UserCustomerType"))){
									   System.out.println("Actual Customer Type Value is: " +tdElement.getText() + ", Expected Customer Type Value is: " + testData.get("UserCustomerType") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Risk Score":
						if (!testData.get("RiskScore").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("RiskScore"))){
									   System.out.println("Actual Risk Score is: " +tdElement.getText() + ", Expected Risk Score is: " + testData.get("RiskScore") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					default:
						col_num++;
			            break;
			    	}	
			     }		
			}			
		}	
		catch(Exception e)
		{
			
		}
	}
	


	public void searchCustomer_ICDD_ID(String scenarioName,HashMap<String, String> testData) throws Exception {
		System.out.println("Searching the Customer");
		sleep(mediumWaitVal);
		this.testData = testData;		
		sleep(minWaitVal);
		webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
		screenshot();
		sleep(minWaitVal);
		enterInputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);
		waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
		ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
		
		sleep(mediumWaitVal);
		screenshot();
		Log.info(testData.get("ICDD_ID")+ " ICDD ID is searched & opened successfully ");
		System.out.println(testData.get("ICDD_ID")+ " ICDD ID is searched & opened successfully ");
	}
	
	public void Details_Of_Customer()throws Exception{
		
		sleep(minWaitVal);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB);
		screenshot();
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.ONBOARDING_TAB);
		screenshot();
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CLIENT_RISK_RATING));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CLIENT_RISK_RATING);
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.OVERRIDE_DETAILS);
		
		screenshot();
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB);
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.PREVIOUS_RISK_RATING_TAB);
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.FCC_RISK_EVENT_TAB);
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CRA_TAB);
		screenshot();
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.PROHIBITION_TAB);
		
		if(isWebElementDisplayed(ICDD_CustomerRecord_Obj.TRR_MAKER_NOTIFIER))
		{
		ieButtonJSClick(ICDD_CustomerRecord_Obj.TRR_MAKER_NOTIFIER);
		screenshot();
		}
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_CODE_DETAILS));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.RISK_CODE_DETAILS);
		
		sleep(minWaitVal);
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MANUAL_VERIFICATION));
		screenshot();

		
	}
	
	public void Risk_code_Details()throws Exception{
		sleep(mediumWaitVal);
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_CODE_DETAILS));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.RISK_CODE_DETAILS);
		sleep(minWaitVal);
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MANUAL_VERIFICATION));
        screenshot();

		
	}


	public void createSavePDF(String scenarioName,HashMap<String, String> testData) throws Exception{
		searchiccdId(scenarioName, testData);
    	clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.PEP_WORKITEM);
		click(ICDD_CustomerRecord_Obj.PDF_MENU);sleep(minWaitVal);
		click(ICDD_CustomerRecord_Obj.PDF_ICON);sleep(mediumWaitVal);
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SHIFT);
			robot.keyPress(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_SHIFT);
			robot.keyRelease(KeyEvent.VK_S);
			sleep(minWaitVal);
			for(int i=0;i<=4;i++){
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				if(i==4){
					enterbyRobot();
					robotCopyPaste(SetupPropertiesLoader.getProperty("PDF1", "config"));sleep(500);
					enterbyRobot();sleep(500);
					enterbyRobot();
				}
			}
			try{
				robot.keyPress(KeyEvent.VK_LEFT);
				robot.keyRelease(KeyEvent.VK_LEFT);enterbyRobot();}
			catch (Exception e) {
			}
		} catch (AWTException e) {
		}
	}
	
	
	public void addAttachment(String scenarioName,HashMap<String, String> testData) throws Exception{
		searchiccdId(scenarioName, testData);
    	clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_CustomerRecord_Obj.CHECK_ALERT);
	//	iCDD_WorkItem.assign_to_me();
		click(ICDD_CustomerRecord_Obj.ADD_ATTACHMENT);sleep(maxWaitVal);
		switchToWindow();
		click(ICDD_CustomerRecord_Obj.ADD_ATTACHMENT_FILE);sleep(mediumWaitVal);
		//switchBackToParentWindow(windowTitle);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robotCopyPaste("Alerts.jsp.pdf");
		for(int i=0;i<=3;i++){
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			if(i==3){
				enterbyRobot();
				robotCopyPaste(SetupPropertiesLoader.getProperty("PDF1", "config"));sleep(500);
				enterbyRobot();sleep(500);
				enterbyRobot();
			}
		}
	}
	
	public void viewAttachment(String scenarioName,HashMap<String, String> testData) throws Exception{
		searchiccdId(scenarioName, testData);
    	clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_CustomerRecord_Obj.CHECK_ALERT);
		click(ICDD_CustomerRecord_Obj.VIEW_ATTACHMENT);sleep(maxWaitVal);
		switchToWindow();
		compareByText(ICDD_CustomerRecord_Obj.ATTACHEMENT_NAME, "Alerts.jsp.pdf");
		click(ICDD_CustomerRecord_Obj.CLOSE_ATTACHMENT_VIEW);
		switchToParentWindow();
	}
	
	
	public void bridge(String scenarioName,HashMap<String, String> testData, String sheetname) throws Exception{
	webDriverwait(By.xpath("//input[@id='autosearch']"));
	click(By.xpath("//input[@id='autosearch']"));
	inputText(By.xpath("//input[@id='autosearch']"), testData.get("StaffName"));sleep(minWaitVal);
	webDriverwait(By.xpath("//span[@class='result-title lnk'][text()='"+ testData.get("StaffName")+"']"));
	scrollUpVertical(driver.findElement(By.xpath("//span[@class='result-title lnk'][text()='"+ testData.get("StaffName")+"']")));
	click(By.xpath("//span[@class='result-title lnk'][text()='"+ testData.get("StaffName")+"']"));sleep(minWaitVal);
	
	webDriverWait(By.xpath("//span[text()='Title']/.."));
	String designation = driver.findElement(By.xpath("//span[text()='Title']/..")).getText();
	String number = driver.findElement(By.xpath("//span[text()='Phone Number']/..")).getText();
	String email = driver.findElement(By.xpath("//span[text()='Email']/..")).getText();
	StringBuffer sb1 = new StringBuffer(designation);
	StringBuffer sb2 = new StringBuffer(number);
	StringBuffer sb3 = new StringBuffer(email);
	String refID1 = sb1.delete(0, 5).toString().trim();
	String refID2 = sb2.delete(0, 12).toString().trim();
	String refID3 = sb3.delete(0, 5).toString().trim();
	System.out.println(refID1 + "||"+ refID2+ "||"+ refID3);
	dataprovider.insertExcelData(scenarioName, "Designation", sheetname, refID1);
	dataprovider.insertExcelData(scenarioName, "Phone_No", sheetname, refID2);
	dataprovider.insertExcelData(scenarioName, "Email_Id", sheetname, refID3);
	//
	String addLoc = driver.findElement(By.xpath("//*[@id='jive-body']//address")).getText();
	System.out.println(addLoc);
	dataprovider.insertExcelData(scenarioName, "AddressLoc", sheetname, addLoc);
	try{
	System.out.println(driver.findElement(By.xpath("//span[text()='Mobile Phone Number']")).getText());
	String mobNum = driver.findElement(By.xpath("//span[text()='Mobile Phone Number']/..")).getText();
	if(mobNum!=null){
	StringBuffer sb = new StringBuffer(mobNum);
	sb.delete(0, 19);
	String refID = sb.toString().trim();
	System.out.println(mobNum);
	System.out.println(refID);
	dataprovider.insertExcelData(scenarioName, "AlternateNumber", sheetname, refID);}
	}catch (Exception e) {
	}
	}

	public void click_on_Customer_Alert() {
		sleep(minWaitVal);
	 	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
	 	sleep(mediumWaitVal);
	 	screenshot();
	 	
	
	}

	public void verify_Customer_Status(String custStatus) {
		sleep(mediumWaitVal);
			String status=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.Customer_Status).getText().trim();
			Assert.assertEquals(custStatus, status);
			System.out.println("Customer_Status validation is sucessfull");
		
	}
	
	public void verify_Customer_Status_for_alert(String custStatus){
		
		BaseTestSetup.driver.switchTo().frame("frmDetails");
		String status=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.Customer_Status).getText().trim();
		BaseTestSetup.driver.switchTo().defaultContent();
		screenshot();
		Assert.assertEquals(custStatus, status);
		System.out.println("Customer_Status validation is sucessfull");
	}
	public void Verify_HHP_should_not_Present(String val){
		
		try{
			
			By byvalue=By.xpath("//td[contains(text(),'"+val+"')]");
			
			BaseTestSetup.driver.switchTo().frame("frmDetails");
			
			Boolean HHP_Presnce=isWebElementDisplayed(byvalue);
			
			BaseTestSetup.driver.switchTo().defaultContent();
			
			if(HHP_Presnce){
				Assert.assertTrue(false);
			}
			else{
				System.out.println("HHP is not available , test case is passed");
				Assert.assertTrue(true);
			}
		}catch(Exception E){
			Assert.assertTrue(true);
			System.out.println("HHP is not available , test case is passed");
			
		}
	}
	
	
	
	
	public void Verify_HHP_should_present(String value){
		try{
			By byvalue=By.xpath("//td[contains(text(),'"+value+"')]");
			
			BaseTestSetup.driver.switchTo().frame("frmDetails");
			
			Boolean HHP_Presnce=isWebElementDisplayed(byvalue);
			
			BaseTestSetup.driver.switchTo().defaultContent();
			
			if(HHP_Presnce){
				Assert.assertTrue(true);
			}
			else{
				System.out.println("HHP is not available , test case is passed");
				Assert.assertTrue(false);
			}
		}catch(Exception E){
			Assert.assertTrue(false);
			System.out.println("HHP is not available , test case is passed");
			
		}
		
	}

	public void Validate_PEP_Status(String status) {
		sleep(minWaitVal);
		BaseTestSetup.driver.switchTo().frame("frmDetails");
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB);
		screenshot();
		sleep(minWaitVal);
		String getStatus=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PEP_Status).getText().trim();
		BaseTestSetup.driver.switchTo().defaultContent();
		Assert.assertEquals(status, getStatus);
		System.out.println("Validation of PEP is sucessfull");
	
	}

	public void Validate_Sensitive_Client(String status) {
		sleep(minWaitVal);
		BaseTestSetup.driver.switchTo().frame("frmDetails");
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB);	
		screenshot();
		sleep(minWaitVal);
		String getStatus=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.Sensitive_Client).getText().trim();
		BaseTestSetup.driver.switchTo().defaultContent();
		Assert.assertEquals(status, getStatus);
		System.out.println("Validation of PEP is sucessfull");
	
	}

	public void click_Details_Button() {

		sleep(minWaitVal);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.Details_Button);
		sleep(mediumWaitVal);
		screenshot();
		
	}

	public void Validate_prohibition_code(String code1, String code2) {
		sleep(mediumWaitVal);
		BaseTestSetup.driver.switchTo().frame("frmDetails");
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.PROHIBITION_TAB);
		screenshot();
	
		String Sow_Codes=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SOW_Prohibition_code).getText().trim();
		BaseTestSetup.driver.switchTo().defaultContent();
		if(code1!=null){
		Assert.assertTrue(Sow_Codes.contains(code1));
		
		
		}
		if(code2!=null){
			Assert.assertTrue(Sow_Codes.contains(code2));
			
			}
		
	}

	public void verify_CDD_Status_for_alert(String custatus) {
		
		BaseTestSetup.driver.switchTo().frame("frmDetails");
		String status=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CDD_STATUS).getText().trim();
		BaseTestSetup.driver.switchTo().defaultContent();
		screenshot();
		Assert.assertEquals(custatus, status);
		System.out.println("CDD_Status validation is sucessfull");
		
	}

	public String find_new_generated_alert(String scenarioName,HashMap<String, String> testData, String Sheetname) throws Exception {
	
		sleep(minWaitVal);
		String date = getCurrentDate();
		webDriverWait(By.xpath("//td[@title='"+date+"']/../td[@title='High Risk Client']/../td[@aria-describedby='alertsModel_alertId']"));
		String Trigger_review=driver.findElement(By.xpath("//td[@title='"+date+"']/../td[@title='High Risk Client']/../td[@aria-describedby='alertsModel_alertId']")).getText();
		screenshot();
		Log.info(Trigger_review + " Manual Trigger alert is created");
		System.out.println(Trigger_review + " Manual Trigger alert is created");
		dataprovider.insertExcelData(scenarioName, "SECOND_MANUAL_TRIGGER_ALERT_ID",Sheetname, Trigger_review);
		return Trigger_review;
		
	}
	
	
	public String find_ICM_ID(String scenarioName,HashMap<String, String> testData, String Sheetname) throws Exception{
		sleep(minWaitVal);
		String ICM_ID = getTextFromWebElement(By.xpath("//td[text()='ICM ID:']/following-sibling::td"));
		
		Log.info(ICM_ID + " is created");
		System.out.println(ICM_ID + " is created");
		dataprovider.insertExcelData(scenarioName, "icmId",Sheetname, ICM_ID);
		
		
		return ICM_ID;
		
		
	}

	public void Relation_Diagram() {

		sleep(minWaitVal);
		mouseOver(ICDD_CustomerRecord_Obj.Realtion_Diagram_tab);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.Realtion_Diagram_tab);
		sleep(maxWaitVal);
		sleep(maxWaitVal);
		
		webDriverWait(ICDD_CustomerRecord_Obj.Apply_button);
		Scroll_To_End();
        screenshot();
        
		
		
	}

	public void validate_Risk_level_of_customer(String risklevel) {

		sleep(minWaitVal);
		String riskfromUI=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.Risk_Level).getText().trim();
		Assert.assertEquals(risklevel, riskfromUI);
		System.out.println("Risk level of customer validation is successfull");
		
	}

	public void conifrm_there_is_no_open_alerts() {
		
		sleep(minWaitVal);
		try{
		int openBulbCount=driver.findElements(ICDD_CustomerRecord_Obj.openBulb).size();
		if(openBulbCount>=1){
			System.out.println("There is open alerts present,validation is failed");
			Assert.assertTrue(false);
		}else{
			System.out.println("There is no open alerts present,validation is sucessfull");
		}
			
		}catch(Exception e){
			screenshot();
			System.out.println("There is no open alerts present,validation is sucessfull");
		}
		
		
		
	}
	
	public void Upload_evidence_filenet(HashMap<String, String> testData) throws IOException{
		
		sleep(minWaitVal);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.FILENET_MENU);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.UPLOAD_DOC_FILENET);
		sleep(minWaitVal);
		switchToWindow();
		enterInputText(ICDD_CustomerRecord_Obj.FilenetDOC_Document_Title, testData.get("Filenet_Document_title"));
		selectDropdownByIndex(ICDD_CustomerRecord_Obj.FilenetDOC_Product, 1);
		selectDropdownByIndex(ICDD_CustomerRecord_Obj.FilenetDOC_SubProduct, 1);
		selectDropdown(ICDD_CustomerRecord_Obj.FilenetDOC_DocCategory, testData.get("Filenet_Document_category"));
		selectDropdown(ICDD_CustomerRecord_Obj.FilenetDOC_DocType, testData.get("Filenet_Document_type"));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.FilenetDOC_Browse);
		copyFileNet(testData);
		Runtime.getRuntime().exec("src/test/resources/autoITScripts/Dettica_filenet_upload.exe");
		sleep(maxWaitVal);
		switchToParentWindow();
	}
	
	public void copyFileNet(HashMap<String, String> testData) throws IOException{
		 
		
		File src= new File(testData.get("FileNet"));        
        File destFile=new File("/src/test/resources/Attachment/dettica.png");
        FileUtils.copyFile(src, destFile);
        
	}

	public void take_screenshots_of_alert() {
		sleep(minWaitVal);
		BaseTestSetup.driver.switchTo().frame("frmDetails");
		
		sleep(minWaitVal);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB);
		screenshot();
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ONBOARDING_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.ONBOARDING_TAB);
		screenshot();
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CLIENT_RISK_RATING));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CLIENT_RISK_RATING);
		ieButtonJSClick(ICDD_CustomerRecord_Obj.OVERRIDE_DETAILS);
		
		screenshot();
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB);
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.PREVIOUS_RISK_RATING_TAB);
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.FCC_RISK_EVENT_TAB);
		
		ieButtonJSClick(ICDD_CustomerRecord_Obj.CRA_TAB);
		screenshot();
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_TAB));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.PROHIBITION_TAB);
		
		if(isWebElementDisplayed(ICDD_CustomerRecord_Obj.TRR_MAKER_NOTIFIER))
		{
		ieButtonJSClick(ICDD_CustomerRecord_Obj.TRR_MAKER_NOTIFIER);
		screenshot();
		}
		
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_CODE_DETAILS));
		ieButtonJSClick(ICDD_CustomerRecord_Obj.RISK_CODE_DETAILS);
		
		sleep(minWaitVal);
		scrollUpVertical(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MANUAL_VERIFICATION));
        ieButtonJSClick(ICDD_CustomerRecord_Obj.VERIFICATION);
        ieButtonJSClick(ICDD_CustomerRecord_Obj.MANUAL_VERIFICATION);
        screenshot();

        
		BaseTestSetup.driver.switchTo().defaultContent();
		
		
		
	}

	public void click_on_Customer_Alert_alert_level() {

		BaseTestSetup.driver.switchTo().frame("frmDetails");
    	ieButtonJSClick(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
    	BaseTestSetup.driver.switchTo().defaultContent();
		sleep(minWaitVal);
		screenshot();

		
	}




	
}
