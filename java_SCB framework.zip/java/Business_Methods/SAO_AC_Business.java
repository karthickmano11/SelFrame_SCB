package Business_Methods;


import java.awt.AWTException;
import java.awt.List;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

import org.antlr.v4.parse.BlockSetTransformer.setAlt_return;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.javascript.host.Window;

import Object_Repository.SAO_Objects;
import Object_Repository.SecurityMatrixObj;
import io.appium.java_client.functions.ExpectedCondition;
import net.sourceforge.marathon.javaagent.Wait;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;

public class SAO_AC_Business extends Common_Utils{
	
	DataProvider dataprovider = new DataProvider();
	public static String SAO_app_num=null;
	
	public void Search_SAO_app_application_number(HashMap<String, String> testData) throws Exception
	{
	
	if(!testData.get("SAO_APPLICATION_NUMBER").isEmpty())
	   {
			
		/*BaseTestSetup.driver.navigate().refresh();
		if (isAlertPresent()) {
			System.out.println(getText_AcceptAlert());
		                }
		}*/
	    sleep(mediumWaitVal);
		BaseTestSetup.driver.switchTo().frame("mainwin");
	       
	       sleep(mediumWaitVal);
	       By SAO_Application_Number=By.xpath("//a[text()='"+testData.get("SAO_APPLICATION_NUMBER")+"']");	
		    ieButtonJSClick(SAO_Application_Number);
	        
			sleep(minWaitVal);
			
			
			screenshotFullScreen();
			if(!testData.get("ICDD_ID").isEmpty() || testData.get("ICDD_ID")!=null)
			{	
			ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
			ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
			}
			else
			{
				System.out.println("Data Present in ICDD_ID, So Can't click on The Save and Next Button");
			}
			
		}}
	
	public void Search_SAO_app_Complete_fullfillment(HashMap<String, String> testData) throws Exception
	{
		       sleep(mediumWaitVal); 
		       
		       ieButtonJSClick(SAO_Objects.PRINT_APPLICATION);
		       
		       sleep(30000);
		       
			    switchToWindow("Application Form");;
			   //sleep(40000);
			   //BaseTestSetup.driver.manage().window().maximize();
			   //sleep(minWaitVal);
			   
			  // sleep(minWaitVal);
			   
			   screenshotFullScreen();
			   
			   Robot rb = new Robot();
			   rb.keyPress(KeyEvent.VK_ALT);
			   rb.keyPress(KeyEvent.VK_F4);
			   rb.keyRelease(KeyEvent.VK_ALT);
			   rb.keyRelease(KeyEvent.VK_F4);
			
			
			sleep(mediumWaitVal);
			
			screenshotFullScreen();
			
			ieButtonJSClick(SAO_Objects.SUBMIT_FULLFILLMENT);
			
			
			sleep(30000);
			
}
	

	public void loginApplication(String uname, String pwd) {
		try {
		sleep(minWaitVal);
		System.out.println("Check2- Inside loginapplication method");
		System.out.println("Check2" + BaseTestSetup.driver.getTitle());
		BaseTestSetup.driver.findElement(SAO_Objects.USER_NAME).sendKeys(uname);
		BaseTestSetup.driver.findElement(SAO_Objects.PASSWORD).sendKeys(pwd);
		screenshotFullScreen();
		ieButtonJSClick(SAO_Objects.SUBMIT);
		sleep(minWaitVal);
			
		} catch (Exception e) {
		  System.out.println("Login has failed ");
		}
		
	}

	public void Create_New_Application_Sourcing_Details(HashMap<String, String> testData) throws Exception {
        try{
		//Filling Sourcing Details
		sleep(mediumWaitVal);
		BaseTestSetup.driver.switchTo().frame("mainwin");
		screenshotFullScreen();
		ieButtonJSClick(SAO_Objects.NEW_APPLICATION_BUTTON);
		webDriverwait(SAO_Objects.ACQUISITION_CHANNEL);
		selectDropDownByText(SAO_Objects.ACQUISITION_CHANNEL, testData.get("ACQUISITION_CHANNEL"));
		screenshotFullScreen();
		ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
		ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
		sleep(minWaitVal);
        }
        catch(Exception e){
        	e.printStackTrace();
        }
		
	}
	
	//<<<<<..The Below Method is used to Create a Customer using Name , ID, DOB and  handle Dedup ETB.>>>>>//
	public String Applicant_Key_Details(String ScenarioName,HashMap<String, String> testData,String SheetName) throws Exception {
		
		//it will print the application Number
		String SAO_application_number = Split(SAO_Objects.PRINT_APPLICATION_NUMBER, ":", 1);
		dataprovider.insertExcelData(ScenarioName, "SAO_APPLICATION_NUMBER", SheetName, SAO_application_number);
		
		
		try{
			Robot rb=new Robot();
			sleep(minWaitVal);
			screenshotFullScreen();
		
			//Applicant Key Details
			selectDropdown(SAO_Objects.ID_TYPE, testData.get("ID_TYPE"));
			inputText(SAO_Objects.ID_NUMBER, testData.get("ID_NUMBER"));
			inputText(SAO_Objects.FULL_NAME, testData.get("FULL_NAME"));
			
			sleep(minWaitVal);

			selectDropDownByText(SAO_Objects.DOB_DATE, testData.get("DOB_DATE"));
			selectDropDownByText(SAO_Objects.DOB_MONTH, testData.get("DOB_MONTH"));
			selectDropDownByText(SAO_Objects.DOB_YEAR, testData.get("DOB_YEAR"));
			sleep(minWaitVal);
			
			ieButtonJSClick(SAO_Objects.SEARCH_APPLICANT);
			sleep(20000);
	
			/*Start- below code is for dedup screen for ETB or inactive customer*/
						
			Set<String> wins=BaseTestSetup.driver.getWindowHandles();
			System.out.println("No of windows open"+wins.size());
			if(wins.size()>1)
			{				
			try
			{
				switchToWindow("Applicant Details");
				System.out.println("After swiching to dedup");
				sleep(minWaitVal);
				screenshotFullScreen();
				sleep(mediumWaitVal);
				ieButtonJSClick(SAO_Objects.DEDUP_ICM_NUMBER);
				sleep(10000);
			    switchBackToParentWindow("Standard Account Opening");
			    BaseTestSetup.driver.switchTo().frame("mainwin");
			    sleep(10000);
			    System.out.println("Switching back to parent window"+BaseTestSetup.driver.getTitle());  	    
				
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			}
			else
			{
				System.out.println("This is not a ETB customer Data");
			}	
			/*End- below code is for dedup screen for ETB or inactive customer*/		
			screenshotFullScreen();
			sleep(mediumWaitVal);
			ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
			sleep(minWaitVal);
			
			if(testData.get("IS_JOINT_ACCOUNT").isEmpty()|| testData.get("IS_JOINT_ACCOUNT")==null)
			{
			ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
			
			sleep(mediumWaitVal);
			if (isAlertPresent()) {
				System.out.println(getText_AcceptAlert());
			                }
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return SAO_application_number;
		
		
	}	

		public void Applicant_Detais(HashMap<String, String> testData) throws Exception {
			
			try{
				
				sleep(minWaitVal);
				screenshotFullScreen();
				//FACTA
				selectDropdown(SAO_Objects.US_RESIDENT, testData.get("US_RESIDENT"));
				selectDropdown(SAO_Objects.US_CITIZEN, testData.get("US_CITIZEN"));
				selectDropdown(SAO_Objects.GREENCARD_HOLDER, testData.get("GREENCARD_HOLDER"));
				screenshotFullScreen();
				
				//tax_details
				selectDropdown(SAO_Objects.COUNTRY_OF_TAXRESIDENCE, testData.get("COUNTRY_OF_TAXRESIDENCE"));
				inputText(SAO_Objects.TAX_IDENTIFICATION_NUMBER, testData.get("TAX_IDENTIFICATION_NUMBER"));
				ieButtonJSClick(SAO_Objects.ADD_CR);
				//sleep(maxWaitVal);		
				
				screenshotFullScreen();
				
				
				//Personal_information
				//scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.FIRST_AND_MIDDLE_NAME));
				selectDropdown(SAO_Objects.TITLE, testData.get("TITLE"));
				inputText(SAO_Objects.FIRST_AND_MIDDLE_NAME, testData.get("FIRST_AND_MIDDLE_NAME"));
				inputText(SAO_Objects.LAST_NAME, testData.get("LAST_NAME"));
				
				
	            //Alias_name&Alais_Type
				
				if((testData.get("ALIAS_TYPE_1")!=null) && (!testData.get("ALIAS_TYPE_1").isEmpty()))
				{	
				String[] ALIAS_names_1 = testData.get("ALIAS_NAME_1").split("\\|");	
			
				for(int i=0;i<ALIAS_names_1.length;i++)
				{
					selectDropdown(SAO_Objects.ALIAS_TYPE, testData.get("ALIAS_TYPE_1"));
					inputText(SAO_Objects.ALIAS_NAME,ALIAS_names_1[i]);
					ieButtonJSClick(SAO_Objects.ALIAS_ADD);
					sleep(minWaitVal);
				}
				
				}
				else
				{
					System.out.println("ALIAS TYPE_1 is Empty.");
				}	
				
				  if((testData.get("ALIAS_TYPE_2")!=null) && (!testData.get("ALIAS_TYPE_2").isEmpty()))
				  { 
	               String[] ALIAS_names_2 = testData.get("ALIAS_NAME_2").split("\\|");
	           
				for(int i=0;i<ALIAS_names_2.length;i++)
				{
					selectDropdown(SAO_Objects.ALIAS_TYPE, testData.get("ALIAS_TYPE_2"));
					inputText(SAO_Objects.ALIAS_NAME,ALIAS_names_2[i]);
					ieButtonJSClick(SAO_Objects.ALIAS_ADD);
					sleep(minWaitVal);
				}
				
				  }
				  else
				  {
					  System.out.println("ALIAS TYPE_2 is Empty.");
				  }
				screenshotFullScreen();
	
             
				//Contunie Fillling Personal Information
				if(testData.get("IS_INACTIVE").isEmpty())
				{	
				enterInputText(SAO_Objects.Passport_Expiry, testData.get("Passport_Expiry"));
				}
				screenshotFullScreen();
			
				selectDropdown(SAO_Objects.CHAINA_ID_TYPE, testData.get("CHAINA_ID_TYPE"));
				ieButtonJSClick(SAO_Objects.MALE);
				if(testData.get("IS_INACTIVE").isEmpty())
				{	
				selectDropdown(SAO_Objects.NATIONALITY, testData.get("NATIONALITY"));
				}
				selectDropdown(SAO_Objects.COUNTRY_OF_BIRTH, testData.get("COUNTRY_OF_BIRTH"));
				selectDropdown(SAO_Objects.MARITAL_STATUS, testData.get("MARITAL_STATUS"));
				selectDropdown(SAO_Objects.PROFESSIONAL_QUALIFICATION, testData.get("PROFESSIONAL_QUALIFICATION"));
				selectDropdown(SAO_Objects.WORK_TYPE, testData.get("WORK_TYPE"));
				selectDropdown(SAO_Objects.INDUSTRY, testData.get("INDUSTRY"));
				selectDropdown(SAO_Objects.PROFESSION, testData.get("PROFESSION"));
				
				screenshotFullScreen();
				
				inputText(SAO_Objects.INCOME, testData.get("INCOME"));
				inputText(SAO_Objects.MAIL_ID, testData.get("MAIL_ID"));
				
				
				scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.PHONE_TYPE));
				selectDropdown(SAO_Objects.PHONE_TYPE, testData.get("PHONE_TYPE"));
				inputText(SAO_Objects.PHONE_NUMBER, testData.get("PHONE_NUMBER"));
				
				screenshotFullScreen();
				
				sleep(minWaitVal);
				
				ieButtonJSClick(SAO_Objects.BUTTON_ADD);
				screenshotFullScreen();
				sleep(minWaitVal);
				
				selectDropdown(SAO_Objects.PHONE_TYPE, testData.get("PHONE_TYPE1"));
				selectDropdown(SAO_Objects.COUNTRY_CODE, testData.get("COUNTRY_CODE"));
				inputText(SAO_Objects.PHONE_NUMBER, testData.get("PHONE_NUMBER_1"));
				screenshotFullScreen();
				
				sleep(minWaitVal);
				
				ieButtonJSClick(SAO_Objects.BUTTON_ADD);
				screenshotFullScreen();
				sleep(mediumWaitVal);
				
				if((testData.get("IS_INACTIVE").equals("Yes") && !testData.get("IS_INACTIVE").isEmpty())|| (!testData.get("IS_JOINT_ACCOUNT").isEmpty() || testData.get("IS_JOINT_ACCOUNT").equals("Yes")))
				{	
					selectDropdown(SAO_Objects.PROMOTION_EMAIL, testData.get("PROMOTION_EMAIL")); 
					selectDropdown(SAO_Objects.PROMOTION_MESSAGE, testData.get("PROMOTION_MESSAGE"));
					selectDropdown(SAO_Objects.PROMOTION_POST, testData.get("PROMOTION_POST"));
					selectDropdown(SAO_Objects.PROMOTION_PHONECALL, testData.get("PROMOTION_PHONECALL"));
					selectDropdown(SAO_Objects.PROMOTION_CONSERVATION_OVER_PHONE, testData.get("PROMOTION_CONSERVATION_OVER_PHONE"));
					screenshotFullScreen();
				}
				else
				{
					System.out.println("Promotions are already Filled");
				}	
				
				String[] Expected_Address = testData.get("ADDRESS_TYPE").split("\\|");
				for(int i=0;i<Expected_Address.length;i++)
				{
					switch (Expected_Address[i]) 
					{
					case "RES - Residential Address":
						if(testData.get("IS_INACTIVE").contentEquals("No")||testData.get("IS_INACTIVE").isEmpty()|| (!testData.get("IS_JOINT_ACCOUNT").isEmpty() ||  testData.get("IS_JOINT_ACCOUNT").equals("Yes")))
						{	
						selectDropdown(SAO_Objects.ADDRESS_TYPE, "RES - Residential Address");
						inputText(SAO_Objects.ADDRESS_LINE1, testData.get("ADDRESS_LINE1"));
						inputText(SAO_Objects.CITY, testData.get("CITY1"));
						selectDropdown(SAO_Objects.COUNTRY, testData.get("COUNTRY1"));
						screenshotFullScreen();
						ieButtonJSClick(SAO_Objects.ADD_ADDRESS);
	     				break;
						}
					case "PER - Permanent Address":
						selectDropdown(SAO_Objects.ADDRESS_TYPE, "PER - Permanent Address");
						selectDropdown(SAO_Objects.SAME_AS, testData.get("SAME_AS"));
						screenshotFullScreen();
						ieButtonJSClick(SAO_Objects.ADD_ADDRESS);
						break;
					case "CSA - Consolidated Statement Address":
						if(testData.get("IS_INACTIVE").contentEquals("No")||testData.get("IS_INACTIVE").isEmpty()|| (!testData.get("IS_JOINT_ACCOUNT").isEmpty() || testData.get("IS_JOINT_ACCOUNT").equals("Yes")))
						{	
						selectDropdown(SAO_Objects.ADDRESS_TYPE, "CSA - Consolidated Statement Address");
						selectDropdown(SAO_Objects.SAME_AS, testData.get("SAME_AS"));
						screenshotFullScreen();
						ieButtonJSClick(SAO_Objects.ADD_ADDRESS);
					    break;
						}
					case "AL1 - Alternate Address 1":
						selectDropdown(SAO_Objects.ADDRESS_TYPE, "AL1 - Alternate Address 1");
						selectDropdown(SAO_Objects.SAME_AS, testData.get("SAME_AS"));
						screenshotFullScreen();
						ieButtonJSClick(SAO_Objects.ADD_ADDRESS);
					    break;
						
				}
					
				}
				
				ieButtonJSClick(SAO_Objects.FINAL_SAVE);
				sleep(mediumWaitVal);
	           if(testData.get("IS_JOINT_ACCOUNT").isEmpty() || testData.get("IS_JOINT_ACCOUNT")==null)
					
				{
	        	sleep(minWaitVal);	
				Scroll_To_End();
				scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.NEXT_BUTTON));
				ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
				}
				
				
			}
		catch(Exception e){
			e.printStackTrace();
		}
		}			
		
		
	/**for ETB customer - fill the below appliant details**/	
	public void Applicant_Details_ETB(HashMap<String, String> testData){
			
			sleep(mediumWaitVal);
			scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.Passport_Expiry));
		    enterInputText(SAO_Objects.Passport_Expiry, testData.get("Passport_Expiry"));
			selectDropdown(SAO_Objects.CHAINA_ID_TYPE, testData.get("CHAINA_ID_TYPE"));
		    screenshotFullScreen();
		    
		    scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.PROMOTION_EMAIL));
  
		    selectDropdown(SAO_Objects.PROMOTION_EMAIL, testData.get("PROMOTION_EMAIL")); 
		    if (isAlertPresent()) {
				System.out.println(getText_AcceptAlert());
			                }
			selectDropdown(SAO_Objects.PROMOTION_MESSAGE, testData.get("PROMOTION_MESSAGE"));
			if (isAlertPresent()) {
				System.out.println(getText_AcceptAlert());
			                }
			selectDropdown(SAO_Objects.PROMOTION_POST, testData.get("PROMOTION_POST"));
			if (isAlertPresent()) {
				System.out.println(getText_AcceptAlert());
			                }
			selectDropdown(SAO_Objects.PROMOTION_PHONECALL, testData.get("PROMOTION_PHONECALL"));
			if (isAlertPresent()) {
				System.out.println(getText_AcceptAlert());
			                }
			selectDropdown(SAO_Objects.PROMOTION_CONSERVATION_OVER_PHONE, testData.get("PROMOTION_CONSERVATION_OVER_PHONE"));
			if (isAlertPresent()) {
				System.out.println(getText_AcceptAlert());
			                }
			screenshotFullScreen();
			
			ieButtonJSClick(SAO_Objects.FINAL_SAVE);
			sleep(mediumWaitVal);
			
		}
		
	public void Product_Selection(HashMap<String, String> testData) throws Exception{
	try{
		sleep(minWaitVal);	
		waitForElement(SAO_Objects.CASA);
		
		if(testData.get("CASA").equals("Yes")){
			ieButtonJSClick(SAO_Objects.CASA);
	        screenshotFullScreen();	
		}
		  
		  
		if(testData.get("TIMEDEPOSIT_CDA").equals("Yes"))
	       {
		     ieButtonJSClick(SAO_Objects.TIMEDEPOSIT_CDA);
		        screenshotFullScreen();	

	       }
		if(testData.get("INVESTMENT_ACCOUNT").equals("Yes"))
	       {
		     ieButtonJSClick(SAO_Objects.INVESTMENT_ACCOUNT);
		        screenshotFullScreen();	

	       }
		if(testData.get("CREDIT_CARDS").equals("Yes")){
			
		     ieButtonJSClick(SAO_Objects.CREDIT_CARDS);
		     screenshotFullScreen();
		}
		   
		
		ieButtonJSClick(SAO_Objects.FINAL_SAVE);
		sleep(minWaitVal);
		ieButtonJSClick(SAO_Objects.NEXT_BUTTON);	
			
		}
	catch(Exception e){
		e.printStackTrace();
	}
		
	}


	
	public void Service_Requested_CASA(HashMap<String, String> testData) throws Exception{
	try{
			
		//CASA--Product Details	
		        sleep(mediumWaitVal);
		        waitForElement(SAO_Objects.PRODUCT);
				selectDropdown(SAO_Objects.PRODUCT, testData.get("PRODUCT"));
				selectDropdown(SAO_Objects.SUB_PRODUCT, testData.get("SUB_PRODUCT"));
				ieButtonJSClick(SAO_Objects.GENERATE_ACCOUNT_NUMBER);	
				sleep(minWaitVal);
				
				screenshotFullScreen();
				selectDropdown(SAO_Objects.CURRENCY_CODE, testData.get("CURRENCY_CODE"));
				selectDropdown(SAO_Objects.CAPAIGN_CODE, testData.get("CAPAIGN_CODE"));
				selectDropdown(SAO_Objects.HOLD_CODE_1, testData.get("HOLD_CODE_1"));
				selectDropdown(SAO_Objects.HOLD_CODE_2, testData.get("HOLD_CODE_2"));
				inputText(SAO_Objects.HOLD_CODE_2_NARRATIVE,testData.get("HOLD_CODE_2_NARRATIVE"));
				
				screenshotFullScreen();
				
				inputText(SAO_Objects.AMOUNT_INITIAL_DEPOSITE, testData.get("AMOUNT_INITIAL_DEPOSITE"));
				selectDropdown(SAO_Objects.AMOUNT_INITIAL_DEPOSITE_CURRENCY, testData.get("AMOUNT_INITIAL_DEPOSITE_CURRENCY"));
				
				selectDropdown(SAO_Objects.PURPOSEOF_ACCOUNT_OPENING, testData.get("PURPOSEOF_ACCOUNT_OPENING"));
				
				ieButtonJSClick(SAO_Objects.PURPOSEOF_ACCOUNT_OPENING_ADD_BUTTON);
				
//				
			    if(isWebElementDisplayed(SAO_Objects.PURPOSE_FOR_OFFSHORE))
			     {
				selectDropdown(SAO_Objects.PURPOSE_FOR_OFFSHORE, testData.get("PURPOSE_FOR_OFFSHORE"));
			     }
				
				//Mailing Address---CASA
				sleep(minWaitVal);					
				selectDropdown(SAO_Objects.ADDRESS_TYPE_CASA, testData.get("ADDRESS_TYPE_CASA"));
				scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.SAVE_BUTTON));
				screenshotFullScreen();
				ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
				
				sleep(minWaitVal);	
				Scroll_To_End();
				scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.NEXT_BUTTON));
				screenshotFullScreen();
				ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
				
		
			
		}
	catch(Exception e){
		String mess = e.getMessage();
		System.out.println(mess);
		e.printStackTrace();
	}
		
	}
	

	public void Time_Deposit(HashMap<String, String> testData) throws Exception
	{
		try
		{
		//TD Product Details.	
		 sleep(mediumWaitVal);
		 screenshotFullScreen();
	     waitForElement(SAO_Objects.SUBPRODUCT_TD);
	     selectDropdown(SAO_Objects.SUBPRODUCT_TD, testData.get("SUBPRODUCT_TD"));
		 ieButtonJSClick(SAO_Objects.GENERATE_ACCOUNT_NUMBER);
		  sleep(minWaitVal);
		  selectDropdown(SAO_Objects.TERM_TYPE, testData.get("TERM_TYPE"));
		  inputText(SAO_Objects.TERM, testData.get("TERM"));
		 screenshotFullScreen();

		  
		//Mailing Address---CASA
			sleep(minWaitVal);					
			selectDropdown(SAO_Objects.ADDRESS_TYPE_CASA, testData.get("ADDRESS_TYPE_CASA"));
			scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.SAVE_BUTTON));
			screenshotFullScreen();
			ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
			screenshotFullScreen();
			
			sleep(minWaitVal);	
			Scroll_To_End();
			scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.NEXT_BUTTON));
			screenshotFullScreen();
			ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
			  

		 
	}
	public void Relationship_Package(HashMap<String, String> testData) throws Exception
	{

		screenshotFullScreen();
		sleep(maxWaitVal);
		
		WebDriverWait wait = new WebDriverWait(BaseTestSetup.driver, 20);
		WebElement Nextbutton = wait.until(ExpectedConditions.elementToBeClickable(SAO_Objects.NEXT_BUTTON));
	
		if(Nextbutton.isDisplayed())
		{
			ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
		}	
		else
		{
			System.out.println("Next Button is Not Clickable");
		}	

		screenshotFullScreen();
	}
	
	public void Banking_Services() throws Exception
	{
		sleep(mediumWaitVal);
		screenshotFullScreen();
	    waitForElement(SAO_Objects.BANKING_SERVICES_STATIMET_SUBSCRIPION_DETAILS);	
     	scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.SAVE_BUTTON));
		ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
		
		sleep(mediumWaitVal);
		if (isAlertPresent()) {
			System.out.println(getText_AcceptAlert());
		}
//		Scroll_To_End(); 
		screenshotFullScreen();
		sleep(minWaitVal);
		ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
		
		if (isAlertPresent()) {
			System.out.println(getText_AcceptAlert());
		}
		
	}
	
	public void FATCA_CRS_Document(HashMap<String, String> testData)
	{
		screenshotFullScreen();
		int bflag=webElementExistance(SAO_Objects.SAVE_BUTTON);
		if(bflag==1){
		ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
		}
		sleep(minWaitVal);
		
		//For joint account
		if((testData.get("IS_JOINT_ACCOUNT")!=null) && (!testData.get("IS_JOINT_ACCOUNT").isEmpty())){
		
			ieButtonJSClick(SAO_Objects.SECONDARY_APPLICANT);
			sleep(minWaitVal);
			ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
			
		}
		
		int Cflag=webElementExistance(SAO_Objects.NEXT_BUTTON);
		if(Cflag==1){
		ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
		}
		screenshotFullScreen();
	}
	
	
	public void Document_Check_List(HashMap<String, String> testData) throws Exception
	{
		sleep(mediumWaitVal);
		waitForElement(SAO_Objects.MANDATORY_DOCUMENTS);
		if(testData.get("MANDATORY_DOCUMENTS").contains("Yes"))
		{
			ieButtonJSClick(SAO_Objects.MANDATORY_DOCUMENTS);	
		}
		
		screenshotFullScreen();
		
		sleep(minWaitVal);
		ieButtonJSClick(SAO_Objects.SAVE_BUTTON);
		sleep(minWaitVal);
		ieButtonJSClick(SAO_Objects.NEXT_BUTTON);
	}
		
	
	public void CDD(String scenarioName,String secondary_scenario_name,HashMap<String, String> testData, String sheetname) throws Exception
	{
		ieButtonJSClick(SAO_Objects.SUBMIT_FOR_CDDPROCESS);
		screenshotFullScreen();
		sleep(60000);
		
		//-----For Normal Customers----//
		
		//it will print the ICCD_Ref Number and Update in Excel//
		WebElement ICCD_1 =  BaseTestSetup.driver.findElement(SAO_Objects.ICCD_NUMBER_1);
		String ICCD_REF_1 = ICCD_1.getText();
		System.out.println("The ICCD Number -1 is " + ICCD_REF_1);
		dataprovider.insertExcelData(scenarioName, "ICDD_ID", sheetname, ICCD_REF_1);
		testData.put("ICDD_ID", ICCD_REF_1);
		
		//it Will Print the NameScreeninghit Alert if Present and then update in Excel//
		WebElement namescreeninghit = BaseTestSetup.driver.findElement(SAO_Objects.NameScreening_AlertID);
		if(!namescreeninghit.getText().contains("–"))
		{
			String Alert_Namescreening = namescreeninghit.getText();
			System.out.println("The NameScreenig Alert ID is " + Alert_Namescreening);
			dataprovider.insertExcelData(scenarioName, "NameScreening_AlertID", sheetname, Alert_Namescreening);
			testData.put("NameScreening_AlertID", Alert_Namescreening);
		}
		else
		{
			System.out.println("No NameScreening Hit Found.");
		}	
		
		
		//---For JointCustomers---//
		
		if((testData.get("IS_JOINT_ACCOUNT")!=null) && (!testData.get("IS_JOINT_ACCOUNT").isEmpty()))
		{
		//This Will Take the ICDD number and update in Excel//	
		WebElement ICCD_2=  BaseTestSetup.driver.findElement(SAO_Objects.ICCD_NUMBER_2);
		String ICCD_REF_2 = ICCD_2.getText();	
		System.out.println("The ICCD Number- 2 is " + ICCD_REF_2);
		dataprovider.insertExcelData(secondary_scenario_name, "ICDD_ID", sheetname, ICCD_REF_2);
		testData.put("ICDD_ID", ICCD_REF_2);
		
		//This Will Print the Name Screening Hit Alert if Present and then Update in Excel//
		WebElement namescreeninghit_1 = BaseTestSetup.driver.findElement(SAO_Objects.NameScreening_AlertID_1);
       if(!namescreeninghit_1.getText().contains("-"))
       {   
		String Alert_Namescreening_1 = namescreeninghit_1.getText();
		System.out.println("The NameScreenig Alert ID is " + Alert_Namescreening_1);
		dataprovider.insertExcelData(secondary_scenario_name, "NameScreening_AlertID", sheetname, Alert_Namescreening_1);
		testData.put("NameScreening_AlertID", Alert_Namescreening_1);
       }
       else
       {
    	   System.out.println("No NameScreening Hit Found.");
       } 
       
		}
		
			
		
		System.out.println("Updated Successfully in Excel");
		screenshotFullScreen();
		
	}
	
	
	public void Search_for_application_to_Get_ICM_Number(HashMap<String, String> testData)
	{
		sleep(mediumWaitVal);
		BaseTestSetup.driver.switchTo().frame("mainwin");
		sleep(mediumWaitVal);
		selectDropdown(SAO_Objects.STATUS, testData.get("STATUS"));
		ieButtonJSClick(SAO_Objects.SEARCH_BUTTON);
		By SAO_Application_Number=By.xpath("//a[text()='"+testData.get("SAO_APPLICATION_NUMBER")+"']");
		ieButtonJSClick(SAO_Application_Number);
		sleep(minWaitVal);
		
	}
	
	public String Get_ICM_Number(String scenarioName,String secondary_scenario_name,HashMap<String, String> testData, String sheetname) throws Exception
	{
       String ICM_Number = Split(SAO_Objects.GET_ICM_NUMBER, "-", 1);
		
		System.out.println("The Number is : + " + ICM_Number);
		
		String ICM_FINAL = Twosplitstrings(ICM_Number, "//s", 0);
		String ICM_FINAL_NUMBER = Twosplitstrings(ICM_FINAL, " ", 0);
	
		System.out.println("The ICM Number is " + ICM_FINAL_NUMBER); 
		
		dataprovider.insertExcelData(scenarioName, "icmId", sheetname, ICM_FINAL_NUMBER);
		
		 if(!testData.get("IS_JOINT_ACCOUNT").isEmpty())
	       {  
	       String ICM_Number_joint = Split(SAO_Objects.GET_ICM_NUMBER_Joint, "-", 1);
		   System.out.println("The Number is : + " + ICM_Number_joint);
		   String ICM_FINAL_joint = Twosplitstrings(ICM_Number_joint, "//s", 0);
		   String ICM_JOINT_NUMBER = Twosplitstrings(ICM_FINAL_joint, " ", 0);
			System.out.println("The ICM Number is " + ICM_JOINT_NUMBER); 
			dataprovider.insertExcelData(secondary_scenario_name, "icmId", sheetname, ICM_JOINT_NUMBER);
			return ICM_JOINT_NUMBER;
	       }
		
			return ICM_FINAL;
		
				
	}
	
	
	
	
	public void Logout_SAO_application() {
		
	
		ieButtonJSClick(SAO_Objects.Logout_button);
		
		sleep(mediumWaitVal);
		
		if(BaseTestSetup.driver.getCurrentUrl().contains("http://10.112.182.34:9080/sao/system/mainFrame.jsp"))
		{
			System.out.println("Successfully Logged Out!");
		}
		
	}
	
	public void Close_Browser()
	{
		BaseTestSetup.driver.quit();
	}
	
	public void Open_Application_Rejected_Customer(HashMap<String, String> testData)
    {
                    if(testData.get("SAO_APPLICATION_NUMBER")!=null)
                       {
          BaseTestSetup.driver.switchTo().frame("mainwin");
          sleep(minWaitVal);
          By SAO_Application_Number=By.xpath("//a[text()='"+testData.get("SAO_APPLICATION_NUMBER")+"']");
                   screenshotFullScreen();
           ieButtonJSClick(SAO_Application_Number);
            System.out.println("SAO application is opened");
                                                    
            screenshotFullScreen();
            sleep(minWaitVal);
                    
                       }
                    sleep(mediumWaitVal);
                    if (isAlertPresent()) {
                                    System.out.println(getText_AcceptAlert());
                    
                       }
                    sleep(minWaitVal);
                    screenshotFullScreen();
    }
	

	

	
/********************  calender funtion for selecting the date given the masterdata xl ****************************************************************************/	
	//Date function
	
	/*public void Selecting_PassPort_Expire_Date(HashMap<String, String> testData) throws ParseException{
		
		*//**Selecting the date function*//*
		 
        
		String getDateFromXl=testData.get("PASSPORT_EXPIRY_DATE");//get it from xl "12/12/2020"
		System.out.println("Date from XL"+ getDateFromXl);
		String[] dtarray=getDateFromXl.split("/");
		
		int intdate=Integer.parseInt(dtarray[0]);
		int intmonth=Integer.parseInt(dtarray[1]);
		int intyear=Integer.parseInt(dtarray[2]);
		
		String strdate=dtarray[0];
		String strmonth=getMonthName(intmonth);
		String stryear=dtarray[2];
		
		System.out.println(convertToDate(getDateFromXl));
		System.out.println(getCurrentDate());
		
		Date dtfrmxl=convertToDate(getDateFromXl);
		Date currdt=getCurrentDt();
		
		//click on calender image
		scrollUpVertical(BaseTestSetup.driver.findElement(SAO_Objects.CALENDER_IMG));
		ieButtonJSClick(SAO_Objects.CALENDER_IMG);
		
		if(dtfrmxl.after(currdt))
		{
		
	       if(intyear==getCurrentYearNum()){
	    	   
	    	   if(intmonth<getCurrentMonthNum()){
	    			  
	    		      for(int i=getCurrentMonthNum();i>1;i--){
	    			  
	    			     //click on month backward and validate month is present are not
	    		    	  ieButtonJSClick(SAO_Objects.MONTH_BACKWARD);
	    				 if(BaseTestSetup.driver.findElement(SAO_Objects.MONTH_YEAR_STRING).getText().contains(strmonth)){
	    				   
	    				   //select the number(strdate) in the calender
	    					 
	    					 int  rowsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr")).size();
	    					 for(int a=1;a<=rowsize;a++){
	    						 
	    						 int colsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td")).size();
	    						 
	    						 for(int b=1;b<=colsize;b++){
	    							 
	    							 if(BaseTestSetup.driver.findElement(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]")).getText().equals(strdate))
	    							 {
	    							 ieButtonJSClick(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]"));
	    							 break;
	    						 }
	    					 }		 
	    				   
	    				   
	    				 }
	    				 
	    			  
	    			  }
	    		  
	    		      }
	    	   }  
	    		else if(intmonth>getCurrentMonthNum()){
	    		     
	    			 for(int i=getCurrentMonthNum();i<12;i++){
	    			  
	    			     //click month forward and validate month is present are not
	    				 ieButtonJSClick(SAO_Objects.MONTH_FORWARD);
	    				 if(BaseTestSetup.driver.findElement(SAO_Objects.MONTH_YEAR_STRING).getText().contains(strmonth)){
	    					 
	    					 int  rowsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr")).size();
	    					 for(int a=1;a<=rowsize;a++){
	    						 
	    						 int colsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td")).size();
	    						 
	    						 for(int b=1;b<=colsize;b++){
	    							 
	    							 if(BaseTestSetup.driver.findElement(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]")).getText().equals(strdate))
	    							 {
	    							 ieButtonJSClick(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]"));
	    							 break;
	    						 }
	    					 }
	    				   
	    				   
	    				   
	    				 }
	    				 
	    			  
	    			  }
	    		  
	    			 }
	    		} 
	    		  //current month
	    		 else{ 	      
                   
	    			 if(BaseTestSetup.driver.findElement(SAO_Objects.MONTH_YEAR_STRING).getText().contains(strmonth)){
    					 int  rowsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr")).size();
    					 for(int a=1;a<=rowsize;a++){
    						 
    						 int colsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td")).size();
    						 
    						 for(int b=1;b<=colsize;b++){
    							 
    							 if(BaseTestSetup.driver.findElement(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]")).getText().equals(strdate))
    							 {
    							 ieButtonJSClick(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]"));
    							 break;
    						 }
    					 }
    				   
    				 
    				   
    				 }
    				 
    			  
    			  }

	    		  }
	    	   
	       }
	    
	       }
	  
	   *//******For future year****//* 	   
	      else if(intyear>getCurrentYearNum()){
	    	     
	    		 // exam
	    		 int diff= intyear-getCurrentYearNum();
	    		 for(int i=0;i< diff;i++){
	    		 
	    			 ieButtonJSClick(SAO_Objects.YEAR_FORWARD);
	    		 
	    		 }
	    	 
	    		 	
	        if(BaseTestSetup.driver.findElement(SAO_Objects.MONTH_YEAR_STRING).getText().contains(stryear)){
	        	
	    		 if(intmonth<getCurrentMonthNum()){
	    		  
	    		      for(int i=getCurrentMonthNum();i>1;i--){
	    			  
	    			     //click and validate month is present are not
	    		    	  ieButtonJSClick(SAO_Objects.MONTH_BACKWARD);
	    		    	  if(BaseTestSetup.driver.findElement(SAO_Objects.MONTH_YEAR_STRING).getText().contains(strmonth)){
		    				   
		    				   //select the number(intdate) in the calender
		    					 
		    					 int  rowsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr")).size();
		    					 for(int a=1;a<=rowsize;a++){
		    						 
		    						 int colsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td")).size();
		    						 
		    						 for(int b=1;b<=colsize;b++){
		    							 
		    							 if(BaseTestSetup.driver.findElement(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]")).getText().equals(strdate))
		    							 {
		    							 ieButtonJSClick(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]"));
		    							 break;
		    						 }
		    					 }		 
		    				   
		    				   
		    				 }
		    				 
		    			  
		    			  }

	    				 
	    			  
	    			  }
	    		  
	    		  }
	    		else if(intmonth>getCurrentMonthNum()){
	    		     
	    			 for(int i=getCurrentMonthNum();i<12;i++){
	    			  
	    			     //click and validate month is present are not
	    				 ieButtonJSClick(SAO_Objects.MONTH_FORWARD);
	    				 if(BaseTestSetup.driver.findElement(SAO_Objects.MONTH_YEAR_STRING).getText().contains(strmonth)){
	    					 int  rowsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr")).size();
	    					 for(int a=1;a<=rowsize;a++){
	    						 
	    						 int colsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td")).size();
	    						 
	    						 for(int b=1;b<=colsize;b++){
	    							 
	    							 if(BaseTestSetup.driver.findElement(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]")).getText().equals(strdate))
	    							 {
	    							 ieButtonJSClick(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]"));
	    							 break;
	    						 }
	    					 }
	    				   
	    				   
	    				 }
	    				 
	    			  
	    			  }
	    		  
	    			 }
	    		}
	    		  
	    		 else{ 	      
                       
		    			 if(BaseTestSetup.driver.findElement(SAO_Objects.MONTH_YEAR_STRING).getText().contains(strmonth))
		    			 {
	    					 int  rowsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr")).size();
	    					 for(int a=1;a<=rowsize;a++){
	    						 
	    						 int colsize=BaseTestSetup.driver.findElements(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td")).size();
	    						 
	    						 for(int b=1;b<=colsize;b++){
	    							 
	    							 if(BaseTestSetup.driver.findElement(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]")).getText().equals(strdate))
	    							 {
	    							 ieButtonJSClick(By.xpath("//table[@calendar='[object Object]']/tbody/tr["+a+"]/td["+b+"]"));
	    							 break;
	    						 }
	    					 }
	    				   
	    				 }
	    				 
	    			  
	    			  }

		    		  }
	    		}
	    		
	    		 }    
	       
			
		// previous date
		else if(dtfrmxl.before(currdt)){
			
		}

        //current date
		else{
			
			
		}
				
		
		
	
		
		
		
	}
	
	
	public static Date getCurrentDt() throws ParseException{	
		Date date = new Date();	
		return date;
		 
	}

	public static Date convertToDate(String strdt) throws ParseException{
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy",  Locale.ENGLISH);
		Date date = dateFormat.parse(strdt);
		return date;
		
	}

	public static String getMonthName(int monthIndex) {
	    return new DateFormatSymbols().getMonths()[monthIndex-1].toString();
	}

	public static int getCurrentMonthNum(){
		 
		 Date date = new Date();
		 LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		 return localDate.getMonthValue();
	}
	public static int getCurrentYearNum(){
		
		return Calendar.getInstance().get(Calendar.YEAR);
	}
*/

	
	
}