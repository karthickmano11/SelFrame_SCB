package Business_Methods;

public class verifyICM {

	/*
	ICDD_CustomerRecord.searchiccdId(scenarioName,testData);
    ICDD_CustomerRecord.clickiccdid(scenarioName,testData);
System.out.print(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
    dataprovider.insertExcelData(scenarioName, " PROHIBITION_BASED_ON_STATIC_DATA", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA).getText());
    dataprovider.insertExcelData(scenarioName, " PROHIBITION_BASED_ON_NAME_SCREENING", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING).getText());
   // clickPerform(ICDD_CustomerRecord_Obj.CUSTOMER_PHONE_NUM);sleep(minWaitVal);
    try{
    dataprovider.insertExcelData(scenarioName, " PHONE1", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PHONE1).getText());
    }catch(Exception e){}
    clickPerform(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS);sleep(minWaitVal);
    try{
    dataprovider.insertExcelData(scenarioName, " EMAIL", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1).getText());
    }catch(Exception e){}
    clickPerform(ICDD_CustomerRecord_Obj.ACCOUNT_TAB);sleep(minWaitVal);
    clickPerform(ICDD_CustomerRecord_Obj.ACTIVE_ACCOUNT_DETAILS);sleep(minWaitVal);
    dataprovider.insertExcelData(scenarioName, " ACCOUNT_NUMBER5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCOUNT_NUMBER5).getText());
    dataprovider.insertExcelData(scenarioName, " ACCCOUNT_SUBPRODUCT5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCCOUNT_SUBPRODUCT5).getText());
    dataprovider.insertExcelData(scenarioName, " ACCOUNT_SUBPRODUCT_DESCRIPTION5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCOUNT_SUBPRODUCT_DESCRIPTION5).getText());*/

}
