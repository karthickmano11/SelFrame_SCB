package Business_Methods;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.List;

import org.antlr.v4.codegen.model.Action;
import org.apache.tools.ant.taskdefs.Sleep;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.fasterxml.jackson.databind.deser.Deserializers.Base;
import com.standardchartered.genie.model.GenieScenario;
import com.standardchartered.genie.module.selenium.core.SeleniumService;

import Object_Repository.OB_COS_obj;
import Step_Defination.Login_Glue;
import junit.extensions.TestDecorator;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;

public class ICDD_COSApp extends Common_Utils {
	DataProvider dataprovider = new DataProvider();
	public String homePageHandles;
	 

/* ---------------------------------------------------------------------
	Method Name: login_COSApplication
	Description: Method to log in to the COS Application.
	Author: Sathish A
------------------------------------------------------------------------*/
	
	public String login_COSApplication(String userName, String password){
		try{
			
			
			enterInputText(OB_COS_obj.Cos_UserName, userName);
			enterInputText(OB_COS_obj.Cos_pwd, password);
			//webElementClick(OB_COS_obj.Cos_Submit);
			ieButtonJSClick(OB_COS_obj.Cos_Submit);
			sleep(maxWaitVal);
			if(isAlertPresent()){
				System.out.println(getText_AcceptAlert());
				waitForElement(By.name("mainwin"));
			}else{
				System.out.println("No alert to handle");
			}			
			sleep(minWaitVal);
			waitForElement(By.name("mainwin"));
			WebElement frame = BaseTestSetup.driver.findElement(By.name("mainwin"));		
			BaseTestSetup.driver.switchTo().frame(frame);			
			homePageHandles = BaseTestSetup.driver.getWindowHandle();
			System.out.println(homePageHandles);
			//webDriverwait(OB_COS_obj.Cos_loggedin);			
			int bFlag = webElementExistance(OB_COS_obj.Cos_loggedin);
			if (bFlag ==1){
				System.out.println("Logged in successfully");
			}else{
				System.out.println("Unable to logged in");
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return homePageHandles;
	}
	
/* ---------------------------------------------------------------------
	Method Name: createnew_COSApplication
	Description: Method is used to create the new Application and perform the Dedupe.
	Author: Sathish A
------------------------------------------------------------------------*/	
public void createnew_COSApplication(HashMap<String, String> testData){
	try{
					
		sleep(mediumWaitVal);		
		//webDriverWait(OB_COS_obj.CREATE_NEW);
		ieButtonJSClick(OB_COS_obj.CREATE_NEW); 
		sleep(minWaitVal);
		//Switch to the pop window
		switchToWindow();			
		/*ExcelWriter writer = new ExcelWriter();
		writer.designAccelator();*/
		
		selectDropDownByText(OB_COS_obj.ID_Type, testData.get("ID_Type"));
		enterInputText(OB_COS_obj.ID_Number, testData.get("ID_Number"));
		enterInputText(OB_COS_obj.docExpiryDate, testData.get("Document_Expiry_Date"));
		BaseTestSetup.driver.findElement(OB_COS_obj.dateOfBirth).sendKeys(Keys.ENTER);
		enterInputText(OB_COS_obj.Full_Name, testData.get("Full_Name"));
		selectDropDownByText(OB_COS_obj.countryOfIssue, testData.get("Country_Of_Issue"));
		enterInputText(OB_COS_obj.dateOfBirth, testData.get("Date_Of_Birth"));
		BaseTestSetup.driver.findElement(OB_COS_obj.dateOfBirth).sendKeys(Keys.ENTER);		
		enterInputText(OB_COS_obj.Mobile_Number,  testData.get("Mobile_Number"));
		enterInputText(OB_COS_obj.Email, testData.get("Email_ID"));			
		ieButtonJSClick(OB_COS_obj.dedupe_Button);
		String WinID = BaseTestSetup.driver.getWindowHandle();
		sleep(mediumWaitVal);
		if(isAlertPresent()){
			String dedup = 	getText_AcceptAlert();
			if (dedup.equals("No customer match found")){
				
			}else{
				
			}
		}else{
			switchToWindow();
			sleep(mediumWaitVal);
            ieButtonJSClick(OB_COS_obj.DEDUP_NTB_BUTTON);
            getText_AcceptAlert();
            BaseTestSetup.driver.switchTo().window(WinID);
            sleep(minWaitVal);
            //acceptAlert();
            sleep(minWaitVal);
            

		}
		
		sleep(minWaitVal);
		
		selectDropDownByText(OB_COS_obj.salutationCode,  testData.get("Salutation"));
		if(!testData.get("Primary_Phone_Type").equals("")){
			selectDropDownByText(OB_COS_obj.primaryPhoneType,  testData.get("Primary_Phone_Type"));
		}
		selectDropDownByText(OB_COS_obj.isdCode,  testData.get("ISD_Code"));
		enterInputText(OB_COS_obj.isdAreaCode, testData.get("Area_Code"));
		if(!testData.get("Primary_Phone_Number").equals("")){
			selectDropDownByText(OB_COS_obj.primaryPhoneNumber,  testData.get("Primary_Phone_Number"));
		}
		
		ieButtonJSClick(OB_COS_obj.PerformPreScreen);
		sleep(mediumWaitVal);
		screenshot();
		
		webDriverWait(OB_COS_obj.productClassificationCode);
		
		sleep(minWaitVal);
		String application_Id= getTextFromWebElement(OB_COS_obj.Application_Id_fetch);
		application_Id = application_Id.substring(application_Id.indexOf(":") + 1);
		System.out.println(application_Id);
		System.out.println(getTextFromWebElement(OB_COS_obj.Application_Id_fetch));		
		testData.put("Application_ID", application_Id);		
		dataprovider.insertExcelData(testData.get("ScenarioName"), "Application_ID","COS", application_Id);
		
		ieButtonJSClick(OB_COS_obj.productClassificationCode);
		selectDropDownByText(OB_COS_obj.sBeginAIPOptionNewProduct, testData.get("New_Product"));
		
		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(mediumWaitVal);
		
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	
}


/* ---------------------------------------------------------------------
Method Name: cos_ProductDetails
Description: Method is used to select the product details of the customer.
Author: Sathish A
------------------------------------------------------------------------*/	
	public void cos_ProductDetails(HashMap<String, String> testData) throws AWTException {
	
		sleep(mediumWaitVal);
		try {
			switch (testData.get("New_Product")) {
			case "CREDIT CARDS":
				cos_CreditCardProduct(testData);
				break;

			default:
				break;
			}

			screenshot();
			ieButtonJSClick(OB_COS_obj.Process);
			sleep(mediumWaitVal);
			// sleep(minWaitVal);
			// ExcelWriter ds= new ExcelWriter();
			// ds.designAccelator();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

/* ---------------------------------------------------------------------
	Method Name: cos_CreditCardProduct
	Description: Method is used to select the Credit Card details of the customer.
	Author: Sathish A
------------------------------------------------------------------------*/
	public void cos_CreditCardProduct(HashMap<String, String> testData) throws Exception {
		/*ExcelWriter writer = new ExcelWriter();
		writer.designAccelator();*/
		
		sleep(mediumWaitVal);
		selectDropDownByText(OB_COS_obj.PRODUCT_TYPE, testData.get("Product_Type"));
		searchPromotionCode(testData);		
		sleep(mediumWaitVal);
		webDriverWait(OB_COS_obj.Affiliation);
		selectDropDownByText(OB_COS_obj.Affiliation, testData.get("Affiliation"));
		selectDropDownByText(OB_COS_obj.Card_Type, testData.get("Card_Type"));
		selectDropDownByText(OB_COS_obj.Fee_Terms, testData.get("Fee_Terms"));
		selectDropDownByText(OB_COS_obj.ASSESSMENT_TYPE, testData.get("Assessment_Type"));
		enterInputText(OB_COS_obj.Request_Amount, testData.get("Request_Amount"));
		if (testData.get("Supplementry_Cards").equals("")) {
			List<WebElement> element = BaseTestSetup.driver.findElements(OB_COS_obj.supplementry_Cards);
			for (int i = 0; i <= element.size(); i++) {
				if (testData.get("Supplementry_Cards").contains(element.get(i).getAttribute("value"))) {
					element.get(i).click();
					break;
				}
			}
		}

		sleep(minWaitVal);
		
	}

/* ---------------------------------------------------------------------
	Method Name: cos_MLIndividual
	Description: Method is used to select the MLIndividual details of the customer.
	Author: Sathish A
------------------------------------------------------------------------*/
	public void cos_MLIndividual(HashMap<String, String> testData) throws Exception {
		selectDropDownByText(OB_COS_obj.PRODUCT_CATEGORY, testData.get("PRODUCT_CATEGORY"));
		selectDropDownByText(OB_COS_obj.PRODUCT_TYPE, testData.get("Product_Type"));
		searchPromotionCode(testData);
		selectDropDownByText(OB_COS_obj.MORTGAGE_TYPE, testData.get("Mortgage_Type"));
		selectDropDownByText(OB_COS_obj.MORTGAGE_SERVICES, testData.get("Mortgage_Services"));
		selectDropDownByText(OB_COS_obj.ASSESSMENT_TYPE, testData.get("Assessment_Type"));
		if (testData.get("Broker_Referral_Flag").equals("Yes")) {
			ieButtonJSClick(OB_COS_obj.BROKER_REFERRAL_FLAG);
		}
		if (testData.get("Property_Details_Available").equals("Yes")) {
			selectDropDownByText(OB_COS_obj.PURCHASE_TYPE, testData.get("Purchase_Type"));
			selectDropDownByText(OB_COS_obj.USE_OF_PROPERTY, testData.get("Use_Of_Property"));
			enterInputText(OB_COS_obj.PROPERTY_TYPE, testData.get("Property_Type"));

		}

	}

/* ---------------------------------------------------------------------
	Method Name: searchPromotionCode
	Description: Method is used to search the Campagin Code for the customer
	Author: Sathish A
------------------------------------------------------------------------*/

	public void searchPromotionCode(HashMap<String, String> testData) {
		String windowHandle = BaseTestSetup.driver.getWindowHandle();
		System.out.println("Window Handle is " + windowHandle);
		ieButtonJSClick(OB_COS_obj.search_Icon);
		sleep(minWaitVal);
		switchToWindow("ID Search");
		sleep(minWaitVal);
		screenshot();
		List<WebElement> promotionTable = BaseTestSetup.driver
				.findElements(By.xpath("//table[@id ='basePromotionSearch_recordSet']/tbody/tr"));

		for (int i = 1; i <= promotionTable.size(); i++) {
			String promotionCode = BaseTestSetup.driver
					.findElement(By.xpath("//table[@id ='basePromotionSearch_recordSet']/tbody/tr[" + i + "]/td[1]"))
					.getText();
			if (promotionCode.equals(testData.get("Campaign_Code"))) {
				
				ieButtonJSClick(By.xpath("//table[@id ='basePromotionSearch_recordSet']/tbody/tr[" + i + "]/td[1]"), windowHandle);				
				break;
			}
		}
		sleep(minWaitVal);
		if (isAlertPresent()) {
			String alertText = getText_AcceptAlert();
			
		}
		System.out.println("Campagin Code is Selected");

	}

/* ---------------------------------------------------------------------
	Method Name: cos_customerDetailedView
	Description: Method is used to fill the customer information in Detailed
	Author: Sathish A
------------------------------------------------------------------------*/
	public void cos_customerDetailedView(HashMap<String, String> testData) throws Exception {
	/*	ExcelWriter writer = new ExcelWriter();
		writer.designAccelator();*/
		
		// ##################Application Details############################
		sleep(minWaitVal);
		ieButtonJSClick(OB_COS_obj.Applicant_Details);
		if (!testData.get("Customer_Segment").equals("")) {
			selectDropDownByText(OB_COS_obj.customerSegment, testData.get("Customer_Segment"));

		}
		screenshot();
		// ##########################Personal_Details#####################################
		ieButtonJSClick(OB_COS_obj.Personal_Details);
		selectDropDownByText(OB_COS_obj.nationalityCode, testData.get("Nationality"));
		if (testData.get("Permanent_Residence_Flag").equals("Yes")) {
			ieButtonJSClick(OB_COS_obj.permanentResFlag);
		}
		if (testData.get("Connected_Lending_Indicator").equals("Yes")) {
			ieButtonJSClick(OB_COS_obj.connectedLendingIndicator);
			selectDropDownByText(OB_COS_obj.connectedPartyRelation, testData.get("Connected_Party_Relation"));
		}

		selectDropDownByText(OB_COS_obj.customerConsent, testData.get("Customer_Consent"));
		screenshot();

		// ##########################Contact Details################################
		ieButtonJSClick(OB_COS_obj.Contact_Details);
		selectDropDownByText(OB_COS_obj.mailingAddressIndicator, testData.get("Mailing_Address_Indicator"));
		if (testData.get("Phone_Conversation_Flag").equals("No")) {
			ieButtonJSClick(OB_COS_obj.phoneConversationFlag);

		} else if (testData.get("Phone_Conversation_Flag").equals("Yes")) {
			if (!testData.get("Conversation_Date").equals("")) {
				enterInputText(OB_COS_obj.conversationDate, testData.get("Conversation_Date"));
			}
			if (!testData.get("Conversation_Time").equals("")) {
				String[] TimeValue = testData.get("Conversation_Time").split(":");
				System.out.println(TimeValue[0]);
				selectDropDownByText(OB_COS_obj.callHour, TimeValue[0]);
				selectDropDownByText(OB_COS_obj.callMinute, TimeValue[1]);
				selectDropDownByText(OB_COS_obj.callSeconds, TimeValue[2]);
				selectDropDownByText(OB_COS_obj.callInterval, TimeValue[3]);
			}
		}
		int bFlag = searchStaffPhone(testData);
		if (bFlag == 1) {
			enterInputText(OB_COS_obj.teleSalesPhone, testData.get("Phone_Number_Used"));
		}

		if (!testData.get("Email_Opt_Flag").equals("")) {
			selectDropDownByText(OB_COS_obj.emailOptFlag, testData.get("Email_Opt_Flag"));
		}
		if (!testData.get("SMS_Opt_Flag").equals("")) {
			selectDropDownByText(OB_COS_obj.smsOptFlag, testData.get("SMS_Opt_Flag"));
		}
		if (!testData.get("Post_Opt_Flag").equals("")) {
			selectDropDownByText(OB_COS_obj.postOptFlag, testData.get("Post_Opt_Flag"));
		}
		if (!testData.get("Phone_Opt_Flag").equals("")) {
			selectDropDownByText(OB_COS_obj.phoneOptFlag, testData.get("Phone_Opt_Flag"));
		}

		screenshot();
		// ##########################Residential Address################################
		ieButtonJSClick(OB_COS_obj.Residential_Address);
		enterInputText(OB_COS_obj.resAddress1, testData.get("Residential_Address_1"));
		enterInputText(OB_COS_obj.resAddress2, testData.get("Residential_Address_2"));
		enterInputText(OB_COS_obj.resCity, testData.get("Residential_City"));
		enterInputText(OB_COS_obj.resState, testData.get("Residential_State"));
		selectDropDownByText(OB_COS_obj.resCountry, testData.get("Residential_Country"));
		enterInputText(OB_COS_obj.resZipCode, testData.get("Residential_ZipCode"));
		selectDropDownByText(OB_COS_obj.residenceStatus, testData.get("Residential_Status"));
		if (testData.get("Residential_Status").equals("OTHERS")) {
			enterInputText(OB_COS_obj.residenceStatusOthers, testData.get("Residential_StatusOthers"));
		} else if (testData.get("Residential_Status").equals("RENTED")) {
			enterInputText(OB_COS_obj.monthlyRentalPayment, testData.get("Residential_Rent_Amount"));

		}

		screenshot();
		// ##########################Employment Details################################
		ieButtonJSClick(OB_COS_obj.Employment_Profession_Details);
		searchEmployment("Nature_Of_Business", testData);
		searchEmployment("Occupation_Code", testData);
		searchEmployment("Employment_Type", testData);
		enterInputText(OB_COS_obj.yrsInOccupation, testData.get("Year_In_Occupation"));
		enterInputText(OB_COS_obj.monthsInOccupation, testData.get("Month_In_Occupation"));
		if (testData.get("StaffIndicator").equals("Yes")) {
			ieButtonJSClick(OB_COS_obj.staffInd);
		}
		screenshot();

		// ##########################Financial Details################################
		ieButtonJSClick(OB_COS_obj.Financial_Details);
		selectDropDownByText(OB_COS_obj.financialCurrencyCode, testData.get("Currency_Code"));
		cos_FinancialDetails(testData);

		screenshot();
		// Overseas Income

		// ##########################More Financial
		// Details################################
		ieButtonJSClick(OB_COS_obj.More_Financial_Details);
		if (testData.get("off_US_Flag").equals("Yes")) {
			enterInputText(OB_COS_obj.offUSAccountNumber, testData.get("Off_US_AccountNumber"));
			selectDropDownByText(OB_COS_obj.acctDtaccountSourcels, testData.get("Off_US_AccountSoruce"));
			selectDropDownByText(OB_COS_obj.acctDtlsoffUSAccountType, testData.get("Off_US_AccountType"));
			selectDropDownByText(OB_COS_obj.accountCode, testData.get("Off_US_AccountCode"));
			selectDropDownByText(OB_COS_obj.interestCode, testData.get("Off_US_AccountCode"));
			enterInputText(OB_COS_obj.offUsOtherText, testData.get("Off_US_OtherText"));
		}
		screenshot();

		ieButtonJSClick(OB_COS_obj.Process);
		sleep(minWaitVal);
		// ######################################AIP Review ##################################
		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(minWaitVal);
		ieButtonJSClick(OB_COS_obj.Applicant_Details);
		ieButtonJSClick(OB_COS_obj.Personal_Details);
		ieButtonJSClick(OB_COS_obj.Contact_Details);
		ieButtonJSClick(OB_COS_obj.Residential_Address);
		ieButtonJSClick(OB_COS_obj.Employment_Profession_Details);
		ieButtonJSClick(OB_COS_obj.Financial_Details);
		ieButtonJSClick(OB_COS_obj.More_Financial_Details);
		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(maxWaitVal);

		webDriverwait(OB_COS_obj.customerRequest_status);
		screenshot();

		// ##################################AIP Results#######################################
		System.out.println(getTextFromWebElement(OB_COS_obj.customerRequest_status));

		if (testData.get("Decision_Choice").equals("Accept")) {
			ieButtonJSClick(OB_COS_obj.Decision_Accept);

		} else {
			ieButtonJSClick(OB_COS_obj.Decision_Escalate);
		}

		if (testData.get("Cross_Sell_Personalline_Credit").equals("Yes")) {
			ieButtonJSClick(OB_COS_obj.CrossSell_RPL);
		}

		if (testData.get("Cross_Sell_Personal_Loan").equals("Yes")) {
			ieButtonJSClick(OB_COS_obj.CrossSell_PL);
		}

		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(minWaitVal);

	}




/* ---------------------------------------------------------------------
	Method Name: searchEmployment
	Description: Method is used to fill the customer Employment information in Detailed
	Author: Sathish A
------------------------------------------------------------------------*/
	public void searchEmployment(String searchWhat, HashMap<String, String> testData) {
		String windowHandle;
		List<WebElement> promotionTable;
		switch (searchWhat) {
		case "Nature_Of_Business":
			windowHandle = BaseTestSetup.driver.getWindowHandle();
			System.out.println("Window Hande is " + windowHandle);
			ieButtonJSClick(OB_COS_obj.search_Icon_Business);
			sleep(minWaitVal);
			switchToWindow("ID Search");
			sleep(minWaitVal);
			screenshot();
			promotionTable = BaseTestSetup.driver
					.findElements(By.xpath("//table[@id ='NatureofBusinessLOV_recordSet']/tbody/tr"));
			for (int i = 1; i <= promotionTable.size(); i++) {
				String promotionCode = BaseTestSetup.driver
						.findElement(
								By.xpath("//table[@id ='NatureofBusinessLOV_recordSet']/tbody/tr[" + i + "]/td[2]"))
						.getText();
				if (promotionCode.equals(testData.get("Nature_Of_Business"))) {
					ieButtonJSClick(
							By.xpath("//table[@id ='NatureofBusinessLOV_recordSet']/tbody/tr[" + i + "]/td[2]"), windowHandle);
						
						
						
					break;
				}
				
			}
			sleep(mediumWaitVal);
			if (isAlertPresent()) {
				String alertText = getText_AcceptAlert();
				
			}
			
			System.out.println("Nature of Business Selected");
			break;
		case "Occupation_Code":
			windowHandle = BaseTestSetup.driver.getWindowHandle();
			System.out.println("Window Hande is " + windowHandle);
			ieButtonJSClick(OB_COS_obj.search_Icon_Occupation);
			sleep(minWaitVal);
			switchToWindow("ID Search");
			sleep(minWaitVal);
			screenshot();
			promotionTable = BaseTestSetup.driver
					.findElements(By.xpath("//table[@id ='OccupationCodeLOV_recordSet']/tbody/tr"));
			for (int i = 1; i <= promotionTable.size(); i++) {
				String promotionCode = BaseTestSetup.driver
						.findElement(By.xpath("//table[@id ='OccupationCodeLOV_recordSet']/tbody/tr[" + i + "]/td[2]"))
						.getText();
				if (promotionCode.equals(testData.get("Occupation_Code"))) {
					ieButtonJSClick(By.xpath("//table[@id ='OccupationCodeLOV_recordSet']/tbody/tr[" + i + "]/td[2]"), windowHandle);
					
					
					break;
				}
			}
			sleep(mediumWaitVal);
			if (isAlertPresent()) {
				String alertText = getText_AcceptAlert();
				
			}
			
			break;
		case "Employment_Type":
			windowHandle = BaseTestSetup.driver.getWindowHandle();
			System.out.println("Window Hande is " + windowHandle);
			ieButtonJSClick(OB_COS_obj.search_Icon_EmploymentType);
			sleep(minWaitVal);
			switchToWindow("ID Search");
			sleep(minWaitVal);
			screenshot();
			promotionTable = BaseTestSetup.driver
					.findElements(By.xpath("//table[@id ='EmploymentTypeCodeLOV_recordSet']/tbody/tr"));
			for (int i = 1; i <= promotionTable.size(); i++) {
				String promotionCode = BaseTestSetup.driver
						.findElement(
								By.xpath("//table[@id ='EmploymentTypeCodeLOV_recordSet']/tbody/tr[" + i + "]/td[2]"))
						.getText();
				if (promotionCode.equals(testData.get("Employment_Type"))) {
					ieButtonJSClick(
							By.xpath("//table[@id ='EmploymentTypeCodeLOV_recordSet']/tbody/tr[" + i + "]/td[2]"), windowHandle);
						
						
					break;
				}
			}
			sleep(mediumWaitVal);
			if (isAlertPresent()) {
				String alertText = getText_AcceptAlert();
				
			}
			
			break;
		default:
			break;
		}
	}

/* ---------------------------------------------------------------------
	Method Name: cos_FinancialDetails
	Description: Method is used to fill the customer Financial information in Detailed
	Author: Sathish A
------------------------------------------------------------------------*/
	public void cos_FinancialDetails(HashMap<String, String> testData) {
		String category;
		String employmentType = testData.get("Employment_Type");
		if (employmentType.contains("Employed -")) {
			category = "Employed";
		} else if (employmentType.contains("Self-Employed")) {
			category = "Self-Employed";
		} else {
			category = employmentType;
		}

		switch (category) {
		
		case "Employed":
			if (!testData.get("Domestic_Annual_Basic_Income").equals("")) {
				enterInputText(OB_COS_obj.annualBasicIncome, testData.get("Domestic_Annual_Basic_Income"));
			}

			if (!testData.get("Domestic_Annual_Bonus").equals("")) {
				enterInputText(OB_COS_obj.annualBonus, testData.get("Domestic_Annual_Bonus"));
			}

			if (!testData.get("Domestic_Annual_Commission").equals("")) {
				enterInputText(OB_COS_obj.annualCommission, testData.get("Domestic_Annual_Commission"));
			}

			if (!testData.get("Domestic_Annual_Rental_Income").equals("")) {
				enterInputText(OB_COS_obj.annualRentalIncome, testData.get("Domestic_Annual_Rental_Income"));
			}

			if (!testData.get("Domestic_Annual_Other_Income").equals("")) {
				enterInputText(OB_COS_obj.annualotherIncome, testData.get("Domestic_Annual_Other_Income"));
			}

			screenshot();

			if (!testData.get("Overseas_Annual_Basic_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualBasicIncome, testData.get("Overseas_Annual_Basic_Income"));
			}

			if (!testData.get("Overseas_Annual_Bonus").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualBonus, testData.get("Overseas_Annual_Bonus"));
			}

			if (!testData.get("Overseas_Annual_Commission").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualCommission, testData.get("Overseas_Annual_Commission"));
			}

			if (!testData.get("Overseas_Annual_Rental_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualRentalIncome, testData.get("Overseas_Annual_Rental_Income"));
			}

			if (!testData.get("Overseas_Annual_Other_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualRentalIncome, testData.get("Overseas_Annual_Other_Income"));
			}
			screenshot();

			break;
			
		case "Self-Employed":
			
			if (!testData.get("Domestic_Profit_PL").equals("")) {
				enterInputText(OB_COS_obj.profitAsPerPL, testData.get("Domestic_Profit_PL"));
			}

			if (!testData.get("Domestic_Annual_TurnOver").equals("")) {
				enterInputText(OB_COS_obj.turnOverDeclared, testData.get("Domestic_Annual_TurnOver"));
			}

			if (!testData.get("Domestic_Annual_TurnOver_BankStatement").equals("")) {
				enterInputText(OB_COS_obj.turnOverAsPerStatement, testData.get("Domestic_Annual_TurnOver_BankStatement"));
			}

			if (!testData.get("Domestic_Annual_Rental_Income").equals("")) {
				enterInputText(OB_COS_obj.annualRentalIncome, testData.get("Domestic_Annual_Rental_Income"));
			}

			if (!testData.get("Domestic_Annual_Other_Income").equals("")) {
				enterInputText(OB_COS_obj.annualotherIncome, testData.get("Domestic_Annual_Other_Income"));
			}

			screenshot();

			if (!testData.get("Overseas_Profit_PL").equals("")) {
				enterInputText(OB_COS_obj.overseasProfitAsPerPL, testData.get("Overseas_Profit_PL"));
			}

			if (!testData.get("Overseas_Annual_TurnOver").equals("")) {
				enterInputText(OB_COS_obj.overseasTurnOverDeclared, testData.get("Overseas_Annual_TurnOver"));
			}

			if (!testData.get("Overseas_Annual_TurnOver_BankStatement").equals("")) {
				enterInputText(OB_COS_obj.overseasTurnOverAsPerStmt, testData.get("Overseas_Annual_TurnOver_BankStatement"));
			}

			if (!testData.get("Overseas_Annual_Rental_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualRentalIncome, testData.get("Overseas_Annual_Rental_Income"));
			}

			if (!testData.get("Overseas_Annual_Other_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualRentalIncome, testData.get("Overseas_Annual_Other_Income"));
			}
			screenshot();

			
			break;

		default:
			if (!testData.get("Domestic_Annual_Basic_Income").equals("")) {
				enterInputText(OB_COS_obj.annualBasicIncome, testData.get("Domestic_Annual_Basic_Income"));
			}

			if (!testData.get("Domestic_Annual_Bonus").equals("")) {
				enterInputText(OB_COS_obj.annualBonus, testData.get("Domestic_Annual_Bonus"));
			}

			if (!testData.get("Domestic_Annual_Commission").equals("")) {
				enterInputText(OB_COS_obj.annualCommission, testData.get("Domestic_Annual_Commission"));
			}

			if (!testData.get("Domestic_Annual_Rental_Income").equals("")) {
				enterInputText(OB_COS_obj.annualRentalIncome, testData.get("Domestic_Annual_Rental_Income"));
			}

			if (!testData.get("Domestic_Annual_Other_Income").equals("")) {
				enterInputText(OB_COS_obj.annualotherIncome, testData.get("Domestic_Annual_Other_Income"));
			}

			screenshot();

			if (!testData.get("Overseas_Annual_Basic_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualBasicIncome, testData.get("Overseas_Annual_Basic_Income"));
			}

			if (!testData.get("Overseas_Annual_Bonus").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualBonus, testData.get("Overseas_Annual_Bonus"));
			}

			if (!testData.get("Overseas_Annual_Commission").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualCommission, testData.get("Overseas_Annual_Commission"));
			}

			if (!testData.get("Overseas_Annual_Rental_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualRentalIncome, testData.get("Overseas_Annual_Rental_Income"));
			}

			if (!testData.get("Overseas_Annual_Other_Income").equals("")) {
				enterInputText(OB_COS_obj.overseasAnnualRentalIncome, testData.get("Overseas_Annual_Other_Income"));
			}
			screenshot();
			break;
		}

	}
/* ---------------------------------------------------------------------
	Method Name: searchStaffPhone
	Description: Method is used to fill the customer Staff Phone information in Detailed
	Author: Sathish A
------------------------------------------------------------------------*/
	public int searchStaffPhone(HashMap<String, String> testData) {
		int bFlag = 0;
		String windowHandle = BaseTestSetup.driver.getWindowHandle();
		System.out.println("Window Hande is " + windowHandle);
		String staffOnPhone = getvalueFromWebElement(OB_COS_obj.teleSalesName);
		if (staffOnPhone.equals("")) {
			bFlag = 1;
			ieButtonJSClick(OB_COS_obj.search_Icon_Phone);
			sleep(minWaitVal);
			switchToWindow("ID Search");
			sleep(minWaitVal);
			screenshot();
			List<WebElement> promotionTable = BaseTestSetup.driver
					.findElements(By.xpath("//table[@id ='HK_AIPInfoSearch_recordSet']/tbody/tr"));

			for (int i = 1; i <= promotionTable.size(); i++) {
				String promotionCode = BaseTestSetup.driver
						.findElement(By.xpath("//table[@id ='HK_AIPInfoSearch_recordSet']/tbody/tr[" + i + "]/td[1]"))
						.getText();
				if (promotionCode.equals(testData.get("Phone_Sourcing_ID"))) {
					ieButtonJSClick(By.xpath("//table[@id ='HK_AIPInfoSearch_recordSet']/tbody/tr[" + i + "]/td[1]"));
					BaseTestSetup.driver.switchTo().window(windowHandle);
					break;
				}
			}
		}
		return bFlag;
	}

/* ---------------------------------------------------------------------
	Method Name: cos_CrossSell
	Description: Method is used to fill the customer Cross Sell Product 
	Author: Sathish A
------------------------------------------------------------------------*/
	public void cos_CrossSell(HashMap<String, String> testData) throws Exception {

		selectDropDownByText(OB_COS_obj.Affiliation, testData.get("Cross_Sell_Affiliation"));
		selectDropDownByText(OB_COS_obj.Card_Type, testData.get("CrossSell_Card_Type"));
		selectDropDownByText(OB_COS_obj.Fee_Terms, testData.get("Fee_Terms"));
		enterInputText(OB_COS_obj.Request_Amount, testData.get("Request_Amount"));
		if (testData.get("Supplementry_Cards").equals("")) {
			List<WebElement> element = BaseTestSetup.driver.findElements(OB_COS_obj.supplementry_Cards);
			for (int i = 0; i <= element.size(); i++) {
				if (testData.get("Supplementry_Cards").contains(element.get(i).getAttribute("value"))) {
					element.get(i).click();
					break;
				}
			}
		}
		sleep(minWaitVal);
		ieButtonJSClick(OB_COS_obj.Perform_Cross_Sell);
		sleep(mediumWaitVal);
		
		if(isAlertPresent()){
			getText_AcceptAlert();
			ieButtonJSClick(OB_COS_obj.Perform_Cross_Sell);
		}
		sleep(mediumWaitVal);
		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(maxWaitVal);

	}

/* ---------------------------------------------------------------------
	Method Name: cos_DataCompletion
	Description: Method is used to fill and review the customer informations
	Author: Sathish A
------------------------------------------------------------------------*/

	public void cos_DataCompletion(HashMap<String, String> testData) throws Exception {
		// #####################################Data Completion#########################
		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(minWaitVal);
		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(minWaitVal);
		
		
		//#################################ICDD Details#################################		
		ieButtonJSClick(OB_COS_obj.ICDD_Details);
		if(!testData.get("PEP_Flag").equals("")){
			selectDropDownByText(OB_COS_obj.potentialPEPStatus, testData.get("PEP_Flag"));
		}
		if(!testData.get("Sanction_Link_Indicator").equals("")){
			selectDropDownByText(OB_COS_obj.sanctionsLinkIndicator, testData.get("Sanction_Link_Indicator"));
		}
		if(!testData.get("Adverse_info_Indicator").equals("")){
			selectDropDownByText(OB_COS_obj.adverseInformation, testData.get("Adverse_info_Indicator"));
		}
		// #######################################Personal Details########################33
		webDriverwait(OB_COS_obj.Personal_Details);
		ieButtonJSClick(OB_COS_obj.Personal_Details);
		selectDropDownByText(OB_COS_obj.Marital_Status_Code, testData.get("Marital_Status"));
		selectDropDownByText(OB_COS_obj.Mode_Of_Communication, testData.get("Mode_Of_Communication"));
		selectDropDownByText(OB_COS_obj.Country_Of_Birth, testData.get("Country_Of_Birth"));
		enterInputText(OB_COS_obj.Establish_date, testData.get("Business_Establish_date"));

		screenshot();
		// #######################################Contact Details########################33
		ieButtonJSClick(OB_COS_obj.Contact_Information);
		enterInputText(OB_COS_obj.HomePhoneNo, testData.get("Home_Phone_No"));

		// #############################################Employment Details####################
		ieButtonJSClick(OB_COS_obj.employment_Profession_information);
		enterInputText(OB_COS_obj.Employer_Name, testData.get("Employer_Name"));
		enterInputText(OB_COS_obj.Bussiness_Ownership_Percentage, testData.get("Bussiness_Ownership_Percentage"));
		screenshot();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(mediumWaitVal);

		// ##########################################Bank Use###################################
		webDriverWait(OB_COS_obj.Bank_Use);
		ieButtonJSClick(OB_COS_obj.Bank_Use);
		selectDropDownByText(OB_COS_obj.Channel_Code, testData.get("Channel_Code"));
		selectDropDownByText(OB_COS_obj.Acquisition_Channel_Code, testData.get("Acquisition_Channel_Code"));
		selectDropDownByText(OB_COS_obj.Acquisition_Code, testData.get("Acquisition_Code"));
		screenshot();
		
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(maxWaitVal);
		screenshot();
		//To Get the ICDD Reference
		sleep(maxWaitVal);
		ieButtonJSClick(OB_COS_obj.Customer_Tab);
		sleep(maxWaitVal);
		if(isAlertPresent()){
			System.out.println(getText_AcceptAlert());
		}
		webDriverWait(OB_COS_obj.ICDD_Details);
		ieButtonJSClick(OB_COS_obj.ICDD_Details);
		screenshot();
		String icdd_ID = getTextFromWebElement(OB_COS_obj.ICDD_reference_Number);
		System.out.println(icdd_ID);
		testData.put("Application_ID", icdd_ID);		
		dataprovider.insertExcelData(testData.get("ScenarioName"), "ICDD_ID",testData.get("sheetName"), icdd_ID);
		ieButtonJSClick(OB_COS_obj.Application_Tab);
		sleep(mediumWaitVal);
		
		

	}
/* ---------------------------------------------------------------------
	Method Name: cos_OfferConfirmation
	Description: Method is used to verify the customer Offer and Proceed. 
	Author: Sathish A
------------------------------------------------------------------------*/
	public void cos_OfferConfirmation(HashMap<String, String> testData) {
		sleep(mediumWaitVal);
		int bFlag = webElementExistance(OB_COS_obj.Offer_Confirmation);
		if (bFlag == 0){
			screenshotFullScreen();
			ieButtonJSClick(OB_COS_obj.Process);
			sleep(maxWaitVal);
		}
		
		webDriverwait(OB_COS_obj.Offer_Confirmation);
		screenshotFullScreen();
		scrollUpVertical(BaseTestSetup.driver.findElement(By.xpath("//td[text()='Notification Status']/../..")));
		screenshotFullScreen();
		ieButtonJSClick(OB_COS_obj.Process);
		sleep(maxWaitVal);
		if (isAlertPresent()) {
			String alertText = getText_AcceptAlert();
			System.out.println(alertText);
			BaseTestSetup.driver.switchTo().window(testData.get("homePageHandles"));
		}

	}


	public void find_Application_ID(HashMap<String, String> testData) throws Exception{
		sleep(mediumWaitVal);
		enterInputText(OB_COS_obj.stxt_SD_APPREFID, testData.get("Application_ID"));
		sleep(minWaitVal);
		ieButtonJSClick(OB_COS_obj.Go_Button);
		sleep(mediumWaitVal);
		List<WebElement> table; 
		table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr"));
		for(int i=1;i<table.size();i++){
			String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[5]")).getText();
			System.out.println(app_Id);
			if(testData.get("Application_ID").equals(app_Id)){
				ieButtonJSClick(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[5]"));
				break;
			}
		}
		
		switchToWindow();
		sleep(maxWaitVal);
	}
	



public void cos_DocumentHandling(HashMap<String, String> testData) throws Exception{
	System.out.println(homePageHandles);
	List<WebElement> table; 	
	sleep(minWaitVal);
//	selectDropDownByText(OB_COS_obj.Now_viewing, "Generic List");
	selectDropDownByText(OB_COS_obj.Queue, "DOCUMENT HANDLING");
	enterInputText(OB_COS_obj.stxt_SD_APPREFID, testData.get("Application_ID"));
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[5]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			WebElement element = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[5]"));
			ieButtonJSClick(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[5]"));
			break;
		}
	}	

	switchToWindow();
	System.out.println(BaseTestSetup.driver.getCurrentUrl());
	sleep(minWaitVal);
	ieButtonJSClick(OB_COS_obj.Document_Tab);	
	Raise_Kiv(testData);
}



public void Raise_Kiv(HashMap<String, String> testData) throws Exception{
	Robot rb = new Robot();
	
	sleep(mediumWaitVal);	
	/*ieButtonJSClick(OB_COS_obj.KIV);	
	rb.keyPress(KeyEvent.VK_ENTER);
	rb.keyRelease(KeyEvent.VK_ENTER);
	sleep(mediumWaitVal);	
	
	
	 Robot robot = new Robot();
     Thread.sleep(5000);
     robot.keyPress(KeyEvent.VK_ENTER);
     Thread.sleep(5000);
     robot.keyPress(java.awt.event.KeyEvent.VK_R);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_R);
     
     Thread.sleep(1000);

     ......Department_ID............


     robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
    
    
     
//    
     
                          ..........Steam_ID................

     robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);

     ...........Target Receipt1...........
     robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
     Thread.sleep(1000);

     ..........................................

     robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
     Thread.sleep(1000);
     robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
     Thread.sleep(1000);
     robot.keyPress(KeyEvent.VK_ENTER);
     Thread.sleep(2000);
    */
	
     ieButtonJSClick(OB_COS_obj.save_exit);
     
     switchToWindow("Reason Capture");
     sleep(mediumWaitVal);
     selectDropDownByText(OB_COS_obj.Reason_Code, "OFFICE HOURS");
     ieButtonJSClick(OB_COS_obj.process_Exit);
     System.out.println(testData.get("homePageHandles"));
     BaseTestSetup.driver.switchTo().window(testData.get("homePageHandles")); 
     sleep(minWaitVal);
     System.out.println(BaseTestSetup.driver.getWindowHandle());
}


public void Save_Exit(HashMap<String, String> testData) throws Exception{
	ieButtonJSClick(OB_COS_obj.save_exit);    
    switchToWindow("Reason Capture");
    sleep(mediumWaitVal);
    selectDropDownByText(OB_COS_obj.Reason_Code, "OFFICE HOURS");
    ieButtonJSClick(OB_COS_obj.process_Exit);
    System.out.println(testData.get("homePageHandles"));
    BaseTestSetup.driver.switchTo().window(testData.get("homePageHandles")); 
    sleep(minWaitVal);
    System.out.println(BaseTestSetup.driver.getWindowHandle());
}


public void find_Appliaction_Verification(HashMap<String, String> testData) throws Exception{
	sleep(minWaitVal);
	selectDropDownByText(OB_COS_obj.channel, "Operations");
	sleep(1000);
	selectDropDownByText(OB_COS_obj.Now_viewing, "Generic List");
	sleep(minWaitVal);
	selectDropDownByText(OB_COS_obj.Queue, "VERIFICATION");
	sleep(1000);
	enterInputText(OB_COS_obj.txt_APPREFID, testData.get("Application_ID"));
	sleep(1000);
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	screenshotFullScreen();
	List<WebElement> table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'GENERICOPS_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'GENERICOPS_recordSet']/tbody/tr["+i+ "]/td[6]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			ieButtonJSClick(By.xpath("//table[@id = 'GENERICOPS_recordSet']/tbody/tr["+i+ "]/td[6]"));
			break;
		}
	}
	sleep(minWaitVal);
}



public void cos_Verification(HashMap<String, String> testData) throws Exception{
	sleep(minWaitVal);	
	switchToWindow();
	screenshotFullScreen();
	
	ieButtonJSClick(OB_COS_obj.Verification_Tab);
	sleep(mediumWaitVal);
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.Waived_Data_Address);
	WebElement element = BaseTestSetup.driver.findElement(OB_COS_obj.Waived_Data_Address);
	scrollUpVertical(element);
	screenshotFullScreen();
	sleep(minWaitVal);
	ieButtonJSClick(OB_COS_obj.update_Data_Address);
	sleep(minWaitVal);
	System.out.println(getText_AcceptAlert());
	sleep(mediumWaitVal);
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.Waived_Data_Employment);
	sleep(minWaitVal);
	scrollUpVertical(BaseTestSetup.driver.findElement(By.name("result[2].subResults[0].Updatestatus")));
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.update_Data_Employment);
	sleep(minWaitVal);
	System.out.println(getText_AcceptAlert());
	sleep(minWaitVal);
	screenshot();
	ieButtonJSClick(OB_COS_obj.Waived_Data_Telephone);
	sleep(minWaitVal);
	scrollUpVertical(BaseTestSetup.driver.findElement(By.name("result[2].subResults[1].Updatestatus")));
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.update_Data_Telephone);
	
	sleep(minWaitVal);
	if(isAlertPresent()){
		System.out.println(getText_AcceptAlert());
	}
	if(isAlertPresent()){
		System.out.println(getText_AcceptAlert());
	}
	sleep(mediumWaitVal);
	screenshotFullScreen();	
	/*String ICDD_ID = getTextFromWebElement(OB_COS_obj.ICDD_reference_Number);
	System.out.println(ICDD_ID);*/
	
	scrollUpVertical(BaseTestSetup.driver.findElement(By.xpath("//label[text()='Remarks :']")));
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.Process_DocumentHandling);
	BaseTestSetup.driver.switchTo().window(testData.get("homePageHandles"));
	sleep(maxWaitVal);
	screenshot();
	sleep(maxWaitVal);
	
}
	

public void find_ReleaseApplication(HashMap<String, String> testData) throws Exception{
	sleep(mediumWaitVal);
	int bFlag = webElementExistance(By.name("mainwin"));
	if (bFlag == 1){		
		WebElement frame = BaseTestSetup.driver.findElement(By.name("mainwin"));		
		BaseTestSetup.driver.switchTo().frame(frame);				
		sleep(minWaitVal);	
	}
	
	selectDropDownByText(OB_COS_obj.Queue, "DOCUMENT HANDLING");
	enterInputText(OB_COS_obj.stxt_SD_APPREFID, testData.get("Application_ID"));
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	List<WebElement> table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[5]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			WebElement element = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[5]"));
			ieButtonJSClick(By.xpath("//table[@id = 'MYSALES_recordSet']/tbody/tr["+i+ "]/td[1]//input"));
			break;
		}
	}
	
	ieButtonJSClick(OB_COS_obj.Release);
	sleep(minWaitVal);
	if(isAlertPresent()){
		getText_AcceptAlert();
	}
	
}



public void Find_Select_Application_KIV_Process(HashMap<String, String> testData) throws Exception{
	selectDropDownByText(OB_COS_obj.Now_viewing, "KIV Action List");
	sleep(minWaitVal);
	enterInputText(OB_COS_obj.txt_APPREFID, testData.get("Application_ID"));
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	List<WebElement> table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'MYKIVACTION_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'MYKIVACTION_recordSet']/tbody/tr["+i+ "]/td[2]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			ieButtonJSClick(By.xpath("//table[@id = 'MYKIVACTION_recordSet']/tbody/tr["+i+ "]/td[2]"));
		}
	}
	
}

public void find_Assigned_Application_DocumentHandling(HashMap<String, String> testData) throws Exception{
	System.out.println(homePageHandles);
	List<WebElement> table; 	
	sleep(minWaitVal);
	selectDropDownByText(OB_COS_obj.Now_viewing, "Generic List");
	sleep(minWaitVal);
	selectDropDownByText(OB_COS_obj.Queue, "DOCUMENT HANDLING");
	sleep(minWaitVal);
	enterInputText(OB_COS_obj.stxt_SD_APPREFID, testData.get("Application_ID"));
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'GENERICSALES_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'GENERICSALES_recordSet']/tbody/tr["+i+ "]/td[5]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			WebElement element = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'GENERICSALES_recordSet']/tbody/tr["+i+ "]/td[5]"));
			screenshotFullScreen();
			ieButtonJSClick(By.xpath("//table[@id = 'GENERICSALES_recordSet']/tbody/tr["+i+ "]/td[5]"));
			break;
		}
	}
	sleep(mediumWaitVal);
	if(isAlertPresent()){
		System.out.println(getText_AcceptAlert());
	}
	screenshotFullScreen();
	
}

public void cos_Waived_DocumentHandlingProcess(HashMap<String, String> testData) throws Exception{
	switchToWindow();
	sleep(minWaitVal);
	ieButtonJSClick(OB_COS_obj.Document_Tab);	
	sleep(minWaitVal);	
	List<WebElement> Application_Document = BaseTestSetup.driver.findElements(By.xpath("//div[@id = 'jsOverflowContainerTBO']//table/tbody/tr"));
	for(int i =1; i<=Application_Document.size(); i++){
		ieButtonJSClick(By.xpath("//div[@id = 'jsOverflowContainerTBO']//table/tbody/tr["+i+"]/td[3]//input"));
	}
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.Process_DocumentHandling);
	sleep(minWaitVal);
	
	BaseTestSetup.driver.switchTo().window(testData.get("homePageHandles"));
	waitForElement(By.name("mainwin"));
	WebElement frame = BaseTestSetup.driver.findElement(By.name("mainwin"));		
	BaseTestSetup.driver.switchTo().frame(frame);	
	sleep(mediumWaitVal);
	screenshotFullScreen();
	
}


public void cos_Document_Waiver_KIV(HashMap<String, String> testData){
	switchToWindow();
	sleep(mediumWaitVal);
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.submit_Replay);
	BaseTestSetup.driver.switchTo().window(testData.get("homePageHandles")); 
	screenshotFullScreen();
}


public void find_Appliaction_Final_Decision(HashMap<String, String> testData) throws Exception{
	sleep(minWaitVal);
	selectDropDownByText(OB_COS_obj.channel, "Operations");
	sleep(1000);
	selectDropDownByText(OB_COS_obj.Now_viewing, "Generic List");
	sleep(minWaitVal);
	selectDropDownByText(OB_COS_obj.Queue, "FINALDECISION");
	sleep(1000);
	enterInputText(OB_COS_obj.txt_APPREFID, testData.get("Application_ID"));
	sleep(1000);
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	List<WebElement> table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'GENERICOPS_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'GENERICOPS_recordSet']/tbody/tr["+i+ "]/td[6]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			ieButtonJSClick(By.xpath("//table[@id = 'GENERICOPS_recordSet']/tbody/tr["+i+ "]/td[6]"));
			break;
		}
	}
	sleep(minWaitVal);
}

public void find_Appliaction_OfferConfirmation(HashMap<String, String> testData) throws Exception{
	sleep(mediumWaitVal);
	selectDropDownByText(OB_COS_obj.channel, "Sales");
	sleep(1000);
	selectDropDownByText(OB_COS_obj.Now_viewing, "Generic List");
	sleep(minWaitVal);
	selectDropDownByText(OB_COS_obj.Queue, "OFFER CONFIRMATION");
	sleep(1000);
	enterInputText(OB_COS_obj.stxt_SD_APPREFID, testData.get("Application_ID"));
	sleep(1000);
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	List<WebElement> table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'GENERICSALES_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'GENERICSALES_recordSet']/tbody/tr["+i+ "]/td[5]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			ieButtonJSClick(By.xpath("//table[@id = 'GENERICSALES_recordSet']/tbody/tr["+i+ "]/td[5]"));
			
			break;
		}
	}
	sleep(minWaitVal);
	if(isAlertPresent()){
		System.out.println(getText_AcceptAlert());
	}
	

	
}

public void find_Appliaction_CreditInitiation(HashMap<String, String> testData) throws Exception{
	sleep(minWaitVal);
	List<WebElement> table;
	selectDropDownByText(OB_COS_obj.Now_viewing, "New Applications");
	sleep(minWaitVal);
	enterInputText(OB_COS_obj.txt_APPREFID, testData.get("Application_ID"));
	sleep(1000);
	ieButtonJSClick(OB_COS_obj.Go_Button);
	sleep(mediumWaitVal);
	table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'CINewApplicationLov_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'CINewApplicationLov_recordSet']/tbody/tr["+i+ "]/td[4]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			ieButtonJSClick(By.xpath("//table[@id = 'CINewApplicationLov_recordSet']/tbody/tr["+i+ "]/td[1]//input"));
			sleep(1000);
			ieButtonJSClick(OB_COS_obj.Credit_Initiation_Assign);			
			sleep(minWaitVal);
			if(isAlertPresent()){
				System.out.println(getText_AcceptAlert());
			}
			
			break;
			
		}
	}
	sleep(mediumWaitVal);
	table = BaseTestSetup.driver.findElements(By.xpath("//table[@id = 'CIMyApplicationLov_recordSet']/tbody/tr"));
	for(int i=1;i<=table.size();i++){
		String app_Id = BaseTestSetup.driver.findElement(By.xpath("//table[@id = 'CIMyApplicationLov_recordSet']/tbody/tr["+i+ "]/td[5]")).getText();
		if(testData.get("Application_ID").equals(app_Id)){
			ieButtonJSClick(By.xpath("//table[@id = 'CIMyApplicationLov_recordSet']/tbody/tr["+i+ "]/td[5]"));
			
			
			
			break;
			
		}
	}
	sleep(mediumWaitVal);
	
}

public void cos_CreditInitiation(HashMap<String, String> testData) throws Exception{
	switchToWindow();
	sleep(minWaitVal);
	ieButtonJSClick(OB_COS_obj.CI_Offer_With_Condition);
	screenshotFullScreen();
	selectDropDownByText(OB_COS_obj.CI_Offer_SubType, testData.get("CI_Offer_SubType"));
	enterInputText(OB_COS_obj.CI_debt_Settlement_Amt, testData.get("CI_debt_Settlement_Amt"));	
	ieButtonJSClick(OB_COS_obj.CI_Remodel);
	sleep(maxWaitVal);
	switch (testData.get("CI_Descision")) {
	case "Approve":
		waitForElement(OB_COS_obj.CI_Approve);
		ieButtonJSClick(OB_COS_obj.CI_Approve);
		screenshotFullScreen();
		break;

	default:
		break;
	}
	
	searchCIReasonCode(testData);
	screenshotFullScreen();
	ieButtonJSClick(OB_COS_obj.Process_DocumentHandling);
	sleep(maxWaitVal);
	
}

/* ---------------------------------------------------------------------
Method Name: searchPromotionCode
Description: Method is used to search the Campagin Code for the customer
Author: Sathish A
------------------------------------------------------------------------*/

public void searchCIReasonCode(HashMap<String, String> testData) {
	String windowHandle = BaseTestSetup.driver.getWindowHandle();
	System.out.println("Window Handle is " + windowHandle);
	ieButtonJSClick(OB_COS_obj.CI_Reason_Code_Search);
	sleep(minWaitVal);
	switchToWindow("ID Search");
	sleep(minWaitVal);
	screenshot();
	List<WebElement> promotionTable = BaseTestSetup.driver
			.findElements(By.xpath("//table[@id ='ApproveDeclineReasonCodes_recordSet']/tbody/tr"));

	for (int i = 1; i <= promotionTable.size(); i++) {
		String promotionCode = BaseTestSetup.driver
				.findElement(By.xpath("//table[@id ='ApproveDeclineReasonCodes_recordSet']/tbody/tr[" + i + "]/td[2]"))
				.getText();
		if (promotionCode.equals(testData.get("CI_Reason_Code"))) {
			
			ieButtonJSClick(By.xpath("//table[@id ='ApproveDeclineReasonCodes_recordSet']/tbody/tr[" + i + "]/td[2]"), windowHandle);				
			break;
		}
	}
	sleep(mediumWaitVal);
	System.out.println("ReasonCode is Selected");

}

public void cos_OfferConfirmation_FD(HashMap<String, String> testData) throws InterruptedException, AWTException{
	switchToWindow();
	String finalStatus = getTextFromWebElement(OB_COS_obj.Offer_Status);
	switch (finalStatus) {
	case "APPROVED":
		
		
		break;
		
	case "CI OFFER WITH CONDITION":
		ieButtonJSClick(OB_COS_obj.offer_Accept);
		break;
		
	case "DECLINED":
		ieButtonJSClick(OB_COS_obj.Offer_Appeal);
		if (isAlertPresent()) {
			System.out.println(getText_AcceptAlert());
		}
		
		BaseTestSetup.driver.switchTo().window(testData.get("homePageHandles"));
		processAppeal();
		
		break;

	default:
		break;
	}
	
	ieButtonJSClick(OB_COS_obj.Process);
	sleep(mediumWaitVal);
	if(isAlertPresent()){
		System.out.println(getText_AcceptAlert());
	}
}

public void processAppeal() throws InterruptedException, AWTException{
	Robot robot = new Robot();
    robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
    Thread.sleep(2000);
    robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
    robot.keyPress(java.awt.event.KeyEvent.VK_SPACE);
    robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
    robot.keyRelease(java.awt.event.KeyEvent.VK_SPACE);

    robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
    Thread.sleep(2000);
    robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
    robot.keyPress(java.awt.event.KeyEvent.VK_SPACE);
    robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
    robot.keyRelease(java.awt.event.KeyEvent.VK_SPACE);
    robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
    Thread.sleep(2000);

    robot.keyPress(java.awt.event.KeyEvent.VK_DOWN);
    Thread.sleep(2000);
    robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
    Thread.sleep(2000);
    robot.keyPress(java.awt.event.KeyEvent.VK_5);
    robot.keyPress(java.awt.event.KeyEvent.VK_0);
    Thread.sleep(1000);
    robot.keyPress(java.awt.event.KeyEvent.VK_5);
    robot.keyPress(java.awt.event.KeyEvent.VK_0);
    Thread.sleep(1000);
    robot.keyPress(java.awt.event.KeyEvent.VK_5);
    robot.keyPress(java.awt.event.KeyEvent.VK_0);
    Thread.sleep(1000);
    robot.keyPress(java.awt.event.KeyEvent.VK_0);
    robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
    Thread.sleep(3000);
    robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
    Thread.sleep(2000);
    robot.keyPress(java.awt.event.KeyEvent.VK_TAB);
    robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
    robot.keyPress(java.awt.event.KeyEvent.VK_SPACE);
    robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
    robot.keyRelease(java.awt.event.KeyEvent.VK_SPACE);
}
public void logout(){
	
	sleep(mediumWaitVal);
	ieButtonJSClick(OB_COS_obj.Logout);
	sleep(minWaitVal);	
	
	
}

public void getFulfilmentStatus(HashMap<String, String> testData){
	sleep(maxWaitVal);
	System.out.println(getTextFromWebElement(OB_COS_obj.fullfilmentStatus));
	screenshot();
	
}

	

	

}
