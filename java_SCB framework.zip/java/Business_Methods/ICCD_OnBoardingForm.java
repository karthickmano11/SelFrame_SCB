package Business_Methods;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Object_Repository.ICCD_OnboardingForm_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;

public class ICCD_OnBoardingForm extends Common_Utils{
	
	ICCD_OnboardingForm_Obj ICCD_OnboardingForm_Obj=new ICCD_OnboardingForm_Obj();
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	utillities.screenshot screenshot = new utillities.screenshot();
	
	
	public void primaryOnBoardingForm(String scenarioName, HashMap<String, String> testData,String sheetName, String temp) throws Exception{
	    
		sleep(mediumWaitVal);
		waitForElement(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		screenshot();
	    BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_CLINTLINK));
	    switch(temp){
	    case "client":
	    	ieButtonJSClick(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_CLINTLINK);
	    	screenshot();
		    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_CLIENTTYPE);
			selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_CLIENTTYPE, testData.get("CLIENTTYPE"));
			selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_RELATIONTYPE, testData.get("RELATIONTYPE"));
			selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACCOPENING, testData.get("ACCOPENING"));
			// selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_TITLE, testData.get("TITLE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_FIRSTNAME, testData.get("FIRSTNAME"));
		    //enterInput(ICCD_OnboardingForm_Obj.OBFORM_MIDDLENAME, testData.get("MIDDLENAME"));
		   // enterInput(ICCD_OnboardingForm_Obj.OBFORM_SURNAME, testData.get("SURNAME"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES, testData.get("OTHERKNOWNBYNAMES"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES2, testData.get("OTHERKNOWNBYNAMES2"));
		   // enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES3, testData.get(""));
		   // enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES4, testData.get(""));
		   // enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES5, testData.get(""));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ADDRESSTYPE, testData.get("ADDRESSTYPE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE1, testData.get("ADDLINE1"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE2, testData.get("ADDLINE2"));
		    screenshot();
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE3, testData.get("ADDLINE3"));
		    enterInputText(ICCD_OnboardingForm_Obj.OBFORM_CITY1, testData.get("CITY1"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_COUNTRY1, testData.get("COUNTRY1"));
		    //waitForElement(ICCD_OnboardingForm_Obj.OBFORM_COUNTRY1);
		   // selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_COUNTRY1, testData.get(""));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_STATE1, testData.get("STATE1"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_POSTAL1, testData.get("POSTAL1"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PHONETYPE, testData.get("PHONETYPE"));
		    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE);
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE, testData.get("COUNTRYCODE"));
		    //enterInput(ICCD_OnboardingForm_Obj.OBFORM_AREACODE, testData.get("AREACODE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS, testData.get("PHONEDETAILS"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_EMAILTYPE, testData.get("EMAILTYPE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EMAILADDRESS, testData.get("EMAILADDRESS"));
		    screenshot();
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCTYPE, testData.get("IDENTITYDOCTYPE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCUMENTNUMBER, testData.get("IDENTITYDOCUMENTNUMBER"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EXPIRYDATE, testData.get("EXPIRYDATE"));
		    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_DOB);
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_DOB, testData.get("DOB"));
		    screenshot();
		    //selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_COB, testData.get("COB"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS1, testData.get("NATIONALITIESORCITIZENSHIPS1"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS2, testData.get("NATIONALITIESORCITIZENSHIPS2"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS3, testData.get("NATIONALITIESORCITIZENSHIPS3"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS4, testData.get("NATIONALITIESORCITIZENSHIPS4"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_GENDER, testData.get("GENDER"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATUREOFEMPLOYMENT, testData.get("NATUREOFEMPLOYMENT"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_OCCUPATION, testData.get("OCCUPATION"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_INDUSTRY, testData.get("INDUSTRY"));
		    enterInput(ICCD_OnboardingForm_Obj.ANNUAL_INCOME, testData.get("ANNUAL_INCOME"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_INCOME_CURRENCY, testData.get("INCOME_CURRENCY"));
		    screenshot();
		   /* try{
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NAMEOFEMPLOYER, testData.get("NAMEOFEMPLOYER"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_NAMEOFEMPLOYER1, testData.get("NAMEOFEMPLOYER1"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_RESIDENT, testData.get("RESIDENT"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PERMRESIDENT, testData.get("PERMRESIDENT"));
		    }catch(Exception e){}*/
		    Thread.sleep(2000);
		    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTTAB);
		    switch(testData.get("PRODUCTNAME")){
		    case "Savings Account Products":
		    	selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTNAME, testData.get("PRODUCTNAME"));
			    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUBPRODUCT, testData.get("SUBPRODUCT"));
			    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACCOUNTCURRENCY, testData.get("ACCOUNTCURRENCY"));
			    BaseTestSetup.driver.findElement(By.xpath("//option[text()='" + testData.get("REASONESTABLOSHRELATION") + "']")).click();
			    enterInput(ICCD_OnboardingForm_Obj.OBFORM_AMTINIDEPOSIT, testData.get("AMTINIDEPOSIT"));
			    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_CURRENCY, testData.get("CURRENCY"));
		    	break;
		    case "Credit Card Products":
		    	selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTNAME, testData.get("PRODUCTNAME"));
			    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUBPRODUCT, testData.get("SUBPRODUCT"));
			    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACCOUNTCURRENCY, testData.get("ACCOUNTCURRENCY"));
			    break;
		    }	    
		    /*((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		            "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(By.xpath("//option[text()='" + testData.get("REASONESTABLOSHRELATION") + "']")));
		    BaseTestSetup.driver.findElement(By.xpath("(//option[text()='" + testData.get("TYPEINIDEPOSIT") + "'])[2]")).click();
		    Thread.sleep(1000);
		    BaseTestSetup.driver.findElement(By.xpath("(//option[text()='" + testData.get("SOURCEOFINITIALFUNDING") + "'])[2]")).click();
		    Thread.sleep(1000);
		    ((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		            "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(By.xpath("(//span[text()='Country(s) of initial Deposit'])[2]/../../../following-sibling::div//option[text()='" + testData.get("COUNTRYOFINITIALFUNDING") + "']")));
		    BaseTestSetup.driver.findElement(By.xpath("(//span[text()='Country(s) of initial Deposit'])[2]/../../../following-sibling::div//option[text()='" + testData.get("COUNTRYOFINITIALFUNDING") + "']")).click();
		    */
		    Thread.sleep(2000);
		    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_INTERNALINFO);
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACQUISITIONCHANNEL, testData.get("ACQUISITIONCHANNEL"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SEGMENT, testData.get("SEGMENT"));
		    
		    /*if(testData.get("SEGMENT").equals("Private Banking - Onshore")){
		    	selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUBSEGMENT, testData.get("SUBSEGMENT"));
		    }else{
		    	enterInput(ICCD_OnboardingForm_Obj.OBFORM_SUBSEGMENT1, testData.get("SUBSEGMENT"));
		    }*/
		    
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUBSEGMENT, testData.get("SUBSEGMENT"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_BRANCHCODE, testData.get("BRANCHCODE"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ARMCODE1, testData.get("ARMCODE1"));
		    enterInputText(ICCD_OnboardingForm_Obj.BOFORM_OWNERID, testData.get("OWNERID"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PEPORNOT, testData.get("PEPORNOT"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUSSANCTION, testData.get("SUSSANCTION"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ADVERSEINFO, testData.get("ADVERSEINFO"));
		    screenshot();
		    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SUMMARY);
		    Thread.sleep(1000);
		    screenshot();
	    	break;
	    case "RP":
	    	ieButtonJSClick(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_RP_INDIVIDUAL);
	    	screenshot();
	    	selectDropdown(ICCD_OnboardingForm_Obj.RP_COUNTRY_ACCOUNT_OPENING, testData.get("RP_CountryOfAcctOpening"));
	    	enterInputText(ICCD_OnboardingForm_Obj.RP_CASE_OWNER_ID, testData.get("RP_CaseOwnerID"));
	    	enterInputText(ICCD_OnboardingForm_Obj.RP_FIRSTNAME, testData.get("RP_FirstName"));
	    	selectDropdown(ICCD_OnboardingForm_Obj.RP_ADDRESS_TYPE, testData.get("RP_AddressType"));
	    	enterInputText(ICCD_OnboardingForm_Obj.RP_ADDRESS_LINE_1, testData.get("RP_AddressLine1"));
	    	enterInputText(ICCD_OnboardingForm_Obj.RP_ADDRESS_LINE_2, testData.get("RP_AddressLine2"));
	    	enterInputText(ICCD_OnboardingForm_Obj.RP_ADDRESS_LINE_3, testData.get("RP_AddressLine3"));
	    	selectDropdown(ICCD_OnboardingForm_Obj.RP_ADDRESS_CITY, testData.get("RP_AddressCity"));
	    	selectDropdown(ICCD_OnboardingForm_Obj.RP_ADDRESS_COUNTRY, testData.get("RP_AddressCountry"));
	    	screenshot();
	    	selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PHONETYPE, testData.get("RP_PHONETYPE"));
		    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE);
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE, testData.get("RP_COUNTRYCODE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS, testData.get("RP_PHONEDETAILS"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_EMAILTYPE, testData.get("RP_EMAILTYPE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EMAILADDRESS, testData.get("RP_EMAILADDRESS"));
		    screenshot();
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCTYPE, testData.get("RP_IDENTITYDOCTYPE"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCUMENTNUMBER, testData.get("RP_IDENTITYDOCUMENTNUMBER"));
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EXPIRYDATE, testData.get("RP_EXPIRYDATE"));
		    enterInputText(ICCD_OnboardingForm_Obj.RP_DOB, testData.get("RP_DOB"));
		    selectDropdown(ICCD_OnboardingForm_Obj.RP_NATIONALITIESORCITIZENSHIPS1, testData.get("RP_Nationality1"));
		    selectDropdown(ICCD_OnboardingForm_Obj.RP_GENDER, testData.get("RP_GENDER"));
		    screenshot();
		    ieButtonJSClick(ICCD_OnboardingForm_Obj.RP_SUMMARY_TAB);
		    screenshot();
	    	break;
	    default:
	    	break;
	    }
	    
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SAVE);
	    sleep(maxWaitVal);
	    screenshot();
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    Thread.sleep(18000);
	    screenshot();
	    sleep(maxWaitVal);
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    screenshot();
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    sleep(maxWaitVal);
	    sleep(maxWaitVal);
	    screenshot();
	    if (BaseTestSetup.driver.getPageSource().contains("Success")) {
	    	screenshot();
	        String partKey=BaseTestSetup.driver.findElement(ICCD_OnboardingForm_Obj.OBFORM_PARTYKEY).getText();
	        System.out.println("Partkey value2 " +partKey);
	        testData.put("ICDD_ID", partKey);
	        dataprovider.insertExcelData(scenarioName, "ICDD_ID",sheetName,partKey);
	        String NameScreenAlertID=BaseTestSetup.driver.findElement(ICCD_OnboardingForm_Obj.NAMESCREENING_ALERT_ID).getText();
	        if(!NameScreenAlertID.equals("")){
	        System.out.println("Name screening alert id " +NameScreenAlertID);
	        testData.put("NameScreening_AlertID", NameScreenAlertID);
	        dataprovider.insertExcelData(scenarioName, "NameScreening_AlertID",sheetName,NameScreenAlertID);
	        }
	        }
	    Thread.sleep(2000);
	    screenshot();
	    for(int i=3;i<=7;i=i+2)
	    {
	    	 int size=BaseTestSetup.driver.findElements(By.xpath("//*[@id='tab_SUMMARY']/div["+i+"]//tr[1]")).size();
	    	 for(int j=1;j<size;j=j+2)
	    	 {
	    		 ((JavascriptExecutor) BaseTestSetup.driver).executeScript(
	    		            "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(By.xpath("(//*[@id='tab_SUMMARY']/div["+i+"]//tr[1])["+j+"]"))); 
	    		 screenshot();
	    	 }
	    }

	}
	
	public void dettica_decision(HashMap<String, String> testData) throws Exception{
		sleep(minWaitVal);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.CASE_MANAGEMENT_MENU);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.ALERT_SEARCH);
		//mouseHoverClick(ICCD_OnboardingForm_Obj.CASE_MANAGEMENT_MENU, ICCD_OnboardingForm_Obj.ALERT_SEARCH);
		sleep(minWaitVal);
		enterInputText(ICCD_OnboardingForm_Obj.ALERT_ID_FIELD, testData.get("NameScreening_AlertID"));
		screenshot();
		ieButtonJSClick(ICCD_OnboardingForm_Obj.SEARCH_BUTTON);
		waitForElement(By.xpath("//a[text()='"+ testData.get("NameScreening_AlertID") +"']"));
		ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("NameScreening_AlertID") +"']"));
		sleep(5000);
		screenshot();
		ieButtonJSClick(ICCD_OnboardingForm_Obj.ALERT_ACTION);
		sleep(minWaitVal);
		selectDropdown(ICCD_OnboardingForm_Obj.WORKFLOW_ACTION, testData.get("Workflow_Action_decision"));
		enterInputText(ICCD_OnboardingForm_Obj.AUDIT_COMMENT, testData.get("Audit_comment"));
		String fileName = screenshot();
		testData.put("FileNet", fileName);
		dataprovider.insertExcelData(testData.get("scenarioName"), "FileNet", testData.get("sheetName"), fileName);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.PERFORM_BUTTON);
		sleep(minWaitVal);
		screenshot();
	}
	
	public void Norkom_login(String Uname, String Pwd){
		sleep(minWaitVal);
		enterInputText(ICCD_OnboardingForm_Obj.Norkom_username, Uname);
		enterInputText(ICCD_OnboardingForm_Obj.Norkom_pwd, Pwd);
		screenshot();
		ieButtonJSClick(ICCD_OnboardingForm_Obj.Login_button);
		sleep(minWaitVal);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.Notice_Ok_button);
		sleep(minWaitVal);
		BaseTestSetup.driver.get("http://aocwebd.hk.standardchartered.com:9083/norkom/home.do");
		screenshot();
	}
	
	public void resubmit_OB_application(HashMap<String, String> testData)throws Exception{
		sleep(mediumWaitVal);
		waitForElement(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		enterInputText(ICCD_OnboardingForm_Obj.OBFORM_ICDDID, testData.get("ICDD_ID"));
		screenshot();
		ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SEARCH);
		sleep(minWaitVal);
		screenshot();
		waitForElement(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
		ieButtonJSClick(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
		sleep(maxWaitVal);
		screenshot();
		if(testData.get("Resubmit_status").equals("Yes"))
		{
		switch(testData.get("Resubmit_value")){
		case "Phone_details":
			enterInputText(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS, testData.get("Phone_details"));
			screenshot();
			break;
		case "ID_No":
			enterInputText(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCUMENTNUMBER, testData.get("ID_No"));
			screenshot();
			break;
		case "Nationality":
			selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS1, testData.get("Nationality"));
			screenshot();
			break;
		case "DOB_resubmit":
			enterInputText(ICCD_OnboardingForm_Obj.OBFORM_DOB, testData.get("DOB_resubmit"));
			screenshot();
			break;
		}
		}
		sleep(2000);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SAVE);
		Thread.sleep(7000);
		screenshot();
		waitForElement(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    Thread.sleep(18000);
	    screenshot();
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    screenshot();
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    sleep(mediumWaitVal);
	    screenshot();
	}
	public void Search_customer_OB_Tab(HashMap<String, String> testData) throws Exception{
		sleep(mediumWaitVal);
		waitForElement(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		ieButtonJSClick(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
		enterInputText(ICCD_OnboardingForm_Obj.OBFORM_ICDDID, testData.get("ICDD_ID"));
		screenshot();
		ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SEARCH);
		sleep(minWaitVal);
		screenshot();
		String Cust_Type	= BaseTestSetup.driver.findElement(By.xpath("//span[text()='I_Related']/..")).getText();
		if (Cust_Type.contains("I_Related")){
			ieButtonJSClick(ICCD_OnboardingForm_Obj.SEARCH_RADIO_BUTTON);
			sleep(2000);
			screenshot();
		}
		ieButtonJSClick(ICCD_OnboardingForm_Obj.CONVERT_PARTY);
		sleep(minWaitVal);
		selectDropDownByValue(ICCD_OnboardingForm_Obj.PARTY_TYPE, "Client");
		screenshot();
		ieButtonJSClick(ICCD_OnboardingForm_Obj.CONTINUE_BOOKING);
		sleep(maxWaitVal);
		screenshot();
	}
	public void OB_Form_filling(String scenarioName, HashMap<String, String> testData,String sheetName) throws Exception{
		sleep(mediumWaitVal);
		waitForElement(ICCD_OnboardingForm_Obj.OBFORM_CLIENTTYPE);
		selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_CLIENTTYPE, testData.get("CLIENTTYPE"));
		selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_RELATIONTYPE, testData.get("RELATIONTYPE"));
		selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACCOPENING, testData.get("ACCOPENING"));
		enterInput(ICCD_OnboardingForm_Obj.OBFORM_FIRSTNAME, testData.get("FIRSTNAME"));
		enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES, testData.get("OTHERKNOWNBYNAMES"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES2, testData.get("OTHERKNOWNBYNAMES2"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ADDRESSTYPE, testData.get("ADDRESSTYPE"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE1, testData.get("ADDLINE1"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE2, testData.get("ADDLINE2"));
	    screenshot();
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE3, testData.get("ADDLINE3"));
	    enterInputText(ICCD_OnboardingForm_Obj.OBFORM_CITY1, testData.get("CITY1"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_COUNTRY1, testData.get("COUNTRY1"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_STATE1, testData.get("STATE1"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_POSTAL1, testData.get("POSTAL1"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PHONETYPE, testData.get("PHONETYPE"));
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE);
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE, testData.get("COUNTRYCODE"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS, testData.get("PHONEDETAILS"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_EMAILTYPE, testData.get("EMAILTYPE"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EMAILADDRESS, testData.get("EMAILADDRESS"));
	    screenshot();
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCTYPE, testData.get("IDENTITYDOCTYPE"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCUMENTNUMBER, testData.get("IDENTITYDOCUMENTNUMBER"));
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EXPIRYDATE, testData.get("EXPIRYDATE"));
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_DOB);
	    enterInput(ICCD_OnboardingForm_Obj.OBFORM_DOB, testData.get("DOB"));
	    screenshot();
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS1, testData.get("NATIONALITIESORCITIZENSHIPS1"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS2, testData.get("NATIONALITIESORCITIZENSHIPS2"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS3, testData.get("NATIONALITIESORCITIZENSHIPS3"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS4, testData.get("NATIONALITIESORCITIZENSHIPS4"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_GENDER, testData.get("GENDER"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_NATUREOFEMPLOYMENT, testData.get("NATUREOFEMPLOYMENT"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_OCCUPATION, testData.get("OCCUPATION"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_INDUSTRY, testData.get("INDUSTRY"));
	    enterInput(ICCD_OnboardingForm_Obj.ANNUAL_INCOME, testData.get("ANNUAL_INCOME"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_INCOME_CURRENCY, testData.get("INCOME_CURRENCY"));
	    screenshot();
	    Thread.sleep(2000);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTTAB);
	    switch(testData.get("PRODUCTNAME")){
	    case "Savings Account Products":
	    	selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTNAME, testData.get("PRODUCTNAME"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUBPRODUCT, testData.get("SUBPRODUCT"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACCOUNTCURRENCY, testData.get("ACCOUNTCURRENCY"));
		    BaseTestSetup.driver.findElement(By.xpath("//option[text()='" + testData.get("REASONESTABLOSHRELATION") + "']")).click();
		    enterInput(ICCD_OnboardingForm_Obj.OBFORM_AMTINIDEPOSIT, testData.get("AMTINIDEPOSIT"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_CURRENCY, testData.get("CURRENCY"));
	    	break;
	    case "Credit Card Products":
	    	selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTNAME, testData.get("PRODUCTNAME"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUBPRODUCT, testData.get("SUBPRODUCT"));
		    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACCOUNTCURRENCY, testData.get("ACCOUNTCURRENCY"));
		    break;
	    }
	    Thread.sleep(2000);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_INTERNALINFO);
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ACQUISITIONCHANNEL, testData.get("ACQUISITIONCHANNEL"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SEGMENT, testData.get("SEGMENT"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUBSEGMENT, testData.get("SUBSEGMENT"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_BRANCHCODE, testData.get("BRANCHCODE"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ARMCODE1, testData.get("ARMCODE1"));
	    enterInputText(ICCD_OnboardingForm_Obj.BOFORM_OWNERID, testData.get("OWNERID"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_PEPORNOT, testData.get("PEPORNOT"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_SUSSANCTION, testData.get("SUSSANCTION"));
	    selectDropdown(ICCD_OnboardingForm_Obj.OBFORM_ADVERSEINFO, testData.get("ADVERSEINFO"));
	    screenshot();
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SUMMARY);
	    Thread.sleep(1000);
	    screenshot();
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SAVE);
	    sleep(maxWaitVal);
	    screenshot();
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
	    Thread.sleep(18000);
	    screenshot();
	    sleep(mediumWaitVal);
	    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    screenshot();
	    ieButtonJSClick(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
	    sleep(maxWaitVal);
	    sleep(maxWaitVal);
	    screenshot();
	    if (BaseTestSetup.driver.getPageSource().contains("Success")) {
	    	screenshot();
	        String partKey=BaseTestSetup.driver.findElement(ICCD_OnboardingForm_Obj.OBFORM_PARTYKEY).getText();
	        System.out.println("Partkey value2 " +partKey);
	        testData.put("ICDD_ID", partKey);
	        dataprovider.insertExcelData(scenarioName, "ICDD_ID",sheetName,partKey);
	        String NameScreenAlertID=BaseTestSetup.driver.findElement(ICCD_OnboardingForm_Obj.NAMESCREENING_ALERT_ID).getText();
	        if(!NameScreenAlertID.equals("")){
	        System.out.println("Name screening alert id " +NameScreenAlertID);
	        testData.put("NameScreening_AlertID", NameScreenAlertID);
	        dataprovider.insertExcelData(scenarioName, "NameScreening_AlertID",sheetName,NameScreenAlertID);
	        }
	        }
	    Thread.sleep(2000);
	    screenshot();
	    for(int i=3;i<=7;i=i+2)
	    {
	    	 int size=BaseTestSetup.driver.findElements(By.xpath("//*[@id='tab_SUMMARY']/div["+i+"]//tr[1]")).size();
	    	 for(int j=1;j<size;j=j+2)
	    	 {
	    		 ((JavascriptExecutor) BaseTestSetup.driver).executeScript(
	    		            "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(By.xpath("(//*[@id='tab_SUMMARY']/div["+i+"]//tr[1])["+j+"]"))); 
	    		 screenshot();
	    	 }
	    }
	}
	
	}
